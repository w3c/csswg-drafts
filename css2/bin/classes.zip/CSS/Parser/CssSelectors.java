/*
 * $Log: CssSelectors.java,v $
 * Revision 2.5  1997/08/27 15:31:43  plehegar
 * Desactivated warning on block and inline element ...
 *
 * Revision 2.4  1997/08/22 14:55:48  plehegar
 * Added isEmpty()
 *
 * Revision 2.3  1997/08/21 07:25:30  plehegar
 * Added auralMode, getNext, setNext
 *
 * Revision 2.2  1997/08/20 11:41:28  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:34  plehegar
 * Nothing
 *
 * Revision 1.1  1997/08/01 19:35:24  plehegar
 * Initial revision
 *
 */
package CSS.Parser;

import java.net.URL;
import java.util.Vector;
import java.util.Properties;

import CSS.util.Warnings;
import CSS.util.Messages;
import CSS.util.Util;
import CSS.util.InvalidParamException;
import CSS.Properties.CssProperty;

/**
 * This class manages all contextual selector.
 *
 * <p>Note:<BR>
 * Invoke a <code>set</code> function to change the selector clears all
 * properties !
 *
 * @version $Revision: 2.5 $
 */
public final class CssSelectors implements CssSelectorsConstant {
    
    /**
     * The element.
     */  
    protected String element; 
    
    /**
     * All classes. You can have more than one class in a HTML document but
     * only one in a CSS1 rule. For the moment, only one class is supported.
     *
     *   <H3>
     *      &nbsp;&nbsp; Class as selector
     *   </H3>
     *   <P>
     *   To increase the granularity of control over elements, a new attribute has
     *   been added to HTML <A HREF="#ref2">[2]</A>: 'CLASS'. All elements inside
     *   the 'BODY' element can be classed, and the class can be addressed in the
     *   style sheet:
     *   <PRE>
     * &lt;HTML&gt;
     *  &lt;HEAD&gt;
     *   &lt;TITLE&gt;Title&lt;/TITLE&gt;
     *   &lt;STYLE TYPE="text/css"&gt;
     *     H1.pastoral { color: #00FF00 }
     *   &lt;/STYLE&gt;
     *  &lt;/HEAD&gt;
     *  &lt;BODY&gt;
     *   &lt;H1 CLASS=pastoral&gt;Way too green&lt;/H1&gt;
     *  &lt;/BODY&gt;
     * &lt;/HTML&gt;
     * </PRE>
     *
     * <P> The normal inheritance rules apply to classed elements; they inherit
     * values from their parent in the document structure.
     *
     * <P> One can address all elements of the same class by omitting the tag name
     * in the selector:
     *
     *   <PRE>
     *   .pastoral { color: green }  / * all elements with CLASS pastoral * /
     * </PRE>
     *
     * <P> * Only one class can be specified per selector. 'P.pastoral.marine' is
     * therefore * an invalid selector in CSS1. (Contextual selectors, described
     * below, can * have one class per simple selector)
     *
     * <P> CSS gives so much power to the CLASS attribute, that in many cases
     * it doesn't even matter what HTML element the class is set on -- you can
     * make any element emulate almost any other. Relying on this power is not
     * recommended, since it removes the level of structure that has a
     * universal meaning (HTML elements). A structure based on CLASS is only
     * useful within a restricted domain, where the meaning of a class has been
     * mutually agreed upon.  
     */
    protected Vector classe = new Vector(); 
    
    /**
     * The id.
     *
     *   <H3>
     *      &nbsp;&nbsp; ID as selector
     *   </H3>
     *
     * <P> HTML also introduces the 'ID' attribute which is guaranteed to have a
     * unique value over the document. It can therefore be of special importance
     * as a style sheet selector, and can be addressed with a preceding '#':
     *
     *   <PRE>
     *   #z98y { letter-spacing: 0.3em }
     *   H1#z98y { letter-spacing: 0.5em }
     *   &lt;P ID=z98y&gt;Wide text&lt;/P&gt;
     * </PRE>
     *
     * <P> In the above example, the first selector matches the 'P' element due to
     * the 'ID' attribute value. The second selector specifies both an element
     * type ('H1') and an ID value, and will therefore not match the 'P' element.
     *
     * <P> By using the ID attribute as selector, one can set style properties on
     * a per-element basis. While style sheets have been designed to augment
     * document structure, this feature will allow authors to create documents
     * that present well on the canvas without taking advantage of the structural
     * elements of HTML. This use of style sheets is discouraged.  
     */
    protected String id; 
    
    /**
     * The pseudo class.
     *
     *   <H3>
     *  &nbsp;&nbsp; Anchor pseudo-classes
     *   </H3>
     *
     * <P> User agents commonly display newly visited anchors differently from
     * older ones. In CSS1, this is handled through pseudo-classes on the 'A'
     * element:
     *
     *   <PRE>
     *   A:link { color: red } / * unvisited link * / 
     * A:visited { color: blue } / * visited links * / 
     * A:active { color: lime } / * active links * /
     * </PRE>
     *
     * <P> All 'A' elements with an 'HREF' attribute will be put into one and only
     * one of these groups (i.e. target anchors are not affected). UAs may choose
     * to move an element from 'visited' to 'link' after a certain time. An
     * 'active' link is one that is currently being selected (e.g. by a mouse
     * button press) by the reader.
     *
     * <P> The formatting of an anchor pseudo-class is as if the class had been
     * inserted manually. A UA is not required to reformat a currently displayed
     * document due to anchor pseudo-class transitions. E.g., a style sheet can
     * legally specify that the 'font-size' of an 'active' link should be larger
     * that a 'visited' link, but the UA is not required to dynamically reformat
     * the document when the reader selects the 'visited' link.
     *
     * <P> Pseudo-class selectors do not match normal classes, and vice versa. The
     * style rule in the example below will therefore not have any influence:
     *
     * <PRE>
     *   A:link { color: red }
     *   &lt;A CLASS=link NAME=target5&gt; ... &lt;/A&gt;
     * </PRE>
     *
     * <P> In CSS1, anchor pseudo-classes have no effect on elements other than
     * 'A'.  Therefore, the element type can be omitted from the selector:
     *
     * <PRE>
     *   A:link { color: red } :link { color: red }
     * </PRE>
     *
     * <P>The two selectors above will select the same elements in CSS1.
     * <P>Pseudo-class names are case-insensitive.
     * <P>Pseudo-classes can be used in contextual selectors:
     *
     * <PRE>
     *   A:link IMG { border: solid blue }
     * </PRE>
     *
     * <P>Also, pseudo-classes can be combined with normal classes:
     *
     * <PRE>
     *   A.external:visited { color: blue }
     *   &lt;A CLASS=external HREF="http: *out.side/"&gt;external link&lt;/A&gt;
     * </PRE>
     *
     * <P> If the link in the above example has been visited, it will be rendered
     * in blue. Note that normal class names precede pseudo-classes in the
     * selector.  
     */
    protected String pseudoClass;
    
    /**
     * The pseudo Element.
     *
     * <p>
     * The description was too big to appear here, so please consult the
     * <A HREF="http://www.w3.org/TR/REC-CSS1#typographical-pseudo-elements">
     * online documentation</A>.
     */
    protected String pseudoElement; 
    
    /**
     * The next context.
     *
     * <H3>
     *    &nbsp;&nbsp; Contextual selectors
     * </H3>
     *
     * <P> Inheritance saves CSS designers typing. Instead of setting all style
     * properties, one can create defaults and then list the exceptions. To give
     * 'EM' elements within 'H1' a different color, one may specify:
     *
     *   <PRE>
     *   H1 { color: blue }
     *   EM { color: red }
     * </PRE>
     *
     * <P> When this style sheet is in effect, all emphasized sections within or
     * outside 'H1' will turn red. Probably, one wanted only 'EM' elements within
     * 'H1' to turn red and this can be specified with:
     *
     *   <PRE>
     *   H1 EM { color: red }
     * </PRE>
     *
     * <P> The selector is now a search pattern on the stack of open elements, and
     * this type of selector is referred to as a <EM>contextual
     * selector</EM>. Contextual selectors consist of several simple selectors
     * separated by whitespace (all selectors described up to now have been simple
     * selectors). Only elements that match the last simple selector (in this case
     * the 'EM' element) are addressed, and only if the search pattern
     * matches. Contextual selectors in CSS1 look for ancestor relationships, but
     * other relationships (e.g. parent-child) may be introduced in later
     * revisions. In the example above, the search pattern matches if 'EM' is a
     * descendant of 'H1', i.e. if 'EM' is inside an 'H1' element.
     *
     *   <PRE>
     *   UL LI    { font-size: small }    
     *   UL UL LI { font-size: x-small }
     * </PRE>
     *
     * <P> Here, the first selector matches 'LI' elements with at least one 'UL'
     * ancestor.  The second selector matches a subset of the first, i.e. 'LI'
     * elements with at least two 'UL' ancestors. The conflict is resolved by the
     * second selector being more specific because of the longer search
     * pattern. See the <A HREF="#cascading-order">cascading order (section
     * 3.2)</A> for more on this.
     *
     * <P> Contextual selectors can look for element types, CLASS attributes, ID
     * attributes or combinations of these:
     *
     *   <PRE>
     *   DIV P           { font: small sans-serif }
     *   .reddish H1     { color: red }
     *   #x78y CODE      { background: blue }
     *   DIV.sidenote H1 { font-size: large }
     * </PRE>
     *
     * <P> The first selector matches all 'P' elements that have a 'DIV' among the
     * ancestors. The second selector matches matches all 'H1' elements that have
     * an ancestor of class 'reddish'. The third selector matches all 'CODE'
     * elements that are descendants of the element with 'ID=x78y'. The fourth
     * selector matches all 'H1' elements that have a 'DIV' ancestor with class
     * 'sidenote'.  
     */
    protected CssSelectors next;
    
    // the specificity
    private int specificity;
    
    // true if the element is a block-level element
    private  boolean isBlock;
    
    CssStyle properties;
    
    // all hashCode (for performance)
    private int hashElement; 
    private int hashClasse; 
    private int hashId; 
    private int hashPseudoClass;
    private int hashPseudoElement; 
    
    private int hashGeneral;
    
    // External representation of the selector
    // (for performance)
    private String representation;
    
    // The CssStyle to use
    private static Class style;
    
    /**
     * Create a new CssSelectors with no previous selector.
     */
    public CssSelectors() {
	try {
	    properties = (CssStyle) style.newInstance();
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }  
    
    /**
     * Create a new CssSelectors with a previous selector.
     *
     * @param next the next selector
     */
    public CssSelectors(CssSelectors next) {
	this();
	this.next = next;
    }  
    
    /**
     * Set the style for all contexts.
     * Don't forget to invoke this method if you want a style !
     * 
     * @param style0 the style
     */  
    public static void setStyle(Class style0) {
	Util.verbose("Style is : " + style0);
	style = style0;
    }
    
    /**
     * Set the element.
     * Be careful, you should work with upper case not lower case
     * (it's more practical)
     *
     * @param element the element.
     */
    public void setElement(String element) {
	if (element == null)
	    return;
	this.element = element;
	hashElement = element.hashCode();
	verifyPseudoElement(null);
	Invalidate();
    }
    
    /**
     * Set the element with verification.
     * Be careful, you should work with upper case not lower case
     * (it's more practical)
     *
     * @param element the element.
     * @param frame   For errors and warnings.
     */
    public void setElement(String element, Frame frame) {
	if (element == null)
	    return;
	String isHTMLBlock = elements.getProperty(element);
	if (isHTMLBlock  == null) {
	    frame.addWarning("unknown-html", element);
	}
	//  else if (isHTMLBlock.equals("true")) {
	//       isBlock = true;
	//       if (next != null && !next.isBlock)
	// 	frame.addWarning("noinside", element);
	//     }
	this.element = element;
	hashElement = element.hashCode();
	if (hashElement == HTMLCode && next != null) {
	    frame.addWarning("html-inside");
	} else if (hashElement == BODYCode && next != null && 
		   next.hashElement != 0 && next.hashElement != HTMLCode) {
	    frame.addWarning("body-inside");
	}
	
	verifyPseudoElement(frame);
	Invalidate();
    }
    
    /**
     * Get the element.
     */
    public String getElement() {
	return element;
    }
    
    /*
      here, you probably have a question :
      
      Why classe and not class ?
      
      because getClass exists in Object :-(
    */
    
    
    /**
     * Adds a class.
     *
     * <p>
     * Be careful, multiple classes are not supported for the moment.
     *
     * @param classe The class.
     */
    public void addClasse(String classe) {
	if (classe == null)
	    return;

	this.classe.addElement(classe);
	// @@ for the moment, it works only with one class :-) ... */
	if (hashClasse == 0) hashClasse = classe.hashCode();
	verifyPseudoElement(null);
	Invalidate();
    }
    
    /**
     * Adds a class with verification.
     *
     * <p>
     * Be careful, multiple classes are not supported for the moment.
     *
     * @param classe The class.
     * @param frame  For errors and warnings.
     */
    public void addClasse(String classe, Frame frame) {
	if (classe == null)
	    return;

	this.classe.addElement(classe);
	// @@ for the moment, it works only with one class :-) ... */
	if (hashClasse == 0) {
	    hashClasse = classe.hashCode();
	}
	verifyPseudoElement(frame);
	Invalidate();
    }
    
    /**
     * Get the all classes.
     */
    public Vector getClasse() {
	return classe;
    }
    
    /**
     * Get the first class.
     *
     * <p> There is no dot at the beginning of the string.
     */
    public String getFirstClasse() {
	if (classe.size() == 0)
	    return null;
	return (String) classe.firstElement();
    }
    
    /**
     * Set the id.
     *
     * @param id The id.
     */
    public void setId(String id) {
	if (id == null)
	    return;
	this.id = id;
	hashId = this.id.hashCode();
	verifyPseudoElement(null);
	Invalidate();
    }
    
    /**
     * Set the id with verification.
     *
     * @param id    The id.
     * @param frame For errors and warnings.
     */
    public void setId(String id, Frame frame) {
	if (id == null)
	    return;
	this.id = id;
	hashId = this.id.hashCode();
	verifyPseudoElement(frame);
	Invalidate();
    }
    
    /**
     * get the id.
     *
     * <p> There is no '#' at the beginning of the string.
     */
    public String getId() {
	return id;
    }
    
    public void setPseudo(String pseudo) {
	int i;
	if (pseudo == null)
	    return;
	for (i = 0; i < pseudoClassConstants.length; i++) {
	    if (pseudoClassConstants[i].equals(pseudo)) {
		setPseudoClass(pseudo);
		return;
	    }
	}
	for (i = 0; i < pseudoElementConstants.length; i++) {
	    if (pseudoElementConstants[i].equals(pseudo)) {
		setPseudoElement(pseudo);
		return;
	    }
	}
    }
    
    public void setPseudo(String pseudo, Frame frame) {
	int i;
	if (pseudo == null)
	    return;	
	for (i = 0; i < pseudoClassConstants.length; i++) {
	    if (pseudoClassConstants[i].equals(pseudo)) {
		setPseudoClass(pseudo, frame);
		return;
	    }
	}
	for (i = 0; i < pseudoElementConstants.length; i++) {
	    if (pseudoElementConstants[i].equals(pseudo)) {
		setPseudoElement(pseudo, frame);
		return;
	    }
	}
	CssErrorToken e = new CssErrorToken(0, 
					    Messages.getErrorString("pseudo"), 
					    new String[0]);
	e.skippedString = pseudo;
	frame.addError(e);
    }
    
    /**
     * Set the pseudoClass.
     *
     * Be careful, you should work with lower case not upper case
     * (it's more practical)
     *
     * @param pseudoClass The pseudo class.
     * @deprecated
     */
    public void setPseudoClass(String pseudoClass) {
	if (pseudoClass == null)
	    return;
	
	this.pseudoClass = pseudoClass;
	hashPseudoClass = pseudoClass.hashCode();
	if (element == null)
	    element = "A";
	verifyPseudoElement(null);
	verifyPseudoClass(null);
	Invalidate();
    }
    
    /**
     * Set the pseudoClass with verification.
     *
     * Be careful, you should work with lower case not upper case
     * (it's more practical)
     *
     * @param pseudoClass The pseudo class.
     * @param frame       For errors and warnings.
     * @deprecated
     */
    public void setPseudoClass(String pseudoClass, Frame frame) {
	if (pseudoClass == null)
	    return;
	
	this.pseudoClass = pseudoClass;
	hashPseudoClass = pseudoClass.hashCode();
	if (element == null)
	    element = "A";
	verifyPseudoElement(frame);
	verifyPseudoClass(frame);
	Invalidate();
	if (element != null && !element.equals("A")) {
	    frame.addWarning("pseudo-classes");
	}
    }
    
    /**
     * Get the pseudoClass.
     *
     * <p> There is no semi-colon at the beginning of the string.
     */
    public String getPseudoClass() {
	return pseudoClass;
    }
    
    /**
     * Set the pseudoElement.
     * Be careful, you should work with lower case not upper case
     * (it's more practical)
     *
     * @param pseudoElement the pseudo element
     * @deprecated
     */
    public void setPseudoElement(String pseudoElement) {
	if (pseudoElement == null)
	    return;
	
	this.pseudoElement = pseudoElement;
	hashPseudoElement = pseudoElement.hashCode();
	verifyPseudoElement(null);
	Invalidate();
    }
    
    /**
     * Set the pseudoElement.
     * Be careful, you should work with lower case not upper case
     * (it's more practical)
     *
     * @param pseudoElement the pseudo element
     * @param frame         For errors and warnings.
     * @deprecated
     */
    public void setPseudoElement(String pseudoElement, Frame frame) {
	//     if (!isBlock) {
	//       frame.addWarning("withblock");
	//     }
	
	if (pseudoElement == null)
	    return;
	
	this.pseudoElement = pseudoElement;
	hashPseudoElement = pseudoElement.hashCode();
	verifyPseudoElement(frame);
	Invalidate();
    }
    
    
    
    /**
     * Get the pseudoElement.
     *
     * <p> There is no semi-colon at the beginning of the string.
     */
    public String getPseudoElement() {
	return pseudoElement;
    }
    
    /**
     * Adds a property to this selector.
     *
     * @param property The property.
     * @param warnings For warning report.
     */  
    public void addProperty(CssProperty property, Warnings warnings) {
	Init = true;
	if (properties != null) {
	    properties.setProperty(property, warnings);
	} else {
	    System.out.println("Invalid state in CSS.Parser.CssSelectors#addProperty");
	}
    }
    
    public CssStyle getStyle() {
	return properties;
    }
    
    /**
     * Get the specificity of this selector.
     *
     * @see CssContextualSelector
     */  
    public int getSpecificity() {
	
	if (specificity == 0) {
	    // compute the specificity
	    if (next != null)
		specificity = next.getSpecificity();
	    if (element != null)
		specificity += 1;
	    if (hashClasse != 0)
		specificity += 10;
	    if (id != null)
		specificity += 100;
	    if (pseudoClass != null)
		specificity += 10;
	    if (pseudoElement != null)
		specificity += 1;
	}
	
	return specificity;
    }
    
    /**
     * Returns a string representation of the object.
     */
    public String toString() {
	if (representation == null) {
	    representation = "";
	    int size = classe.size();
	    
	    // I'm in reverse order, so compute the next before the current
	    if (next != null)
		representation += next + " ";
	    
	    if (element != null)
		representation += element;
	    
	    if (id != null)
		representation += "#" + id;
	    
	    switch (size) {
	    case 0:
		break;
	    case 1:
		representation += "." + (String) classe.firstElement();
		break;
	    default:
		return "SORRY, MULTIPLE CLASSES ARE NOT SUPPORTED";
	    }
	    if (pseudoClass != null)
		representation += ":" + pseudoClass;
	    if (pseudoElement != null)
		representation += ":" + pseudoElement;
	}
	
	return representation;
    }
    
    /**
     * Get a hashCode.
     */  
    public int hashCode() {
	if (hashGeneral == 0) {
	    String s = toString();
	    hashGeneral = s.hashCode();
	    for (int i = 0; i < s.length(); i++) {
		hashGeneral += (int) s.charAt(i);
	    }
	}
	return hashGeneral;
    }
    
    /**
     * Returns <code>true</code> if the selector is equals to an another.
     *
     * @param selector The selector to compare
     */
    public boolean equals(Object selector) {
	if (selector == null || !(selector instanceof CssSelectors))
	    return false;
	return hashCode() == ((CssSelectors) selector).hashCode();
    }
    
    /**
     * Set the previous selector.
     *
     * @param next the previous selector.
     */  
    public void setNext(CssSelectors next) {
	this.next = next;
	verifyPseudoElement(null);
	Invalidate();
    }
    
    /**
     * Get the previous selector.
     */  
    public CssSelectors getNext() {
	return next;
    }
    
    /**
     * Returns <code>true</code> if the selector can matched this selector.
     *
     * <p>Examples:<br>
     * <OL>
     * <LI><code>H1.canApply(HTML BODY H1)</code> returns <code>true</code>
     * <LI><code>H1.canApply(HTML BODY H1 EM)</code> returns <code>false</code>
     * <LI><code>(H1 EM).canApply(HTML BODY H2 EM)</code> returns 
     *     <code>false</code>
     * <LI><code>(HTML EM).canApply(HTML BODY H2 EM)</code> returns 
     *     <code>true</code>
     * </OL>
     *
     * <p> Note:<BR>
     * In principle, if you work with a HTML document, your selector should
     * start with HTML BODY. Because you are always in this context when you
     * parse the text in a HTML document.
     *
     * @param selector the selector to match
     * @see            CSS.CSS.CssCascadingOrder#order
     */  
    public boolean canApply(CssSelectors selector) {
	if (((hashElement != selector.hashElement) && hashElement != 0) ||
	    ((hashClasse != selector.hashClasse) && hashClasse != 0) ||
	    ((hashId != selector.hashId) && hashId != 0) ||
	    ((hashPseudoClass != selector.hashPseudoClass) && 
	     hashPseudoClass != 0) ||
	    ((hashPseudoElement != selector.hashPseudoElement) && 
	     hashPseudoElement != 0)) {
	    // here we are in this case :
	    // H1 and HTML BODY H1 EM
	    // don't do anything !
	    // the cascading order algorithm resolves this case like this :
	    // 
	    // if (for all contexts) !canApply(selector) 
	    //       go and see canApply(selector.getNext())
	    //
	    // for further informations, see CSS.CSS.CssCascadingOrder#order
	    return false;
	} else {
	    if (next == null || selector.next == null) {
		return true;
	    } else {
		return next.canMatched(selector.next);
	    }
	}
    }
    
    /**
     * Returns true if the selector can matched an another selector.
     * called by canApply
     *
     * @param selector The selector to compare
     */
    private boolean canMatched(CssSelectors selector) {
	if (((hashElement != selector.hashElement) && hashElement != 0) ||
	    ((hashClasse != selector.hashClasse) && hashClasse != 0) ||
	    ((hashId != selector.hashId) && hashId != 0) ||
	    ((hashPseudoClass != selector.hashPseudoClass) && 
	     hashPseudoClass != 0) ||
	    ((hashPseudoElement != selector.hashPseudoElement) && 
	     hashPseudoElement != 0)) {
	    if (selector.next != null) {
		// here we are in this case :
		// H1 and HTML BODY H1 EM
		// H1 can't matched EM but EM have next
		return canMatched(selector.next);
	    } else {
		// here we are in this case :
		// H1 and HTML
		// H1 can't matched HTML and HTML don't have next
		return false; 
	    }
	}
	
	if (next == null || selector.next == null) {
	    // here we are in this case :
	    // H1 and BODY HTML H1
	    // or :
	    // HTML BODY and BODY (this case won't appear in principle)
	    return true;
	} else {
	    // here we are in this case :
	    // BODY H1 and HTML BODY H1
	    return next.canMatched(selector.next);
	}
    }
    
    /**
     * Returns <code>true</code> if there is no property in this document.
     */  
    public boolean isEmpty() {
	return !Init;
    }
    
    void verifyPseudoElement(Frame frame) {
	if (next != null && next.pseudoElement != null) {
	    // eliminate this error
	    if (frame != null) {
		InvalidParamException error = 
		    new InvalidParamException("pseudo-element", 
					      next.pseudoElement,
					      this.toString());
		frame.addError(new CssError(error));
	    }
	    next.pseudoElement = null;
	    next.verifyPseudoElement(frame);
	    next.Invalidate();
	}
    }
    
    void verifyPseudoClass(Frame frame) {
	if (next != null && next.pseudoClass != null) {
	    // eliminate this error
	    if (frame != null) {
		InvalidParamException error = 
		    new InvalidParamException("pseudo-class", 
					      next.pseudoClass,
					      this.toString());
		frame.addError(new CssError(error));
	    }
	    next.pseudoClass = null;
	    next.verifyPseudoClass(frame);
	    next.Invalidate();
	}
    }
    
    void Invalidate() {
	// invalidate all pre-computation in this selectors
	representation = null;
	specificity = 0;
	hashGeneral = 0;
	
	if (Init) {
	    // yes I invalidate all properties too !
	    try {
		properties = (CssStyle) style.newInstance();
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}
    }
    
    // see isEmpty and addProperty
    private boolean Init;
    
    // all HTML element in HTML 4.0
    private static Properties elements = new Properties();
    
    // special (?) HTML tag
    private static final int HTMLCode = "HTML".hashCode();
    private static final int BODYCode = "BODY".hashCode();
    
    static {
	try {
	    URL url = CssSelectors.class.getResource("Elements.dtd4");
	    java.io.InputStream f = url.openStream();
	    try {
		elements.load(f);
	    } finally {
		f.close();
	    }
	} catch (Exception e) {
	    System.err.println("CSS.Properties.CssSelectors: couldn't load properties");
	    System.err.println("  " + e.toString() );
	}
    }
}
