/*
 * $Log$
 */
package CSS.Parser;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.io.InputStream;
import java.io.IOException;
import java.util.Properties;

import CSS.Properties.CssProperty;
import CSS.Values.CssExpression;
import CSS.util.InvalidParamException;

/**
 * @version $Revision$
 * @author  Philippe Le H�garet
 */
public class CssPropertyFactory {

    // all recognized properties are here.
    private static Properties properties;

    /**
     * Create a new CssPropertyFactory
     */
    public CssPropertyFactory(URL url) {
	properties = new Properties();
	InputStream f = null;
	try {
	    f = url.openStream();
	    properties.load(f);
	} catch (IOException e) {
	    e.printStackTrace();
	} finally {
	    try {
		if (f != null) 
		    f.close();
	    } catch (Exception e) {
		e.printStackTrace();
	    } // ignore
	}
    }

    public String getProperty(String name) {
	return properties.getProperty(name);
    }

    public synchronized CssProperty createProperty(String property, 
						   CssExpression expression) 
	    throws Exception {
	
	String classname = properties.getProperty(property);
	CssProperty prop = null;
	
	if (classname == null) {
	    // I don't know this property
	    throw new InvalidParamException("noexistence", property);
	}

	try {
	    // create an instance of your property class
	    Class[] parametersType = { expression.getClass() };
	    Constructor constructor = 
		Class.forName(classname).getConstructor(parametersType);
	    Object[] parameters = { expression };
	    // invoke the constructor
	    return (CssProperty) constructor.newInstance(parameters);
	} catch (InvocationTargetException e) {
	    // catch InvalidParamException
	    InvocationTargetException iv = e;
	    Exception ex = (Exception) iv.getTargetException();
	    throw ex;
	}
    }
}
