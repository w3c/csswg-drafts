/*
 * $Log$
 */
package CSS.Parser;

import java.util.Vector;
import CSS.Parser.Analyzer.ParseException;

/**
 * @version $Revision$
 */
public class CssParseException extends ParseException {

  /**
   * The list of context when the error appears
   */  
  public Vector contexts;

  /**
   * the property name
   */  
  public String property;

  private boolean error;

  /**
   * the skipped text
   */  
  public String skippedString;

  /**
   * The real exception
   */
  ParseException parseException;

  /**
   * Create a new CssParseException
   */
  public CssParseException(ParseException e) {
    parseException = e;
    error = (e.currentToken != null && e.expectedTokenSequences != null &&
	     e.tokenImage != null);
  }  

  /**
   * Get contexts
   */
  public Vector getContexts() {
    return contexts;
  }

  /**
   * Get the name of the property.
   */  
  public String getPropertyName() {
    return property;
  }

  /**
   * Get the skipped text.
   */  
  public String getSkippedString() {
    return skippedString;
  }

  /**
   * Get the exception message
   */  
  public String getMessage() {
    if (!error) {
      return parseException.getMessage();
    } else {
      return null;
    }
  }

}
