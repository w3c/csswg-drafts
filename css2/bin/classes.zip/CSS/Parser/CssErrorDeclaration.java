/*
 * $Log: CssErrorDeclaration.java,v $
 * Revision 2.1  1997/08/08 15:50:51  plehegar
 * Freeze
 *
 * Revision 1.4  1997/07/30 13:20:32  plehegar
 * Updated package
 *
 * Revision 1.3  1997/07/21 22:23:32  plehegar
 * Updated
 *
 * Revision 1.2  1997/07/21 14:58:47  plehegar
 * Updated
 *
 * Revision 1.1  1997/07/21 14:36:30  plehegar
 * Initial revision
 *
 */
package CSS.Parser;

import CSS.Values.CssExpression;

/**
 * @version $Revision: 2.1 $
 */
public class CssErrorDeclaration extends CssError {

  /**
   * the property name
   */  
  String property;

  /**
   * The expression
   */  
  CssExpression expression;
  
  /**
   * Create a new CssErrorDeclaration. This type of errors are create by
   * handleDeclaration.
   *
   * @param prop The name of the property
   * @param val The expression
   * @param message The exception 
   */
  protected CssErrorDeclaration(String prop, 
				CssExpression expr, 
				Exception message) {
    property = prop;
    expression = expr;
    error = message;
  }

  /**
   * Get the property name.
   */  
  public String getPropertyName() {
    return property;
  }

  /**
   * Get the expression
   */
  public CssExpression getExpression() {
    return expression;
  }
}
