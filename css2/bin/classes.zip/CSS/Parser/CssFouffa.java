/*
 * $Log: CssFouffa.java,v $
 * Revision 2.2  1998/02/07 14:06:27  plehegar
 * *** empty log message ***
 *
 * Revision 2.1  1997/08/29 13:08:03  plehegar
 * Updated
 *
 * Revision 1.1  1997/07/15 13:07:24  plehegar
 * Initial revision
 *
 */

package CSS.Parser;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
// import w3c.www.protocol.http.HttpURLConnection;
import java.net.MalformedURLException;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Properties;

import CSS.Properties.CssProperty;
import CSS.Parser.Analyzer.CssParser;
import CSS.Parser.Analyzer.ParseError;
import CSS.Parser.Analyzer.ParseException;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.util.InvalidParamException;
import CSS.util.Util;

/**
 * This class is a front end of the CSS1 parser.
 * 
 * <p> Example:<br>
 * <code>
 * CssFouffa parser = 
 *   new CssFouffa(new URL("http://www.w3.org/drafts.css"));<BR>
 * CssValidatorListener myListener = new MyParserListener();<BR>
 * <BR>
 * parser.addListener(myListener);<BR>
 * parser.parseStyle();<BR>
 * </code>
 *
 * @version $Revision: 2.2 $
 */
public final class CssFouffa extends CssParser {
    
    // all properties
    static CssPropertyFactory properties;
    // all listeners
    Vector listeners;
    // all errors
    Errors errors;
    
    /**
     * Create a new CssFouffa with a data input and a begin line number.
     *
     * @param input     data input
     * @param file      The source file (use for errors, warnings and import)
     * @param beginLine The begin line number in the file.
     *                  (used for HTML for example)
     * @exception       IOException  if an I/O error occurs.
     */
    public CssFouffa(InputStream input, URL file, int beginLine)
	throws IOException {
	
	super(input);

	setFrame(new Frame(this, file.toString(), beginLine));
	setURL(file);
	listeners = new Vector();
    }
    
    /**
     * Create a new CssFouffa with a data input.
     *
     * @param input data input
     * @param file  The source file (use for errors, warnings and import)
     * @exception   IOException  if an I/O error occurs.
     */
    public CssFouffa(InputStream input, URL file) throws IOException {
	this(input, file, 0);
    }
    
    /**
     * Create a new CssFouffa.
     *
     * @param file  The source file 
     *              (use for data input, errors, warnings and import)
     * @exception   IOException  if an I/O error occurs.
     */
    public CssFouffa(URL file) throws IOException {
	this(file.openStream(), file, 0);
    }
    
    /**
     * Create a new CssFouffa. Used by handleImport.
     *
     * @param file      The source file 
     *                  (use for data input, errors, warnings and import)
     * @param listeners Works with this listeners
     * @exception       IOException  if an I/O error occurs.
     */
    private CssFouffa(URL url, Vector listeners) throws IOException {
	this(url.openStream(), url);
	
	setURL(url);
	setFrame(new Frame(this, url.toString()));
	this.listeners = listeners;
    }
    
    private void ReInit(InputStream input, URL file, Frame frame) {
	// reinitialize the parser with a new data input
	// and a new frame for errors and warnings
	super.ReInit(input, frame);

	setURL(file);
    }
    
    /**
     * Reinitializes a new CssFouffa with a data input and a begin line number.
     *
     * @param input     data input
     * @param file      The source file (use for errors, warnings and import)
     * @param beginLine The begin line number in the file.
     *                  (used for HTML for example)
     * @exception       IOException  if an I/O error occurs.
     */
    public void ReInit(InputStream input, URL file, int beginLine) 
	throws IOException {
	
	ReInit(input, file, new Frame(this, file.toString(), beginLine));
    }
    
    /**
     * Reinitializes a new CssFouffa with a data input.
     *
     * @param input     data input
     * @param file      The source file (use for errors, warnings and import)
     * @exception       IOException  if an I/O error occurs.
     */
    public void ReInit(InputStream input, URL file) throws IOException {
	ReInit(input, file, new Frame(this, file.toString()));
    }
    
    /**
     * Reinitializes a new CssFouffa.
     *
     * @param file  The source file 
     *              (use for data input, errors, warnings and import)
     * @exception   IOException  if an I/O error occurs.
     */
    public void ReInit(URL file) throws IOException {
	ReInit(file.openStream(), file, new Frame(this, file.toString()));
    }
    
    /**
     * Adds a listener to the parser.
     *
     * @param listener The listener
     * @see            CSS.Parser.CssValidatorListener
     */  
    public void addListener(CssValidatorListener listener) {
	listeners.addElement(listener);
    }
    
    /**
     * Removes a listener from the parser
     *
     * @param listener The listener
     * @see            CSS.Parser.CssValidatorListener
     */  
    public void removeListener(CssValidatorListener listener) {
	listeners.removeElement(listener);
    }
    
    /**
     * Parse the style sheet. This is the main function of this parser.
     *
     * <p> Example:<br>
     * <code>
     * CssFouffa parser = new CssFouffa(new URL("http://www.w3.org/drafts.css"));<BR>
     * CssValidatorListener myListener = new MyParserListener();<BR>
     * <BR>
     * parser.addListener(myListener);<BR>
     * parser.parseStyle();<BR>
     * </code>
     * @see            CSS.Parser.CssFouffa#addListener
     */  
    public void parseStyle() {
	try {
	    parserUnit();
	} catch (Exception e) {
	    e.printStackTrace();
	}
	
	// That's all folks, notify all errors and warnings
	for (Enumeration e = listeners.elements(); e.hasMoreElements();) {
	    CssValidatorListener listener = (CssValidatorListener) e.nextElement();
	    listener.notifyErrors(frame.getErrors());
	    listener.notifyWarnings(frame.getWarnings());
	}
    }
    
    /**
     * Call by the import statement.
     *
     * @param url  The style sheet where this import statement appears.
     * @param file the file name in the import statement
     */  
    public void handleImport(URL url, String file) {
	CssError cssError = null;
	
	try {
	    if (Util.importSecurity) {
		throw new FileNotFoundException("[SECURITY] You can't import URL sorry.");
	    }
	    
	    URL importedURL = new URL(url, file);
	    URLConnection importURL = importedURL.openConnection();
	    if (Util.servlet && !(importURL instanceof HttpURLConnection)) {
		System.out.println( "[WARNING] : someone is trying to get the file : " + 
				    file );
		throw new FileNotFoundException("import " + file + 
						": Operation not permitted");
	    }
	    Util.verbose("Trying to load " + importURL.getURL());
	    importURL.connect();
	    if (importURL instanceof HttpURLConnection) {
		HttpURLConnection httpURL = (HttpURLConnection) importURL;
		if (httpURL.getResponseCode() != HttpURLConnection.HTTP_OK) {
		    throw new FileNotFoundException(importURL.getURL() + ": " +
						    httpURL.getResponseMessage());
		}
		if (httpURL.getContentType().toLowerCase().indexOf("text/html") != -1) {
		    throw new FileNotFoundException(importURL.getURL() + 
						    ": You can't import an HTML document");
		}
	    }
	    try {
		importURL.getInputStream().close();
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	    CssFouffa cssFouffa = new CssFouffa(importedURL, listeners);
	    cssFouffa.parseStyle();
	} catch (Exception e) {
	    frame.addError(new CssError(e));
	}
    }
    
    /**
     * Call by the at-rule statement.
     *
     * @param ident The ident for this at-rule (for example: 'font-face')
     * @param string The string representation of this at-rule
     */  
    public void handleAtRule(String ident, String string) {
	if (mode) {
	    for (Enumeration e = listeners.elements(); e.hasMoreElements();) {
		CssValidatorListener listener = 
		    (CssValidatorListener) e.nextElement();
		listener.handleAtRule(ident, string);
	    }
	} else {
	    // only @import <string>; or @import <url>; are valids in CSS1
	    ParseException error = 
		new ParseException("at-rules are not implemented in CSS1");
	    frame.addError(new CssError(error));
	}
    }
    
    /**
     * Assign an expression to a property.  This function create a new property
     * with <code>property</code> and assign to it the expression with the
     * importance.
     *
     * @param  property   the name of the property
     * @param  expression The expression representation of expression
     * @param  important  true if expression id important
     * @return            null or a CssProperty 
     */
    public CssProperty handleDeclaration(String property, 
					 CssExpression expression, 
					 boolean important) {
	
	CssProperty prop = null;

	try {
	    prop = properties.createProperty(property, expression);
	    // set the importance
	    if (important) prop.setImportant();
	    // set informations for errors and warnings
	    prop.setInfo(frame.getLine(), frame.getSourceFile());
	    // Did the property recognize all values in the expression ?
	    if (!expression.end()) {
		throw new InvalidParamException("unrecognize", "");
	    } else {
		// ok, return the new property
		return prop;
	    }
	} catch (Exception e) {
	    // reset the expression for display
	    expression.starts();
	    
	    // create a new CssError
	    CssErrorDeclaration cssErrorDeclaration = 
		new CssErrorDeclaration(property, expression, e);
	    cssErrorDeclaration.sourceFile = getSourceFile();
	    cssErrorDeclaration.line = getLine();
	    
	    // add it
	    frame.addError(cssErrorDeclaration);
	    
	    return null;
	}
    }
    
    /**
     * Parse only a list of declarations. This is useful to parse the
     * <code>STYLE</code> attribute in a HTML document.
     *
     * <p> Example:<br>
     * <code>
     * CssFouffa parser = 
     *    new CssFouffa(new URL("http://www.w3.org/drafts.css"));<BR>
     * CssValidatorListener myListener = new MyParserListener();<BR>
     * CssSelector selector = new CssSelector();
     * selector.setElement("H1");
     * <BR>
     * parser.addListener(myListener);<BR>
     * parser.parseDeclarations(selector);<BR>
     * </code>
     *
     * @param context The current context 
     * @see           CSS.Parser.CssFouffa#addListener
     * @see           CSS.Parser.CssSelectors#setElement
     */
    public void parseDeclarations(CssSelectors context) {
	// here we have an example for reusing the parser.
	try {
	    Vector properties = declarations();
	    
	    if (properties.size() != 0) {
		handleRule(context, properties);
	    }
	} catch (ParseException e) {
	    System.out.println( "Parser exception" );
	    CssParseException ex = new CssParseException(e);
	    ex.skippedString = "";
	    ex.property = currentProperty;
	    ex.contexts = currentContext;
	    CssError error = new CssError(getSourceFile(), getLine(), ex);
	    frame.addError(error);
	}
	
	for (Enumeration e = listeners.elements(); e.hasMoreElements();) {
	    CssValidatorListener listener = 
		(CssValidatorListener) e.nextElement();
	    listener.notifyErrors(frame.getErrors());
	    listener.notifyWarnings(frame.getWarnings());
	}
    }
    
    /**
     * Adds a vector of properties to a selector.
     *
     * @param selector     the selector
     * @param declarations Properties to associate with contexts
     */  
    public void handleRule(CssSelectors selector, Vector declarations) {
	for (Enumeration e = listeners.elements(); e.hasMoreElements();) {
	    ((CssValidatorListener) e.nextElement()).handleRule(selector, 
								declarations);
	}
    }
    
    /**
     * Return the class name for a property
     *
     * @param  property the property name ('font-size' for example)
     * @return          the class name ('CSS.Properties.CssFontSize' for example)
     */  
    public static String getProperty(String property) {
	return properties.getProperty(property);
    }
    
    /**
     * Set the style
     */
    public static void setStyle(Class style) {
	CssSelectors.setStyle(style);
    }
    
    /**
     * If you want to parse aural values and properties, invoke this method.
     * Don't use this method !
     *
     * Please invoke this class like this :<BR>
     *  <code>CssFouffa.loadConfig(YourConfigFile);</code><BR>
     * See also CSS/Parser/Config.properties
     *
     * @deprecated
     * @see #loadConfig
     */  
    public static void setAuralMode() {
	message();
    }
    
    /**
     * If you don't want to parse aural values and properties, invoke this method.
     * The parse, by default, doesn't parse aural values and properties.
     * Don't use this method !
     *
     * Please invoke this class like this :<BR>
     *  <code>CssFouffa.loadConfig(YourConfigFile);</code><BR>
q     * See also CSS/Parser/Config.properties
     *
     * @deprecated
     * @see #loadConfig
     */  
    public static void unsetAuralMode() {
	message();
    }
    
    static void message() {
	System.err.println("CSS.Parser.CssFouffa: InvocationMethodDeprecated");
	System.err.println("Please invoke this class like this :");
	System.err.println(" CssFouffa.loadConfig(YourConfigFile)");
	System.err.println("See also CSS/Parser/Config.properties");
    }
    
    /**
     * Get the parse state.
     *
     * @return <code>true</code> if the parse can take aural values and properties
     *         in input.
     */
    public static boolean inAuralMode() {
	return mode;
    }
    
    /**
     * Load the parser properties configuration.
     *
     * <p>By default, the parser is configure for cascading style sheet 1.
     *
     * <OL>You have three parser properties :
     * <LI> style:      the class name of your CssStyle.
     * <LI> properties: the file name where the parser can find all CSS properties
     *                  names.
     * <LI> extended-parser: <code>true</code> if you want to parse cascading
     *                  style sheet 2. (only aural is implemented for the moment)
     * <OL>
     */
    public static void loadConfig(Properties config) {
	try {
	    // load the CssStyle
	    String classStyle = config.getProperty("style");
	    Class style = Class.forName(classStyle);
	    CssSelectors.setStyle(style);
	    
	    // load properties
	    URL url = style.getResource(config.getProperty("properties"));
	    properties = new CssPropertyFactory(url);
	    
	    // aural mode
	    String mode0 = config.getProperty("extended-parser");
	    if (mode0 != null) {
		mode = mode0.equals("true");
	    }
	    
	} catch (Exception e) {
	    System.err.println("CSS.Parser.CssFouffa: couldn't load the style");
	    e.printStackTrace();
	}
    }
    
    static {
	Properties config = new Properties();
	
	try {
	    URL url = CssFouffa.class.getResource("Config.properties");
	    java.io.InputStream f = url.openStream();
	    config.load(f);
	    f.close();
	    loadConfig(config);
	} catch (Exception e) {
	    System.err.println("CSS.Parser.CssFouffa: couldn't load the config");
	    e.printStackTrace();
	}
    }
}
