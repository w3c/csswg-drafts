/*
 * $Log$
 */
package CSS.Parser;

import java.util.Enumeration;
import CSS.util.Warnings;
import CSS.util.Warning;
import CSS.Properties.CssProperty;
import CSS.CSS.StyleSheet;

/**
 * This class represents a class for one context
 *
 * @version $Revision$
 */
public class CssStyle {

  /**
   * For warnings report.
   */  
  protected Warnings warnings;

  /**
   * The entire style sheet.
   */  
  protected StyleSheet style;

  /**
   * The context of this style.
   */  
  protected CssSelectors selector;
  
  /**
   * Set the context of this style.
   *
   * @param selectors The context.
   */  
  public final void setSelector(CssSelectors selectors) {
      this.selector = selectors;
  }

  /**
   * Set the style sheet of this style.
   *
   * @param style The style sheet.
   */  
  public final void setStyleSheet(StyleSheet style) {
    this.style = style;
  }
    
  /**
   * Add a warning definition to this style.
   *
   * @param property The property.
   */  
  public final void addRedefinitionWarning(CssProperty property) {
    warnings.addWarning(new Warning(property, "redefinition", 1));
  }

  /**
   * Add a property to this style
   *
   * @param property the property to add
   * @param warnings where to add warnings if required
   */  
  public final void setProperty(CssProperty property, Warnings warnings) {
    this.warnings = warnings;
    property.addToStyle(this);
  }
  
  /**
   * Print this style.
   * Overrides this method to create your own style.
   *
   * @param printer The printer interface.
   */  
  public void print(CssPrinterStyle printer) {
    // nothing to do
  }

  /**
   * Find conflicts in this Style
   *
   * @param warnings For warnings reports.
   * @param allSelectors All contexts is the entire style sheet.
   */
  public void findConflicts(Warnings warnings, Enumeration allSelectors) {
    // nothing to do
  }
}
