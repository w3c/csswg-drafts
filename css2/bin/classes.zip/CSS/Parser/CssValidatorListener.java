/*
 * $Log: CssValidatorListener.java,v $
 * Revision 2.1  1997/08/08 15:50:53  plehegar
 * Freeze
 *
 * Revision 1.2  1997/07/30 13:20:34  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/28 21:35:52  plehegar
 * Initial revision
 *
 */
package CSS.Parser;

import java.util.Vector;

import CSS.util.Warnings;

/**
 * Implements this interface if you want to use the CSS1 parser.
 *
 * @version $Revision: 2.1 $
 */
public interface CssValidatorListener {  

  /**
   * Adds a vector of properties to a selector.
   *
   * @param selector     the selector
   * @param declarations Properties to associate with contexts
   */  
  public void handleRule(CssSelectors selector, Vector declarations);

  /**
   * Handles an at-rule.
   *
   * <p>The parameter <code>value</code> can be :
   * <DL>
   * <DT>CssString
   * <DD>The value coming from a string.
   * <DT>CssURL
   * <DD>The value coming from an URL.
   * <DT>Vector
   * <DD>The value is a vector of declarations (it contains Couple).
   * </DL>
   *
   * @param ident The ident for this at-rule (for example: 'font-face')
   * @param value The string representation of this at-rule
   * @see         CSS.Parser.Analyzer.Couple
   */  
  public void handleAtRule(String ident, String string);

  /**
   * Notify all errors
   *
   * @param errors All errors in the style sheet
   * @see CssError
   * @see CssErrorDeclaration
   * @see CssErrorToken
   */  
  public void notifyErrors(Errors errors);

  /**
   * Notify all warnings
   *
   * @param warnings All warnings in the style sheet
   * @see CSS.util.Warning
   */  
  public void notifyWarnings(Warnings warnings);

}
