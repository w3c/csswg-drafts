/*
 * $Log: CssPrinterStyle.java,v $
 * Revision 1.1  1997/08/20 11:41:28  plehegar
 * Initial revision
 *
 */
package CSS.Parser;

import CSS.Properties.CssProperty;

/**
 * This class is invoke by all propperties when a print is required.
 *
 * @version $Revision: 1.1 $
 * @see CSS.Parser.CssStyle#print
 */
public interface CssPrinterStyle {

  /**
   * Print this property.
   *
   * @param property The property to print.
   * @see CSS.Properties.CssProperty#toString
   * @see CSS.Properties.CssProperty#getPropertyName
   */
  public void print(CssProperty property);
}
