/*
 * $Log$
 */
package CSS.Parser;

/**
 * @version $Revision$
 */
public interface CssSelectorsConstant {

    public static final String[] pseudoClassConstants =
    { 
	"first-child", "link", "active", "visited"
    };

    public static final String[] pseudoElementConstants =
    {
	"before", "after", "first-line", "first-letter"
    };
}
