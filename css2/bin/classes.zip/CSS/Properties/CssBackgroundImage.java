/*
 * $Log: CssBackgroundImage.java,v $
 * Revision 3.1  1997/08/29 13:13:30  plehegar
 * Freeze
 *
 * Revision 2.2  1997/08/20 11:41:13  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:03  plehegar
 * Nothing
 *
 * Revision 1.5  1997/08/06 17:29:48  plehegar
 * Updated set, now it's a constructor
 *
 * Revision 1.4  1997/07/30 13:19:45  plehegar
 * Updated package
 *
 * Revision 1.3  1997/07/23 23:38:35  plehegar
 * bug fix
 *
 * Revision 1.2  1997/07/23 23:34:19  plehegar
 * bug fix "none"
 *
 * Revision 1.1  1997/07/22 17:51:17  plehegar
 * Initial revision
 *
 */

package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.Values.CssURL;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *     &nbsp;&nbsp; 'background-image'
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> &lt;url&gt; | none<BR>
 *   <EM>Initial:</EM> none<BR>
 *   <EM>Applies to:</EM> all elements<BR>
 *   <EM>Inherited:</EM> no<BR>
 *   <EM>Percentage values:</EM> N/A<BR>
 *   <P> This property sets the background image of an element. When setting a
 *   background image, one should also set a background color that will be used
 *   when the image is unavailable. When the image is available, it is overlaid
 *   on top of the background color.
 *   <PRE>
 *   BODY { background-image: url(marble.gif) }
 *   P { background-image: none }
 *   </PRE>
 * @version $Revision: 3.1 $ */
public class CssBackgroundImage extends CssProperty {
  
  CssValue url;

  /**
   * Create a new CssBackgroundImage
   */
  public CssBackgroundImage() {
    url = none;
  }  

  /**
   * Creates a new CssBackgroundImage
   *
   * @param expression The expression for this property
   * @exception InvalidParamException Values are incorrect
   */  
  public CssBackgroundImage(CssExpression expression) 
    throws InvalidParamException {

    CssValue val = expression.getValue();
    if (val instanceof CssURL) {
      url = (CssURL) val;
      expression.next();
    } else if (val.equals(none)) {
      val = none;
      expression.next();
    } else
      throw new InvalidParamException("value", expression.getValue(), 
				      getPropertyName());
  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return url;
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return url.toString();
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "background-image";
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    CssBackground cssBackground = ((Css1Style) style).cssBackground;
    if (cssBackground.image != null)
      style.addRedefinitionWarning(this);
    cssBackground.image = this;
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getBackgroundImage();
    } else {
      return ((Css1Style) style).cssBackground.image;
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof CssBackgroundImage && 
	    url.equals(((CssBackgroundImage) property).url));
  }

  /**
   * Is the value of this property is a default value.
   * It is used by all macro for the function <code>print</code>
   */  
  public boolean isDefault() {
    return url == none;
  }
  
  private static CssIdent none = new CssIdent("none");
}
