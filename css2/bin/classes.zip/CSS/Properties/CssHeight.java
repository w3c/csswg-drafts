/*
 * $Log: CssHeight.java,v $
 * Revision 3.1  1997/08/29 13:13:49  plehegar
 * Freeze
 *
 * Revision 2.2  1997/08/20 11:41:23  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:20  plehegar
 * Nothing
 *
 * Revision 1.4  1997/08/06 17:30:05  plehegar
 * Updated set, now it's a constructor
 *
 * Revision 1.3  1997/07/30 13:20:03  plehegar
 * Updated package
 *
 * Revision 1.2  1997/07/25 15:41:58  plehegar
 * bug fix
 *
 * Revision 1.1  1997/07/25 15:38:12  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssLength;
import CSS.Values.CssNumber;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *      &nbsp;&nbsp; 'height'
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> &lt;length&gt; | auto <BR>
 *   <EM>Initial:</EM> auto<BR>
 *   <EM>Applies to:</EM> block-level and replaced elements<BR>
 *   <EM>Inherited:</EM> no<BR>
 *   <EM>Percentage values:</EM> N/A<BR>
 *   <P>
 *   This property can be applied to text, but it is most useful with replaced
 *   elements such as images. The height is to be enforced by scaling the image
 *   if necessary. When scaling, the aspect ratio of the image is preserved if
 *   the 'width' property is 'auto'.
 *   <P>
 *   Example:
 *   <PRE>
 *   IMG.icon { height: 100px }
 *   </PRE>
 *   <P>
 *   If the 'width' and 'height' of a replaced element are both 'auto', these
 *   properties will be set to the intrinsic dimensions of the element.
 *   <P>
 *   If applied to a textual element, the height can be enforced with e.g. a
 *   scrollbar.
 *   <P>
 *   Negative values are not allowed.
 * @version $Revision: 3.1 $
 */
public class CssHeight extends CssProperty {

  CssValue value;

  /**
   * Create a new CssHeight
   */
  public CssHeight() {
    value = auto;
  }  

  /**
   * Create a new CssHeight
   *
   * @param expression The expression for this property
   * @exception InvalidParamException The expression is incorrect
   */  
  public CssHeight(CssExpression expression) throws InvalidParamException {
    CssValue val = expression.getValue();
    if (val instanceof CssLength) {
      float f = ((Float) val.get()).floatValue();
      if (f < 0)
	throw new InvalidParamException("negative-value", val.toString());
      value = val;
      expression.next();
    } else if (val.equals(auto)) {
      value = auto;
      expression.next();
    } else if (val instanceof CssNumber) {
      value = ((CssNumber) val).getLength();
      expression.next();
    } else {
      throw new InvalidParamException("value", expression.getValue(), 
				      getPropertyName());
    }
    
  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return value;
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "height";
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    Css1Style style0 = (Css1Style) style;
    if (style0.cssHeight != null)
      style0.addRedefinitionWarning(this);
    style0.cssHeight = this;
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getHeight();
    } else {
      return ((Css1Style) style).cssHeight;
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof CssHeight && 
	    value.equals(((CssHeight) property).value));
  }

  /**
   * Is the value of this property is a default value.
   * It is used by all macro for the function <code>print</code>
   */  
  public boolean isDefault() {
    return value == auto;
  }

  private static CssIdent auto = new CssIdent("auto");

}
