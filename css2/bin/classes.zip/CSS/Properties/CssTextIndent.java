/*
 * $Log: CssTextIndent.java,v $
 * Revision 3.1  1997/08/29 13:14:05  plehegar
 * Freeze
 *
 * Revision 2.2  1997/08/20 11:41:29  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:36  plehegar
 * Nothing
 *
 * Revision 1.3  1997/08/06 17:30:22  plehegar
 * Updated set, now it's a constructor
 *
 * Revision 1.2  1997/07/30 13:20:20  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/23 23:06:12  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssPercentage;
import CSS.Values.CssLength;
import CSS.Values.CssNumber;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *     &nbsp;&nbsp; 'text-indent'
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> &lt;length&gt; | &lt;percentage&gt;<BR>
 *   <EM>Initial:</EM> 0<BR>
 *   <EM>Applies to:</EM> block-level elements<BR>
 *   <EM>Inherited:</EM> yes<BR>
 *   <EM>Percentage values:</EM> refer to parent element's width<BR>
 *   <P>
 *   The property specifies the indentation that appears before the first formatted
 *   line. The value of 'text-indent' may be negative, but there may be
 *   implementation-specific limits. An indentation is not inserted in the middle
 *   of an element that was broken by another (such as 'BR' in HTML).
 *   <P>
 *   Example:
 *   <PRE>
 *   P { text-indent: 3em }
 * </PRE>
 * @version $Revision: 3.1 $
 */
public class CssTextIndent extends CssProperty  {

  CssValue value = new CssLength();

  /**
   * Create a new CssTextIndent
   */
  public CssTextIndent() {
  }
  
  /**
   * Create a new CssTextIndent
   *
   * @param expression The expression for this property
   * @exception InvalidParamException Values are incorrect
   */  
  public CssTextIndent(CssExpression expression) throws InvalidParamException {
    CssValue val = expression.getValue();

    if (val instanceof CssLength || val instanceof CssPercentage) {
      value = val;
      expression.next();
    } else if (val instanceof CssNumber) {
      value = ((CssNumber) val).getLength();
      expression.next();
    } else {
      throw new InvalidParamException("value", val.toString(), getPropertyName());
    }

  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return value;
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "text-align";
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    Css1Style style0 = (Css1Style) style;
    if (style0.cssTextIndent != null)
      style0.addRedefinitionWarning(this);
    style0.cssTextIndent = this;
  }
 
  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getTextIndent();
    } else {
      return ((Css1Style) style).cssTextIndent;
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
 public boolean equals(CssProperty property) {
    return (property instanceof CssTextIndent && value.equals(((CssTextIndent) property).value));
  }
}
