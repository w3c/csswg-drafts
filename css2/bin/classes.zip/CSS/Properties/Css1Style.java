/*
 * $Log: Css1Style.java,v $
 * Revision 3.1  1997/08/29 13:14:03  plehegar
 * Freeze
 *
 * Revision 2.4  1997/08/22 14:54:17  plehegar
 * Updated
 *
 * Revision 2.3  1997/08/21 07:27:52  plehegar
 * Added protected
 *
 * Revision 2.2  1997/08/20 11:41:28  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/11 08:05:16  plehegar
 * Freeze
 *
 * Revision 1.4  1997/08/01 00:09:57  plehegar
 * Updated
 *
 * Revision 1.3  1997/07/30 13:18:20  plehegar
 * Updated package
 *
 * Revision 1.2  1997/07/24 11:23:13  plehegar
 * updated
 *
 * Revision 1.1  1997/07/16 15:14:49  plehegar
 * Initial revision
 *
 */

package CSS.Properties;

import java.util.*;

import CSS.Parser.CssSelectors;
import CSS.Parser.CssStyle;
import CSS.Parser.CssPrinterStyle;
import CSS.Values.CssPercentage;
import CSS.Values.CssLength;
import CSS.Values.CssValue;
import CSS.CSS.StyleSheet;
import CSS.util.Warning;
import CSS.util.Warnings;

/**
 * The Css1Style main class.
 * <P>Be careful, I probably change this class for an interface.
 * @version $Revision: 3.1 $
 */
public class Css1Style extends CssStyle {
  
  /** Font properties */
  protected CssFont cssFont = new CssFont();
  
  /* Color and Background properties */
  /** Color property */  
  protected CssColor cssColor;
  /** background properties */  
  protected CssBackground cssBackground = new CssBackground();
  
  /* Text properties */
  /** word-spacing property */  
  protected CssWordSpacing cssWordSpacing;
  /** letter-spacing property */  
  protected CssLetterSpacing cssLetterSpacing;
  /** text-decoration property */  
  protected CssTextDecoration cssTextDecoration;
  /** vertical-align property */  
  protected CssVerticalAlign cssVerticalAlign;
  /** text-transform property */  
  protected CssTextTransform cssTextTransform;
  /** text-align property */  
  protected CssTextAlign cssTextAlign;
  /** text-ident property */  
  protected CssTextIndent cssTextIndent;
  // line-heigth : see cssFont
  
  /* Box properties */
  /** margin properties */  
  protected CssMargin cssMargin = new CssMargin();
  /** padding properties */  
  protected CssPadding cssPadding = new CssPadding();
  /** border properties */  
  protected CssBorder cssBorder = new CssBorder();
  /** width property */  
  protected CssWidth cssWidth;
  /** height property */  
  protected CssHeight cssHeight;
  /** float property */  
  protected CssFloat cssFloat;
  /** clear property */  
  protected CssClear cssClear;
  
  /* Classification properties */
  /** display property */  
  protected CssDisplay cssDisplay;
  /** white-space property */  
  protected CssWhiteSpace cssWhiteSpace;
  /** list-style properties */  
  protected CssListStyle cssListStyle = new CssListStyle();
  
  
  /*
   * Font Properties
   */
  
  /**
   * Get the font-style property
   */  
  public final CssFontStyle getFontStyle() {
    if (cssFont.fontStyle == null) {
      cssFont.fontStyle = 
	(CssFontStyle) style.CascadingOrder(new CssFontStyle(), 
					    style, selector);
    }
    return cssFont.fontStyle;
  }
  
  /**
   * Get the font-variant property
   */  
  public final CssFontVariant getFontVariant() {
    if (cssFont.fontVariant == null) {
      cssFont.fontVariant = 
	(CssFontVariant) style.CascadingOrder(new CssFontVariant(), 
					      style, selector);
    }
    return cssFont.fontVariant;
  }
  
  /**
   * Get the font-weight property
   */  
  public final CssFontWeight getFontWeight() {
    if (cssFont.fontWeight == null) {
      cssFont.fontWeight = 
	(CssFontWeight) style.CascadingOrder(new CssFontWeight(), 
					     style, selector);
    }
    return cssFont.fontWeight;
  }
  
  /**
   * Get the font-size property
   */  
  public final CssFontSize getFontSize() {
    if (cssFont.fontSize == null) {
      cssFont.fontSize = 
	(CssFontSize) style.CascadingOrder(new CssFontSize(), 
					   style, selector);
    }
    return cssFont.fontSize;
  }
  
  /**
   * Get the font-family property
   */
  public final CssFontFamily getFontFamily() {
    if (cssFont.fontFamily == null) {
      cssFont.fontFamily = 
	(CssFontFamily) style.CascadingOrder(new CssFontFamily(), 
					     style, selector);
    }
    return cssFont.fontFamily;
  }
  
  /**
   * Get the font property
   */
  public final CssFont getFont() {
    if (cssFont.fontStyle == null) {
      cssFont.fontStyle = getFontStyle();
    }
    if (cssFont.fontVariant == null) {
      cssFont.fontVariant = getFontVariant();
    }
    if (cssFont.fontWeight == null) {
      cssFont.fontWeight = getFontWeight();
    }
    if (cssFont.fontSize == null) {
      cssFont.fontSize = getFontSize();
    }
    if (cssFont.lineHeight == null) {
      cssFont.lineHeight = getLineHeight();
    }
    if (cssFont.fontFamily == null) {
      cssFont.fontFamily = getFontFamily();
    }
    return cssFont;
  }
  
  /*
   * Color and Background properties
   */
  
  /**
   * Get the color property
   */
  public final CssColor getColor() {
    if (cssColor == null) {
      cssColor = (CssColor) 
	style.CascadingOrder(new CssColor(), style, selector);
    }
    return cssColor;
  }
  
  /**
   * Get the bacground-color property
   */
  public final CssBackgroundColor getBackgroundColor() {
    if (cssBackground.color == null) {
      cssBackground.color = 
	(CssBackgroundColor) style.CascadingOrder(new CssBackgroundColor(), 
						  style, selector);
    }
    return cssBackground.color;
  }
  
  /**
   * Get the bacground-image property
   */
  public final CssBackgroundImage getBackgroundImage() {
    if (cssBackground.image == null) {
      cssBackground.image = 
	(CssBackgroundImage) style.CascadingOrder(new CssBackgroundImage(), 
						  style, selector);
    }
    return cssBackground.image;
  }
  
  /**
   * Get the bacground-repeat property
   */
  public final CssBackgroundRepeat getBackgroundRepeat() {
    if (cssBackground.repeat == null) {
      cssBackground.repeat = 
	(CssBackgroundRepeat) style.CascadingOrder(new CssBackgroundRepeat(), 
						   style, selector);
    }
    return cssBackground.repeat;
  }
  
  /**
   * Get the bacground-attachment property
   */
  public final CssBackgroundAttachment getBackgroundAttachment() {
    if (cssBackground.attachment == null) {
      cssBackground.attachment = 
	(CssBackgroundAttachment) style.CascadingOrder(new CssBackgroundAttachment(), 
						       style, selector);
    }
    return cssBackground.attachment;
  }
  
  /**
   * Get the bacground-position property
   */
  public final CssBackgroundPosition getBackgroundPosition() {
    if (cssBackground.position == null) {
      cssBackground.position = 
	(CssBackgroundPosition) style.CascadingOrder(new CssBackgroundPosition(), 
						     style, selector);
    }
    return cssBackground.position;
  }
  
  /**
   * Get the bacground property
   */
  public final CssBackground getBackground() {
    if (cssBackground.getColor() == null) {
      cssBackground.color = getBackgroundColor();
    }
    if (cssBackground.image == null) {
      cssBackground.image = getBackgroundImage();
    }
    if (cssBackground.repeat == null) {
      cssBackground.repeat = getBackgroundRepeat();
    }
    if (cssBackground.attachment == null) {
      cssBackground.attachment = getBackgroundAttachment();
    }
    if (cssBackground.position == null) {
      cssBackground.position = getBackgroundPosition();
    }
    return cssBackground;
  }
  
  
  /*
   * Text properties
   */  
  
  /**
   * Get the word-spacing property
   */  
  public final CssWordSpacing getWordSpacing() {
    if (cssWordSpacing == null) {
      cssWordSpacing = 
	(CssWordSpacing) style.CascadingOrder(new CssWordSpacing(), 
					      style, selector);
    }
    return cssWordSpacing;
  }
  
  /**
   * Get the letter-spacing property
   */  
  public final CssLetterSpacing getLetterSpacing() {
    if (cssLetterSpacing == null) {
      cssLetterSpacing = 
	(CssLetterSpacing) style.CascadingOrder(new CssLetterSpacing(),
						style, selector);
    }
    return cssLetterSpacing;
  }
  
  /**
   * Get the text-decoration property
   */  
  public final CssTextDecoration getTextDecoration() {
    if (cssTextDecoration == null) {
      cssTextDecoration = 
	(CssTextDecoration) style.CascadingOrder(new CssTextDecoration(),
						 style, selector);
    }
    return cssTextDecoration;
  }
  
  /**
   * Get the vertical-align property
   */  
  public final CssVerticalAlign getVerticalAlign() {
    if (cssVerticalAlign == null) {
      cssVerticalAlign = 
	(CssVerticalAlign) style.CascadingOrder(new CssVerticalAlign(), 
						style, selector);
    }
    return cssVerticalAlign;
  }
  
  /**
   * Get the text-transform property
   */  
  public final CssTextTransform getTextTransform() {
    if (cssTextTransform == null) {
      cssTextTransform = 
	(CssTextTransform) style.CascadingOrder(new CssTextTransform(), 
						style, selector);
    }
    return cssTextTransform;
  }
  
  /**
   * Get the text-align property
   */  
  public final CssTextAlign getTextAlign() {
    if (cssTextAlign == null) {
      cssTextAlign = 
	(CssTextAlign) style.CascadingOrder(new CssTextAlign(), 
					    style, selector);
    }
    return cssTextAlign;
  }
  
  /**
   * Get the text-indent property
   */  
  public final CssTextIndent getTextIndent() {
    if (cssTextIndent == null) {
      cssTextIndent = 
	(CssTextIndent) style.CascadingOrder(new CssTextIndent(), 
					     style, selector);
    }
    return cssTextIndent;
  }
  
  /**
   * Get the line-height property
   */  
  public final CssLineHeight getLineHeight() {
    if (cssFont.lineHeight == null) {
      cssFont.lineHeight = 
	(CssLineHeight) style.CascadingOrder(new CssLineHeight(), 
					     style, selector);
    }
    return cssFont.lineHeight;
  }
  
  /*
   * Box properties
   */  
  
  /**
   * Get the margin-top property
   */  
  public final CssMarginTop getMarginTop() {
    if (cssMargin.top == null) {
      cssMargin.top = 
	(CssMarginTop) style.CascadingOrder(new CssMarginTop(), 
					    style, selector);
    }
    return cssMargin.top;
  }
  
  /**
   * Get the margin-right property
   */  
  public final CssMarginRight getMarginRight() {
    if (cssMargin.right == null) {
      cssMargin.right = 
	(CssMarginRight) style.CascadingOrder(new CssMarginRight(), 
					      style, selector);
    }
    return cssMargin.right;
  }
  
  /**
   * Get the margin-bottom property
   */  
  public final CssMarginBottom getMarginBottom() {
    if (cssMargin.bottom == null) {
      cssMargin.bottom = 
	(CssMarginBottom) style.CascadingOrder(new CssMarginBottom(), 
					       style, selector);
    }
    return cssMargin.bottom;
  }
  
  /**
   * Get the margin-left property
   */  
  public final CssMarginLeft getMarginLeft() {
    if (cssMargin.left == null) {
      cssMargin.left = 
	(CssMarginLeft) style.CascadingOrder(new CssMarginLeft(), 
					     style, selector);
    }
    return cssMargin.left;
  }
  
  /**
   * Get the margin property
   */  
  public final CssMargin getMargin() {
    if (cssMargin.top == null)
      cssMargin.top = getMarginTop();
    if (cssMargin.right == null)
      cssMargin.right = getMarginRight();
    if (cssMargin.bottom == null)
      cssMargin.bottom = getMarginBottom();
    if (cssMargin.left == null)
      cssMargin.left = getMarginLeft();
    return cssMargin;
  }
  
  /**
   * Get the padding-top property
   */  
  public final CssPaddingTop getPaddingTop() {
    if (cssPadding.top == null) {
      cssPadding.top = 
	(CssPaddingTop) style.CascadingOrder(new CssPaddingTop(), 
					     style, selector);
    }
    return cssPadding.top;
  }
  
  /**
   * Get the padding-right property
   */  
  public final CssPaddingRight getPaddingRight() {
    if (cssPadding.right == null) {
      cssPadding.right = 
	(CssPaddingRight) style.CascadingOrder(new CssPaddingRight(), 
					       style, selector);
    }
    return cssPadding.right;
  }
  
  /**
   * Get the padding-bottom property
   */  
  public final CssPaddingBottom getPaddingBottom() {
    if (cssPadding.bottom == null) {
      cssPadding.bottom = 
	(CssPaddingBottom) style.CascadingOrder(new CssPaddingBottom(), 
						style, selector);
    }
    return cssPadding.bottom;
  }
  
  /**
   * Get the padding-left property
   */  
  public final CssPaddingLeft getPaddingLeft() {
    if (cssPadding.left == null) {
      cssPadding.left = 
	(CssPaddingLeft) style.CascadingOrder(new CssPaddingLeft(), 
					      style, selector);
    }
    return cssPadding.left;
  }
  
  /**
   * Get the padding property
   */  
  public final CssPadding getPadding() {
    if (cssPadding.top == null)
      cssPadding.top = getPaddingTop();
    if (cssPadding.right == null)
      cssPadding.right = getPaddingRight();
    if (cssPadding.bottom == null)
      cssPadding.bottom = getPaddingBottom();
    if (cssPadding.left == null)
      cssPadding.left = getPaddingLeft();
    return cssPadding;
  }
  
  /**
   * Get the border-top-width property
   */
  public final CssBorderTopWidth getBorderTopWidth() {
    if (cssBorder.getTop().getWidth() == null) {
      cssBorder.getTop().width = 
	(CssBorderTopWidth) style.CascadingOrder(new CssBorderTopWidth(), 
						 style, selector);
    }
    return cssBorder.getTop().width;
  }
  
  /**
   * Get the border-top-style property
   */
  public final CssBorderTopStyle getBorderTopStyle() {
    if (cssBorder.getTop().getStyle() == null) {
      cssBorder.getTop().style = 
	(CssBorderTopStyle) style.CascadingOrder(new CssBorderTopStyle(), 
						 style, selector);
    }
    return cssBorder.getTop().style;
  }
  
  /**
   * Get the border-top-color property
   */
  public final CssBorderTopColor getBorderTopColor() {
    if (cssBorder.getTop().getColor() == null) {
      cssBorder.getTop().color = 
	(CssBorderTopColor) style.CascadingOrder(new CssBorderTopColor(), 
						 style, selector);
    }
    return cssBorder.getTop().color;
  }
  
  /**
   * Get the border-right-width property
   */
  public final CssBorderRightWidth getBorderRightWidth() {
    if (cssBorder.getRight().getWidth() == null) {
      cssBorder.getRight().width = 
	(CssBorderRightWidth) style.CascadingOrder(new CssBorderRightWidth(), 
						   style, selector);
    }
    return cssBorder.getRight().width;
  }
  
  /**
   * Get the border-right-style property
   */
  public final CssBorderRightStyle getBorderRightStyle() {
    if (cssBorder.getRight().getStyle() == null) {
      cssBorder.getRight().style = 
	(CssBorderRightStyle) style.CascadingOrder(new CssBorderRightStyle(), 
						   style, selector);
    }
    return cssBorder.getRight().style;
  }
  
  /**
   * Get the border-right-color property
   */
  public final CssBorderRightColor getBorderRightColor() {
    if (cssBorder.getRight().getColor() == null) {
      cssBorder.getRight().color = 
	(CssBorderRightColor) style.CascadingOrder(new CssBorderRightColor(), 
						   style, selector);
    }
    return cssBorder.getRight().color;
  }
  
  /**
   * Get the border-bottom-width property
   */
  public final CssBorderBottomWidth getBorderBottomWidth() {
    if (cssBorder.getBottom().getWidth() == null) {
      cssBorder.getBottom().width = 
	(CssBorderBottomWidth) style.CascadingOrder(new CssBorderBottomWidth(), 
						    style, selector);
    }
    return cssBorder.getBottom().width;
  }
  
  /**
   * Get the border-bottom-style property
   */
  public final CssBorderBottomStyle getBorderBottomStyle() {
    if (cssBorder.getBottom().getStyle() == null) {
      cssBorder.getBottom().style = 
	(CssBorderBottomStyle) style.CascadingOrder(new CssBorderBottomStyle(), 
						    style, selector);
    }
    return cssBorder.getBottom().style;
  }
  
  /**
   * Get the border-bottom-color property
   */
  public final CssBorderBottomColor getBorderBottomColor() {
    if (cssBorder.getBottom().getColor() == null) {
      cssBorder.getBottom().color =
	(CssBorderBottomColor) style.CascadingOrder(new CssBorderBottomColor(), 
						    style, selector);
    }
    return cssBorder.getBottom().color;
  }
  
  /**
   * Get the border-left-width property
   */
  public final CssBorderLeftWidth getBorderLeftWidth() {
    if (cssBorder.getLeft().getWidth() == null) {
      cssBorder.getLeft().width = 
	(CssBorderLeftWidth) style.CascadingOrder(new CssBorderLeftWidth(), 
						  style, selector);
    }
    return cssBorder.getLeft().width;
  }
  
  /**
   * Get the border-left-style property
   */
  public final CssBorderLeftStyle getBorderLeftStyle() {
    if (cssBorder.getLeft().getStyle() == null) {
      cssBorder.getLeft().style = 
	(CssBorderLeftStyle) style.CascadingOrder(new CssBorderLeftStyle(), 
						  style, selector);
    }
    return cssBorder.getLeft().style;
  }
  
  /**
   * Get the border-left-color property
   */
  public final CssBorderLeftColor getBorderLeftColor() {
    if (cssBorder.getLeft().getColor() == null) {
      cssBorder.getLeft().color = 
	(CssBorderLeftColor) style.CascadingOrder(new CssBorderLeftColor(), 
						  style, selector);
    }
    return cssBorder.getLeft().color;
  }
  
  /**
   * Get the border-top property
   */  
  public final CssBorderTop getBorderTop() {
    if (cssBorder.getTop().getWidth() == null) {
      cssBorder.getTop().width = getBorderTopWidth();
    }
    if (cssBorder.getTop().getStyle() == null) {
      cssBorder.getTop().style = getBorderTopStyle();
    }
    if (cssBorder.getTop().getColor() == null) {
      cssBorder.getTop().color = getBorderTopColor();
    }
    return cssBorder.getTop();
  }
  
  /**
   * Get the border-right property
   */  
  public final CssBorderRight getBorderRight() {
    if (cssBorder.getRight().getWidth() == null) {
      cssBorder.getRight().width = getBorderRightWidth();
    }
    if (cssBorder.getRight().getStyle() == null) {
      cssBorder.getRight().style = getBorderRightStyle();
    }
    if (cssBorder.getRight().getColor() == null) {
      cssBorder.getRight().color = getBorderRightColor();
    }
    return cssBorder.getRight();
  }
  
  /**
   * Get the border-bottom property
   */  
  public final CssBorderBottom getBorderBottom() {
    if (cssBorder.getBottom().getWidth() == null) {
      cssBorder.getBottom().width = getBorderBottomWidth();
    }
    if (cssBorder.getBottom().getStyle() == null) {
      cssBorder.getBottom().style = getBorderBottomStyle();
    }
    if (cssBorder.getBottom().getColor() == null) {
      cssBorder.getBottom().color = getBorderBottomColor();
    }
    return cssBorder.getBottom();
  }
  
  /**
   * Get the border-left property
   */  
  public final CssBorderLeft getBorderLeft() {
    if (cssBorder.getLeft().getWidth() == null) {
      cssBorder.getLeft().width = getBorderLeftWidth();
    }
    if (cssBorder.getLeft().getStyle() == null) {
      cssBorder.getLeft().style = getBorderLeftStyle();
    }
    if (cssBorder.getLeft().getColor() == null) {
      cssBorder.getLeft().color = getBorderLeftColor();
    }
    return cssBorder.getLeft();
  }
  
  /**
   * Get the border property
   */  
  public final CssBorder getBorder() {
    getBorderTop();
    getBorderRight();
    getBorderBottom();
    getBorderLeft();
    return cssBorder;
  }
  
  /**
   * Get the border-width property
   */
  public final CssBorderWidth getBorderWidth() {
    // WARNING invalid fields in this porperty ....
    return new CssBorderWidth(getBorderTopWidth(),
			      getBorderBottomWidth(),
			      getBorderRightWidth(),
			      getBorderLeftWidth());
  }
  
  /**
   * Get the border-style property
   */  
  public final CssBorderStyle getBorderStyle() {
    // WARNING invalid fields in this porperty ....
    return new CssBorderStyle(getBorderTopStyle(),
			      getBorderBottomStyle(),
			      getBorderRightStyle(),
			      getBorderLeftStyle());
  }
  
  /**
   * Get the border-color property
   */  
  public final CssBorderColor getBorderColor() {
    // WARNING invalid fields in this porperty ....
    return new CssBorderColor(getBorderTopColor(),
			      getBorderBottomColor(),
			      getBorderRightColor(),
			      getBorderLeftColor());
  }
  
  /**
   * Get the width property
   */  
  public final CssWidth getWidth() {
    if (cssWidth == null) {
      cssWidth = 
	(CssWidth) style.CascadingOrder(new CssWidth(), style, selector);
    }
    return cssWidth;
  }
  
  /**
   * Get the height property
   */  
  public final CssHeight getHeight() {
    if (cssHeight == null) {
      cssHeight =
	(CssHeight) style.CascadingOrder(new CssHeight(), style, selector);
    }
    return cssHeight;
  }
  
  /**
   * Get the float property
   */  
  public final CssFloat getFloat() {
    if (cssFloat == null) {
      cssFloat = 
	(CssFloat) style.CascadingOrder(new CssFloat(), style, selector);
    }
    return cssFloat;
  }
  
  /**
   * Get the clear property
   */  
  public final CssClear getClear() {
    if (cssClear == null) {
      cssClear = 
	(CssClear) style.CascadingOrder(new CssClear(), style, selector);
    }
    return cssClear;
  }
  
  /*
   * Classification properties
   */  
  
  /**
   * Get the display property
   */  
  public final CssDisplay getDisplay() {
    if (cssDisplay == null) {
      cssDisplay = 
	(CssDisplay) style.CascadingOrder(new CssDisplay(), style, selector);
    }
    return cssDisplay;
  }
  
  /**
   * Get the white-space property
   */  
  public final CssWhiteSpace getWhiteSpace() {
    if (cssWhiteSpace == null) {
      cssWhiteSpace = 
	(CssWhiteSpace) style.CascadingOrder(new CssWhiteSpace(), 
					     style, selector);
    }
    return cssWhiteSpace;
  }
  
  /**
   * Get the list-style-type property
   */  
  public final CssListStyleType getListStyleType() {
    if (cssListStyle.listStyleType == null) {
      cssListStyle.listStyleType = 
	(CssListStyleType) style.CascadingOrder(new CssListStyleType(), 
						style, selector);
    }
    return cssListStyle.listStyleType;
  }
  
  /**
   * Get the list-style-image property
   */  
  public final CssListStyleImage getListStyleImage() {
    if (cssListStyle.listStyleImage == null) {
      cssListStyle.listStyleImage = 
	(CssListStyleImage) style.CascadingOrder(new CssListStyleImage(), 
						 style, selector);
    }
    return cssListStyle.listStyleImage;
  }
  
  /**
   * Get the list-style-position property
   */  
  public final CssListStylePosition getListStylePosition() {
    if (cssListStyle.listStylePosition == null) {
      cssListStyle.listStylePosition = 
	(CssListStylePosition) style.CascadingOrder(new CssListStylePosition(), 
						    style, selector);
    }
    return cssListStyle.listStylePosition;
  }
  
  /**
   * Get the list-style property
   */  
  public final CssListStyle getListStyle() {
    if (cssListStyle.listStyleType == null)
      cssListStyle.listStyleType = getListStyleType();
    if (cssListStyle.listStyleImage == null)
      cssListStyle.listStyleImage = getListStyleImage();
    if (cssListStyle.listStylePosition == null)
      cssListStyle.listStylePosition = getListStylePosition();
    return cssListStyle;
  }
  
  /**
   * Print this style.
   *
   * @param printer The printer interface.
   */  
  public void print(CssPrinterStyle printer) {
    // Note : macro are never null
    cssFont.print(printer);
    if (cssColor != null)
      cssColor.print(printer);
    cssBackground.print(printer);
    if (cssWordSpacing != null)
      cssWordSpacing.print(printer);
    if (cssLetterSpacing != null)
      cssLetterSpacing.print(printer);
    if (cssTextDecoration != null)
      cssTextDecoration.print(printer);
    if (cssVerticalAlign != null)
      cssVerticalAlign.print(printer);
    if (cssTextTransform != null)
      cssTextTransform.print(printer);
    if (cssTextAlign != null)
      cssTextAlign.print(printer);
    if (cssTextIndent != null)
      cssTextIndent.print(printer);
    cssMargin.print(printer);
    cssPadding.print(printer);
    cssBorder.print(printer);
    if (cssWidth != null)
      cssWidth.print(printer);
    if (cssHeight != null)
      cssHeight.print(printer);
    if (cssFloat != null)
      cssFloat.print(printer);
    if (cssClear != null)
      cssClear.print(printer);
    if (cssDisplay != null)
      cssDisplay.print(printer);
    if (cssWhiteSpace != null)
      cssWhiteSpace.print(printer);
    cssListStyle.print(printer);
  }
  
  /**
   * Find conflicts in this Style
   *
   * @param warnings For warnings reports.
   * @param allSelectors All contexts is the entire style sheet.
   */
  public void findConflicts(Warnings warnings, Enumeration allSelectors) {
    if (cssFont.fontFamily != null && 
	!cssFont.fontFamily.containsGenericFamily()) {
      warnings.addWarning(new Warning(cssFont.fontFamily, 
				      "no-generic-family", 2));
    }
    if (cssBackground.getColor() != null) {
      if (cssColor != null) {
	if (cssBackground.getColor().equals(cssColor.getColor())) {      
	  // background and color can't have the same color
	  warnings.addWarning(new Warning(cssBackground.color, 
					  "same-colors", 1, cssColor));
	}
      } else {
	// It's better to have a color when a background is defined.
	warnings.addWarning(new Warning(cssBackground.color, "no-color", 1));
      }

      // Note : For borders, I don't look for inherited value.
      //        So I can't find same colors in two differents contexts.

      if (cssBorder.getTop().getColor() != null) {
	CSS.Values.CssColor color = cssBorder.getTop().getColor();
	if (cssBackground.getColor().equals(color)) {      
	  // background and border-color can't have the same color
	  warnings.addWarning(new Warning(cssBackground.color, 
					  "same-colors", 1, 
					  cssBorder.getTop().color));
	}
      }
      if (cssBorder.getRight().getColor() != null) {
	CSS.Values.CssColor color = cssBorder.getRight().getColor();
	if (cssBackground.getColor().equals(color)) {      
	  // background and border-color can't have the same color
	  warnings.addWarning(new Warning(cssBackground.color, 
					  "same-colors", 1, 
					  cssBorder.getRight().color));
	}
      }
      if (cssBorder.getBottom().getColor() != null) {
	CSS.Values.CssColor color = cssBorder.getBottom().getColor();
	if (cssBackground.getColor().equals(color)) {      
	  // background and border-color can't have the same color
	  warnings.addWarning(new Warning(cssBackground.color, 
					  "same-colors", 1, 
					  cssBorder.getBottom().color));
	}
      }
      if (cssBorder.getLeft().getColor() != null) {
	CSS.Values.CssColor color = cssBorder.getLeft().getColor();
	if (cssBackground.getColor().equals(color)) {      
	  // background and border-color can't have the same color
	  warnings.addWarning(new Warning(cssBackground.color, 
					  "same-colors", 1, 
					  cssBorder.getLeft().color));
	}
      }
      if ((cssPadding.top == null) ||
	  (cssPadding.right == null) ||
	  (cssPadding.bottom == null) ||
	  (cssPadding.left == null)) {
	// It's better to have a padding with a background color.
	warnings.addWarning(new Warning(cssBackground.color, "no-padding", 2));
      }
    } else if (cssColor != null) {
      // It's better to have a background color with a color
      warnings.addWarning(new Warning(cssColor, "no-background-color", 1));
      while (allSelectors.hasMoreElements()) {
	// looking for inherited values.
	Css1Style style = 
	  (Css1Style) ((CssSelectors) allSelectors.nextElement()).getStyle();
	if (style.cssBackground.getColor() != null) {
	  if (style.cssBackground.getColor().equals(cssColor.getColor())) {
	    warnings.addWarning(new Warning(cssColor, "same-colors2", 1,
					    style.cssBackground.color.getSelectors().toString(), 
					    cssColor.getSelectors().toString()));
	  }
	}
      }
    }

    // now testing for % and length in padding and marging
    // @@FIXME I don't be carreful with the value zero ...

    boolean relative = false;
    boolean absolute = false;
    CssProperty info = null;
    CssValue value = null;

    if (cssMargin.getTop() != null) {
      info = cssMargin.getTop();
      value = cssMargin.getTop().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  
    if (cssMargin.getRight() != null) {
      info = cssMargin.getRight();
      value = cssMargin.getRight().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  
    if (cssMargin.getBottom() != null) {
      info = cssMargin.getBottom();
      value = cssMargin.getBottom().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  
    if (cssMargin.getLeft() != null) {
      info = cssMargin.getLeft();
      value = cssMargin.getLeft().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  

    if (relative && absolute) {
      warnings.addWarning(new Warning(info.getSourceFile(),
				      info.getLine(),
				      "relative-absolute", 2,
				      "margin", ""));
    }

    relative = false;
    absolute = false;

    if (cssPadding.getTop() != null) {
      info = cssPadding.getTop();
      value = cssPadding.getTop().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  
    if (cssPadding.getRight() != null) {
      info = cssPadding.getRight();
      value = cssPadding.getRight().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  
    if (cssPadding.getBottom() != null) {
      info = cssPadding.getBottom();
      value = cssPadding.getBottom().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  
    if (cssPadding.getLeft() != null) {
      info = cssPadding.getLeft();
      value = cssPadding.getLeft().getValue();

      if (value instanceof CssPercentage) {
	relative |= true;
      } else if (value instanceof CssLength) {
	absolute |= true;
      }
    }			  

    if (relative && absolute) {
      warnings.addWarning(new Warning(info.getSourceFile(),
				      info.getLine(),
				      "relative-absolute", 2,
				      "padding", ""));
    }
  }

}
