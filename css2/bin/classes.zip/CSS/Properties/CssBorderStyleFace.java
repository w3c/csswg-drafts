/*
 * $Log: CssBorderStyleFace.java,v $
 * Revision 2.1  1997/08/08 15:52:11  plehegar
 * Nothing
 *
 * Revision 1.2  1997/07/30 13:19:52  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/25 12:34:00  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;

/**
 * @version $Revision: 2.1 $
 */
public class CssBorderStyleFace {

  /**
   * Create a new CssBorderStyleFace
   * @param value The value for this face (no verification)
   * @see acceptValue
   */  
  public CssBorderStyleFace(int value) {
    this.value = value;
  }

  /**
   * Returns the value of this property
   */
  public int get() {
    return value;
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return BORDERSTYLE[value];
  }

  static int acceptValue(CssValue val) {
    if (val instanceof CssIdent) {
      int hash = val.hashCode();
      for (int i = 0; i < BORDERSTYLE.length; i++)
	if (hash_values[i] == hash)
	  return i;
    }

    return INVALID;
  }


  static int INVALID = -1;


  private int value;

  private static String[] BORDERSTYLE = {
    "none", "dotted", "dashed", "solid", "double", "groove", "ridge",
    "inset", "outset" };

  private static int[] hash_values;

  static {
    hash_values = new int[BORDERSTYLE.length];
    for (int i=0; i<BORDERSTYLE.length; i++)
      hash_values[i] = BORDERSTYLE[i].hashCode();
  }

}
