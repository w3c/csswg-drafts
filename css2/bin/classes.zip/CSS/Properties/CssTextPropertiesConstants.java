/*
 * $Log: CssTextPropertiesConstants.java,v $
 * Revision 1.2  1997/07/30 13:20:21  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/24 01:39:42  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

/**
 * @version $Revision: 1.2 $
 */
public interface CssTextPropertiesConstants {
  public static String[] TEXTDECORATION = { 
    "underline", "overline", "line-through", "blink" };
					    
  public static String[] VERTICALALIGN = { 
    "baseline", "sub", "super", "top", "text-top", "middle",
    "bottom", "text-bottom" };

  public static String[] TEXTTRANSFORM = {
    "none", "capitalize", "uppercase", "lowercase" };

  public static String[] TEXTALIGN = {
    "left", "right", "center", "justify" };
}
