/*
 * $Log: CssPaddingLeft.java,v $
 * Revision 3.1  1997/08/29 13:13:59  plehegar
 * Freeze
 *
 * Revision 1.4  1997/08/20 11:41:27  plehegar
 * Freeze
 *
 * Revision 1.3  1997/08/06 17:30:15  plehegar
 * Updated set, now it's a constructor
 *
 * Revision 1.2  1997/07/30 13:20:15  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/24 01:31:29  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *     <A NAME="padding-left">5.5.9 &nbsp;&nbsp; 'padding-left'</A>
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> &lt;length&gt; | &lt;percentage&gt;<BR>
 *   <EM>Initial:</EM> 0<BR>
 *   <EM>Applies to:</EM> all elements<BR>
 *   <EM>Inherited:</EM> no<BR>
 *   <EM>Percentage values:</EM> refer to parent element's width<BR>
 *   <P>
 *   This property sets the left padding of an element.
 *   <PRE>
 *   BLOCKQUOTE { padding-left: 20% }
 * </PRE>
 *   <P>
 *   Padding values cannot be negative.
 * @version $Revision: 3.1 $
 */
public class CssPaddingLeft extends CssPaddingSide {

  /**
   * Create a new CssPaddingLeft
   */
  public CssPaddingLeft() {
    super();
  }
  
  /**
   * Create a new CssPaddingLeft with an another CssPaddingSide
   * @param another The another side.
   */
  public CssPaddingLeft(CssPaddingSide another) {
    super(another);
  }
  
  /**
   * Create a new CssPaddingLeft
   *
   * @param expression The expression for this property.
   * @exception InvalidParamException Values are incorrect
   */
  public CssPaddingLeft(CssExpression expression) throws InvalidParamException {
    super(expression);
  }
  
  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "padding-left";
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    Css1Style style0 = (Css1Style) style;
    if (style0.cssPadding.left != null)
      style0.addRedefinitionWarning(this);
    style0.cssPadding.left = this;
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getPaddingLeft();
    } else {
      return ((Css1Style) style).cssPadding.getLeft();
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof CssPaddingLeft && 
	    value.equals(((CssPaddingLeft) property).value));
  }

}
