/*
 * $Log: CssColor.java,v $
 * Revision 3.3  1997/09/09 13:03:38  plehegar
 * Added getColor()
 *
 * Revision 3.2  1997/09/08 14:03:51  plehegar
 * Suppressed a conflict
 *
 * Revision 3.1  1997/08/29 13:13:43  plehegar
 * Freeze
 *
 * Revision 2.2  1997/08/20 11:41:21  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:14  plehegar
 * Nothing
 *
 * Revision 1.6  1997/08/06 17:29:57  plehegar
 * Updated set, now it's a constructor
 *
 * Revision 1.5  1997/07/31 15:44:29  plehegar
 * CssColors --> CssColor
 *
 * Revision 1.4  1997/07/30 13:19:53  plehegar
 * Updated package
 *
 * Revision 1.3  1997/07/22 17:53:08  plehegar
 * Bug fix in documentation
 *
 * Revision 1.2  1997/07/22 11:21:01  plehegar
 * Updated documentation
 *
 * Revision 1.1  1997/07/21 22:07:26  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *     &nbsp;&nbsp; 'color'
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> &lt;color&gt;<BR>
 *   <EM>Initial:</EM> UA specific<BR>
 *   <EM>Applies to:</EM> all elements<BR>
 *   <EM>Inherited:</EM> yes<BR>
 *   <EM>Percentage values:</EM> N/A<BR>
 *   <P>
 *   This property describes the text color of an element (often referred to as
 *   the <EM>foreground</EM> color). There are different ways to specify red:
 *   <PRE>
 *   EM { color: red }              /* natural language * /
 *   EM { color: rgb(255,0,0) }     /* RGB range 0-255   * /
 * </PRE>
 * @version $Revision: 3.3 $
 */
public class CssColor extends CssProperty {

  CSS.Values.CssColor color;

  /**
   * Create a new CssColor
   */
  public CssColor() {
  }  

  /**
   * Set the value of the property
   * @param expression The expression for this property
   * @exception InvalidParamException Values are incorrect
   */  
  public CssColor(CssExpression expression) throws InvalidParamException {
    CssValue val = expression.getValue();
    if (val instanceof CSS.Values.CssColor) {
      color = (CSS.Values.CssColor) val;
      expression.next();
    } else if (val instanceof CssIdent) {
      color = new CSS.Values.CssColor((String) val.get());
      expression.next();
    } else
      throw new InvalidParamException("value", expression.getValue(), 
				      getPropertyName());
  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return color;
  }

  /**
   * Returns the color
   */
  public CSS.Values.CssColor getColor() {
    return color;
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return color.toString();
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    Css1Style style0 = (Css1Style) style;
    if (style0.cssColor != null) {
      style0.addRedefinitionWarning(this);
    }
    style0.cssColor = this;
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getColor();
    } else {
      return ((Css1Style) style).cssColor;
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof CssColor && 
	    color.equals(((CssColor) property).color));
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "color";
  }

}
