/*
 * $Log: CssBorderFaceStyle.java,v $
 * Revision 2.3  1997/09/09 08:50:28  plehegar
 * Added getStyle()
 *
 * Revision 2.2  1997/08/20 11:41:17  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:08  plehegar
 * Nothing
 *
 * Revision 1.2  1997/07/30 13:19:52  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/25 12:34:00  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;

/**
 * @version $Revision: 2.3 $
 */
public class CssBorderFaceStyle {

  int value;

  /**
   * Create a new CssBorderFaceStyle
   */
  public CssBorderFaceStyle() {
    // nothing to do
  }  

  /**
   * Create a new CssBorderFaceStyle with an another CssBorderFaceStyle
   *
   * @param another An another side.
   */
  public CssBorderFaceStyle(CssBorderFaceStyle another) {
    value = another.value;
  }
  
  /**
   * Create a new CssBorderFaceStyle
   *
   * @param expression The expression for this face
   * @exception InvalidParamException The expression is incorrect
   */  
  public CssBorderFaceStyle(CssExpression expression) 
    throws InvalidParamException {

    CssValue val = expression.getValue();
    if (val instanceof CssIdent) {
      int hash = val.hashCode();
      for (int i = 0; i < BORDERSTYLE.length; i++)
	if (hash_values[i] == hash) {
	  value = i;
	  expression.next();
	  return;
	}
    }

    throw new InvalidParamException("value", val.toString(), "style");
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return BORDERSTYLE[value];
  }

  /**
   * Returns the value
   */
  public String getStyle() {
    return BORDERSTYLE[value];
  }

  /**
   * Compares two side for equality.
   *
   * @param value The another side.
   */  
  public boolean equals(CssBorderFaceStyle style) {
    return value == style.value;
  }

  private static String[] BORDERSTYLE = {
    "none", "dotted", "dashed", "solid", "double", "groove", "ridge",
    "inset", "outset" };

  private static int[] hash_values;

  static {
    hash_values = new int[BORDERSTYLE.length];
    for (int i=0; i<BORDERSTYLE.length; i++)
      hash_values[i] = BORDERSTYLE[i].hashCode();
  }

}
