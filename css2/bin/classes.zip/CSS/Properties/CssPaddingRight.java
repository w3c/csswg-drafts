/*
 * $Log: CssPaddingRight.java,v $
 * Revision 3.1  1997/08/29 13:14:00  plehegar
 * Freeze
 *
 * Revision 1.4  1997/08/20 11:41:27  plehegar
 * Freeze
 *
 * Revision 1.3  1997/08/06 17:30:16  plehegar
 * Updated set, now it's a constructor
 *
 * Revision 1.2  1997/07/30 13:20:16  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/24 01:29:32  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *     &nbsp;&nbsp; 'padding-right'
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> &lt;length&gt; | &lt;percentage&gt;<BR>
 *   <EM>Initial:</EM> 0<BR>
 *   <EM>Applies to:</EM> all elements<BR>
 *   <EM>Inherited:</EM> no<BR>
 *   <EM>Percentage values:</EM> refer to parent element's width<BR>
 *   <P>
 *   This property sets the right padding of an element.
 *   <PRE>
 *   BLOCKQUOTE { padding-right: 10px }
 * </PRE>
 *   <P>
 *   Padding values cannot be negative.
 *
 * @version $Revision: 3.1 $
 */
public class CssPaddingRight extends CssPaddingSide {

  /**
   * Create a new CssPaddingRight
   */
  public CssPaddingRight() {
    super();
  }
  
  /**
   * Create a new CssPaddingRight with an another CssPaddingSide
   *
   * @param another The another side
   */
  public CssPaddingRight(CssPaddingSide another) {
    super(another);
  }
  
  /**
   * Create a new CssPaddingRight
   *
   * @param expression The expression for this property.
   * @exception InvalidParamException Values are incorrect
   */
  public CssPaddingRight(CssExpression expression)
    throws InvalidParamException {
    super(expression);
  }
  
  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "padding-right";
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    Css1Style style0 = (Css1Style) style;
    if (style0.cssPadding.right != null)
      style0.addRedefinitionWarning(this);
    style0.cssPadding.right = this;
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getPaddingRight();
    } else {
      return ((Css1Style) style).cssPadding.getRight();
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof CssPaddingRight && 
	    value.equals(((CssPaddingRight) property).value));
  }

}
