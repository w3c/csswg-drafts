/*
 * $Log: CssListStyleConstants.java,v $
 * Revision 1.2  1997/07/30 13:20:06  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/25 15:20:46  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

/**
 * @version $Revision: 1.2 $
 */
public interface CssListStyleConstants {

  public static String[] LISTSTYLETYPE = {
    "disc", "circle", "square", "decimal", "lower-roman", "upper-roman", "lower-alpha", 
    "upper-alpha", "none" };

  public static String[] LISTSTYLEPOSITION = {
    "outside", "inside" };
}
