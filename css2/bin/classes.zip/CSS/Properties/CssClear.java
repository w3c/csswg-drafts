/*
 * $Log: CssClear.java,v $
 * Revision 3.1  1997/08/29 13:13:43  plehegar
 * Freeze
 *
 * Revision 2.2  1997/08/20 11:41:20  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:13  plehegar
 * Nothing
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *     <A NAME="clear">5.5.26 &nbsp;&nbsp; 'clear'</A>
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> none | left | right | both<BR>
 *   <EM>Initial:</EM> none<BR>
 *   <EM>Applies to:</EM> all elements<BR>
 *   <EM>Inherited:</EM> no<BR>
 *   <EM>Percentage values:</EM> N/A<BR>
 *   <P> This property specifies if an element allows floating elements on its
 *   sides.  More specifically, the value of this property lists the sides where
 *   floating elements are not accepted. With 'clear' set to 'left', an element
 *   will be moved below any floating element on the left side. With 'clear' set
 *   to 'none', floating elements are allowed on all sides. Example:
 *   <PRE>
 *   H1 { clear: left }
 *  </PRE>
 *
 * @version $Revision: 3.1 $ */
public class CssClear extends CssProperty {

  int value;

  /**
   * Create a new CssClear
   */
  public CssClear() {
    // nothing to do
  }  
  
  /**
   * Create a new CssClear
   *
   * @param expression The expression for this property
   * @exception InvalidParamException Values are incorrect
   */  
  public CssClear(CssExpression expression) throws InvalidParamException {
    CssValue val = expression.getValue();

    if ( val instanceof CssIdent) {
      int hash = val.hashCode();
      for (int i = 0; i < CLEAR.length; i++)
	if (hash_values[i] == hash) {
	  value = i;
	  expression.next();
	  return;
	}
    }
    throw new InvalidParamException("value", expression.getValue(), getPropertyName());
  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return CLEAR[value];
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "clear";
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return CLEAR[value];
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    Css1Style style0 = (Css1Style) style;
    if (style0.cssClear != null)
      style0.addRedefinitionWarning(this);
    style0.cssClear = this;
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getClear();
    } else {
      return ((Css1Style) style).cssClear;
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof CssClear && 
	    value == ((CssClear) property).value);
  }

  /**
   * Is the value of this property is a default value.
   * It is used by all macro for the function <code>print</code>
   */  
  public boolean isDefault() {
    return value == 0;
  }

  private static String[] CLEAR = {
    "none", "left", "right", "both" };
  private static int[] hash_values;

  static {
    hash_values = new int[CLEAR.length];
    for (int i = 0; i < CLEAR.length; i++)
      hash_values[i] = CLEAR[i].hashCode();
  }
}
