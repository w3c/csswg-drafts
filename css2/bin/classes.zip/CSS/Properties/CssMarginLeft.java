/*
 * $Log: CssMarginLeft.java,v $
 * Revision 3.1  1997/08/29 13:13:55  plehegar
 * Freeze
 *
 * Revision 1.4  1997/08/20 11:41:26  plehegar
 * Freeze
 *
 * Revision 1.3  1997/08/06 17:30:11  plehegar
 * Updated set, now it's a constructor
 *
 * Revision 1.2  1997/07/30 13:20:10  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/24 00:08:17  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.util.InvalidParamException;

/**
 *   <H4>
 *     &nbsp;&nbsp; 'margin-left'
 *   </H4>
 *   <P>
 *   <EM>Value:</EM> &lt;length&gt; | &lt;percentage&gt; | auto<BR>
 *   <EM>Initial:</EM> 0<BR>
 *   <EM>Applies to:</EM> all elements<BR>
 *   <EM>Inherited:</EM> no<BR>
 *   <EM>Percentage values:</EM> refer to parent element's width<BR>
 *   <P>
 *   This property sets the left margin of an element:
 *   <PRE>
 *   H1 { margin-left: 2em }
 * </PRE>
 *   <P>
 *   A negative value is allowed, but there may be implementation-specific limits.
 * @version $Revision: 3.1 $
 */
public class CssMarginLeft extends CssMarginSide {

  /**
   * Create a new CssMarginLeft
   */
  public CssMarginLeft() {
    super();
  }
  
  /**
   * Create a new CssMarginLeft with an another CssMarginSide
   *
   * @param another The another side.
   */
  public CssMarginLeft(CssMarginSide another) {
    super(another);
  }
  
  /**
   * Create a new CssMarginLeft
   *
   * @param expression The expression foir this property.
   * @exception InvalidParamException Values are incorrect
   */
  public CssMarginLeft(CssExpression expression) throws InvalidParamException {
    super(expression);
  }
  
  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "margin-left";
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    Css1Style style0 = (Css1Style) style;
    if (style0.cssMargin.left != null)
      style0.addRedefinitionWarning(this);
    style0.cssMargin.left = this;
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((Css1Style) style).getMarginLeft();
    } else {
      return ((Css1Style) style).cssMargin.getLeft();
    }
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof CssMarginLeft && 
	    value.equals(((CssMarginLeft) property).value));
  }

}
