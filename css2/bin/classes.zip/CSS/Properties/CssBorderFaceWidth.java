/*
 * $Log: CssBorderFaceWidth.java,v $
 * Revision 2.3  1997/09/09 08:43:07  plehegar
 * Added getValue()
 *
 * Revision 2.2  1997/08/20 11:41:17  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:52:08  plehegar
 * Nothing
 *
 * Revision 1.2  1997/07/30 13:19:50  plehegar
 * Updated package
 *
 * Revision 1.1  1997/07/25 12:34:40  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssLength;
import CSS.Values.CssNumber;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;

/**
 * @version $Revision: 2.3 $
 */
public class CssBorderFaceWidth {

  CssValue value;

  /**
   * Create a new CssBorderFaceWidth
   */
  public CssBorderFaceWidth() {
    value = medium;
  }

  /**
   * Create a new CssBorderFaceWidth from an another CssBorderFaceWidth
   *
   * @param another The another side.
   */
  public CssBorderFaceWidth(CssBorderFaceWidth another) {
    value = another.value;
  }

  /**
   * Create a new CssBorderFaceWidth
   *
   * @param expression The expression for this property
   * @exception InvalidParamException Values are incorrect
   */
  public CssBorderFaceWidth(CssExpression expression) 
    throws InvalidParamException {

    CssValue val = expression.getValue();

    if (val instanceof CssLength) {
      float f = ((Float) val.get()).floatValue();
      if (f >= 0) 
	this.value = val;
      else
	throw new InvalidParamException("negative-value", val.toString());
    } else if (val instanceof CssNumber) {
      value = ((CssNumber) val).getLength();
    } else if (val.equals(thin)) {
      value = thin;
    } else if (val.equals(medium)) {
      value = medium;
    } else if (val.equals(thick)) {
      value = thick;
    } else {
      throw new InvalidParamException("value", val.toString(), "width");
    }

    expression.next();
  }  

  /**
   * Returns the internal value
   */  
  public CssValue getValue() {
    return value;
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {  
    return value.toString();
  }

  /**
   * Compares two sides for equality.
   *
   * @param value The another side.
   */  
  public boolean equals(CssBorderFaceWidth another) {
    return value.equals(another.value);
  }
  
  private static CssIdent thin = new CssIdent("thin");
  private static CssIdent medium = new CssIdent("medium");
  private static CssIdent thick = new CssIdent("thick");
  
}



