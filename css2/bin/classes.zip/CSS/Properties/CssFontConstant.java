/*
 * $Log: CssFontConstant.java,v $
 * Revision 1.3  1997/07/30 13:19:59  plehegar
 * Updated package
 *
 * Revision 1.2  1997/07/17 12:42:03  plehegar
 * Added font-weight
 *
 * Revision 1.1  1997/07/17 12:28:44  plehegar
 * Initial revision
 *
 */
package CSS.Properties;

/**
 * @version $Revision: 1.3 $
 */
public interface CssFontConstant {

  /**
   * Array of font-style values
   */  
  static String[] FONTSTYLE = { "normal", "italic", "oblique" };

  /**
   * Array of font-variant values
   */  
  static String[] FONTVARIANT = { "normal", "small-caps" };

  /**
   * Array of font-size values
   */  
  static String[] FONTSIZE = { 
    "xx-small", "x-small", "small", "medium", "large", "x-large", "xx-large",
    "larger", "smaller"
  }; // relative-size

  /**
   * Array of font-weight values
   */  
  static String[] FONTWEIGHT = { "normal", "bold", "bolder", "lighter" };
  
  /**
   * Corresponding value for font-style normal
   * @see CssFontConstant#FONTSTYLE
   */  
  static int FONTSTYLE_NORMAL = 0;

  /**
   * Corresponding value for font-style italic
   * @see CssFontConstant#FONTSTYLE
   */  
  static int FONTSTYLE_ITALIC = 1;

  /**
   * Corresponding value for font-style oblique
   * @see CssFontConstant#FONTSTYLE
   */  
  static int FONTSTYLE_OBLIQUE = 2;

  /**
   * Corresponding value for font-variant normal
   * @see CssFontConstant#FONTVARIANT
   */  
  static int FONTVARIANT_NORMAL = 0;

  /**
   * Corresponding value for font-variant small-caps
   * @see CssFontConstant#FONTVARIANT
   */  
  static int FONTVARIANT_SMALLCAPS = 1;

  /**
   * Corresponding value for font-size xx-small
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_XXSMALL = 0;

  /**
   * Corresponding value for font-size x-small
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_XSMALL = 0;

  /**
   * Corresponding value for font-size small
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_SMALL = 0;

  /**
   * Corresponding value for font-size medium
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_MEDIUM = 0;

  /**
   * Corresponding value for font-size large
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_LARGE = 0;

  /**
   * Corresponding value for font-size x-large
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_XLARGE = 0;

  /**
   * Corresponding value for font-size xx-large
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_XXLARGE = 0;

  /**
   * Corresponding value for font-size larger
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_LARGER = 0;

  /**
   * Corresponding value for font-size smaller
   * @see CssFontConstant#FONTSIZE
   */  
  static int FONTSIZE_SMALLER = 0;

  /**
   * Corresponding value for font-weight normal
   * @see CssFontConstant#FONTWEIGHT
   */  
  static int FONTWEIGHT_NORMAL = 0;

  /**
   * Corresponding value for font-weight bold
   * @see CssFontConstant#FONTWEIGHT
   */  
  static int FONTWEIGHT_BOLD = 0;

  /**
   * Corresponding value for font-weight bolder
   * @see CssFontConstant#FONTWEIGHT
   */  
  static int FONTWEIGHT_BOLDER = 0;

  /**
   * Corresponding value for font-weight lighter
   * @see CssFontConstant#FONTWEIGHT
   */  
  static int FONTWEIGHT_LIGHTER = 0;

}
