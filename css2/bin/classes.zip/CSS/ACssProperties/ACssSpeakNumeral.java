/*
 * $Log$
 */

package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;

/**
 * <H3> &nbsp;&nbsp 'speak-numeral'</H3>
 * <P>
 * <EM>Value: </EM> digits | continous | none<BR>
 * <EM>Initial:</EM> none<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> NA
 *
 *
 * @version $Revision: 2.1 $
 */
public class ACssSpeakNumeral extends ACssProperty {
  
  CssValue value;
  
  /**
   * Create a new ACssSpeakNumeral
   */  
  public ACssSpeakNumeral() {
    value = none;
  }
  
  /**
   * Creates a new ACssSpeakNumeral
   *
   * @param expression the expression of the size
   * @exception InvalidParamException The expression is incorrect
   */  
  public ACssSpeakNumeral(CssExpression expression) 
    throws InvalidParamException {

    CssValue val = expression.getValue();
    
    if (val.equals(none)) {
      value = none;
      expression.next();
      return;
    } else if (val.equals(continuous)) {
      value = continuous;
      expression.next();
      return;
    } else if (val.equals(digits)) {
      value = digits;
      expression.next();
      return;
    }
    
    throw new InvalidParamException("value", val.toString(), getPropertyName());
  }
  
  /**
   * Returns the current value
   */  
  public Object get() {
    return value;
  }
  
  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }
  
  
  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "speak-numeral";
  }
  
  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    if (((ACssStyle) style).acssSpeakNumeral != null)
      ((ACssStyle) style).addRedefinitionWarning(this);
    ((ACssStyle) style).acssSpeakNumeral = this;
  }
  
  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof ACssSpeakNumeral && 
	    value.equals(((ACssSpeakNumeral) property).value));
  }
  
  
  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getSpeakNumeral();
    } else {
      return ((ACssStyle) style).acssSpeakNumeral;
    }
  }
  
  private static CssIdent none = new CssIdent("none");
  private static CssIdent digits = new CssIdent("digits");
  private static CssIdent continuous = new CssIdent("continuous");
}
