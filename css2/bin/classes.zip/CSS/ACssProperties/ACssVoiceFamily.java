/*
 * $Log: ACssVoiceFamily.java,v $
 * Revision 2.1  1997/08/29 13:11:50  plehegar
 * Updated
 *
 * Revision 1.1  1997/08/25 13:40:59  plehegar
 * Initial revision
 *
 */

package CSS.ACssProperties;

import java.util.Vector;
import java.util.Enumeration;

import CSS.Parser.CssStyle;
import CSS.Properties.CssProperty;
import CSS.Values.CssExpression;
import CSS.Values.CssOperator;
import CSS.Values.CssValue;
import CSS.Values.CssString;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;
import CSS.util.Util;

/** 
 * <H3>5.2 &nbsp;&nbsp;   'voice-family'</H3>
 * <P>
 * <EM>Value:</EM>  [[&lt;specific-voice&gt; | &lt;generic-voice&gt;],]* 
 * [&lt;specific-voice&gt; | &lt;generic-voice&gt;]<BR>
 * <EM>Initial:</EM> UA <BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> NA
 *
 * <P>The value is a prioritized list of voice family names (compare 
 * with '<a
 * href="/pub/WWW/TR/REC-CSS1##font-family">font-family</a>'. Suggested
 * genric families: male, female, child.
 *
 * <P>Examples of specific voice families are: comedian, trinoids, carlos, lisa
 *
 * <p>Examples
 *
 * <pre>
 *   H1 { voice-family: announcer, male }
 *   P.part.romeo {  voice-family: romeo, male }
 *   P.part.juliet { voice-family: juliet, female }
 * </pre>
 *
 * <p class=comment>Should the properties of these family names be
 * described, using an @-rule, to allow better client-side matching (like
 * fonts). If so, what are the values that describe these voice families
 * in a way that is independent of speech synthesizer?
 *
 * @version $Revision: 2.1 $ 
 */
public class ACssVoiceFamily extends ACssProperty implements CssOperator {

  Vector family_name = new Vector();

  /**
   * Create a new ACssVoiceFamily
   */
  public ACssVoiceFamily() {
  }  

  /**
   * Create a new ACssVoiceFamily
   * @param value the voice name
   * @exception InvalidParamException The expression is incorrect
   */
  public ACssVoiceFamily(CssExpression value) throws InvalidParamException {
    boolean family = true;
    CssValue val;
    char op;
    //@@ and if name is already in the vector ?

    while (family) {
      val = value.getValue();
      op = value.getOperator();

      if (op != COMMA && op != SPACE)
	throw new InvalidParamException("operator", (new Character(op)).toString());

      if (val instanceof CssString) {
	if (op == COMMA) { // "helvetica", "roman"
	  String name = (String) val.get();
	  family_name.addElement(trimToOneSpace(name));
	  value.next();
	} else { // "helvetica" CssValue
	  String name = (String) val.get();
	  family_name.addElement(trimToOneSpace(name));
	  family = false;
	  value.next();
	}
      } else if (val instanceof CssIdent) {
	if (op == COMMA) {
	  family_name.addElement(val.toString());
	  value.next();
	} else {
	  CssValue next = value.getNextValue();
	  
	  if (next != null && next instanceof CssIdent) { // @@ null and instanceof
	    CssIdent New = new CssIdent(val.get() + " " + next.get());
	    value.remove();
	    op = value.getOperator();
	    value.remove();
	    value.insert(New);
	    value.setCurrentOperator(op);
	  } else {
	    family_name.addElement(val.toString());
	    value.next();
	    family = false;
	  }
	}
      } else
	throw new InvalidParamException("value", val.toString(), getPropertyName());
    }

  }    

  /**
   * Returns all voices name
   */  
  public Enumeration elements() {
    return family_name.elements();
  }

  /**
   * Returns the size
   */
  public int size() {
    return family_name.size();
  }

  /**
   * Returns the voice (null if no voice)
   */  
  public Object get() {
    if (family_name.size() == 0)
      return null;

    return family_name.firstElement();
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {  
    String r = "";
    for (Enumeration e = elements(); e.hasMoreElements();)
      r += ", " + e.nextElement().toString();
    if (r.length() < 3)
      return null;
    return r.substring(2);
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "voice-family";
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    if (((ACssStyle) style).acssVoiceFamily != null)
      style.addRedefinitionWarning(this);
    ((ACssStyle) style).acssVoiceFamily = this;
  }

  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return false; //@@ FIXME
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getVoiceFamily();
    } else {
      return ((ACssStyle) style).acssVoiceFamily;
    }
  }

  private static String trimToOneSpace(String name) {
    int count = name.length();
    char[] dst = new char[count];
    char[] src = new char[count];
    int index = -1;
    
    name.getChars(0, count, src, 0);
    for(int i=0; i < count; i++)
      if ( i == 0 || ! Util.isWhiteSpace(src[i]) || 
	   ( Util.isWhiteSpace(src[i]) && !Util.isWhiteSpace(dst[index]) ) )
	dst[++index] = src[i];

    return new String(dst, 0, index+1);
  }

}
