/*
 * $Log$
 */
package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssNumber;
import CSS.Values.CssIdent;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;


/**
 * <H3> &nbsp;&nbsp; 'pitch-range' <span class="notes">(could be
 * combined with 'pitch' ?) or 'inflection'</span></H3>
 *
 * <P>
 * <EM>Value: </EM>&lt;number&gt;|inherit<BR>
 * <em>Initial:</EM>50%<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> relative to..
 *
 * <p>Specifies variation in average pitch. A pitch range of 0% produces
 * a flat, monotonic voice. A pitch range of 50% produces normal
 * inflection.  Pitch ranges greater than 50% produce animated voices.
 *
 *
 * @version $Revision: 2.1 $
 */
public class ACssPitchRange extends ACssProperty {
    
    CssValue value;
    
    static CssNumber DefaultValue50 = new CssNumber(50);
    static CssIdent  inherit = new CssIdent("inherit");
    
    /**
     * Create a new ACssPitchRange
     */
    public ACssPitchRange() {
	value = DefaultValue50;
    }  
    
    /**
     * Creates a new ACssPitchRange
     * @param expression The expression for this property
     * @exception InvalidParamException Values are incorrect
     */  
    public ACssPitchRange(CssExpression expression) throws InvalidParamException {
	this();
	CssValue val = expression.getValue();
	int index;
	
	if (val instanceof CssNumber) {
	    value = (CssNumber) val;
	    expression.next();
	    return;
	} else if (val instanceof CssIdent) {
	    if (val.equals(inherit)) {
		value = inherit;
		expression.next();
		return;
	    }
	}
	
	throw new InvalidParamException("value", 
					expression.getValue().toString(), 
					getPropertyName());
    }
    
    /**
     * Returns the value of this property
     */
    public Object get() {
	return value;
    }
    
    
    /**
     * Returns the name of this property
     */  
    public String getPropertyName() {
	return "pitch-range";
    }
    
    /**
     * Returns a string representation of the object.
     */
    public String toString() {
	return value.toString();
    }
    
    /**
     * Add this property to the CssStyle.
     *
     * @param style The CssStyle
     */
    public void addToStyle(CssStyle style) {
	if (((ACssStyle) style).acssPitchRange != null)
	    style.addRedefinitionWarning(this);
	((ACssStyle) style).acssPitchRange = this;
    }
    
    /**
     * Compares two properties for equality.
     *
     * @param property The other property.
     */  
    public boolean equals(CssProperty property) {
	return (property instanceof ACssPitchRange && 
		value.equals(((ACssPitchRange) property).value));
    }
    
    /**
     * Get this property in the style.
     *
     * @param style The style where the property is
     * @param resolve if true, resolve the style to find this property
     */  
    public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
	if (resolve) {
	    return ((ACssStyle) style).getPitchRange();
	} else {
	    return ((ACssStyle) style).acssPitchRange;
	}
    }
    
}

