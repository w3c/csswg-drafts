/*
 * $Log: ACssCueAfter.java,v $
 * Revision 2.1  1997/08/29 13:11:50  plehegar
 * Updated
 *
 * Revision 1.2  1997/08/26 14:26:55  plehegar
 * Bug in getValue()
 *
 * Revision 1.1  1997/08/25 13:03:54  plehegar
 * Initial revision
 *
 * Revision 1.6  1997/08/22 15:00:09  plehegar
 * Bugs
 *
 * Revision 1.5  1997/08/22 14:57:32  plehegar
 * Added getPropertyInStyle()
 *
 * Revision 1.4  1997/08/21 21:13:25  plehegar
 * Added time
 *
 * Revision 1.3  1997/08/21 14:34:56  vmallet
 * Minor modifications so we could compile it.
 *
 * Revision 1.2  1997/08/14 13:19:05  plehegar
 * Added ACssPauseAfter(ACssPauseBefore)
 *
 * Revision 1.1  1997/08/14 12:58:44  plehegar
 * Initial revision
 *
 */

package CSS.ACssProperties;

import java.io.IOException;
import java.net.URL;

import CSS.Values.CssValue;
import CSS.Values.CssExpression;
import CSS.Values.CssURL;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;
import CSS.Parser.CssStyle;
import CSS.Properties.CssProperty;

/**
 * &nbsp;&nbsp;  'cue-after'
 *
 * <P>
 * <EM>Value: </EM> &lt;url&gt; | none<BR>
 * <EM>Initial:</EM> none<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> no<BR>
 * <EM>Percentage values:</EM> NA
 *
 * <P>Auditory icons are another way to distinguish semantic
 * elements. Sounds may be played before, and/or after the element to
 * delimit it. The same sound can be used both before and after, using the
 * shorthand 'cue' property.
 *
 * <p> Examples:
 * <PRE>
 *   A {cue-before: url(bell.aiff); cue-after: url(dong.wav) }
 *   H1 {cue-before: url(pop.au); cue-after: url(pop.au) }
 *   H1 {cue: url(pop.au) }  /* same as previous * /
 * </pre>
 *
 * <p class=comment>The <tt>:before</tt> and <tt>:after</tt>
 * pseudo-elements (see frostings document) could be used to generate
 * this content, rather than using two special-purpose properties. This
 * would be more general.</p>
 *
 * @version $Revision: 2.1 $
 */
public class ACssCueAfter extends ACssProperty {

  CssValue value;
			      
  /**
   * Create a new ACssCueAfter
   */  
  public ACssCueAfter() {
    // Initial is User Agent Specific
    value = none;
  }

  /**
   * Create a new ACssCueAfter
   */  
  public ACssCueAfter(ACssCueBefore cueBefore) {
    value = cueBefore.value;
  }

  /**
   * Creates a new ACssCueAfter
   * @param value the value of the size
   * @exception InvalidParamException The value is incorrect
   */  
  public ACssCueAfter(CssExpression value) throws InvalidParamException {
    CssValue val = value.getValue();
    
    if (val instanceof CssURL) {
      this.value = val;
      value.next();
      return;
    } 
    else if (val.equals(none)) {
      this.value = none;
      value.next();
      return;
    }
    
    throw new InvalidParamException("value", val.toString(), getPropertyName());
  }
  
  /**
   * Returns the current value
   */  
  public Object get() {
    if (value == none)
      return null;
    else
      return value;
  }


  /**
   * Returns some usable value of this property...
   */
  public URL getValue() throws IOException { // vm
    if (value == none)
      return null;
    else {
      if (url == null) {
	url = new URL(new URL(sourceFile), (String) value.get());
      }
      return url;
    }
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }
  

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "cue-after";
  }

  public void addToStyle(CssStyle style) {
    ACssCue acssCue = ((ACssStyle) style).acssCue;
    if (acssCue.cueAfter != null)
      style.addRedefinitionWarning(this);
    acssCue.cueAfter = this;
  }

  public boolean equals(CssProperty property) {
    return (property instanceof ACssCueAfter && value.equals(((ACssCueAfter) property).value));
  }

  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getCueAfter();
    } else {
      return ((ACssStyle) style).acssCue.cueAfter;
    }
  }

  private URL url;
  private static CssIdent none = new CssIdent("none");
}
