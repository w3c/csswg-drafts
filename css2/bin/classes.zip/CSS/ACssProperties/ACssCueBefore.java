/*
 * $Log: ACssCueBefore.java,v $
 * Revision 2.1  1997/08/29 13:11:50  plehegar
 * Updated
 *
 * Revision 1.1  1997/08/14 12:58:44  plehegar
 * Initial revision
 *
 */

package CSS.ACssProperties;

import java.io.IOException;
import java.net.URL;

import CSS.Values.CssValue;
import CSS.Values.CssExpression;
import CSS.Values.CssURL;
import CSS.Values.CssIdent;
import CSS.util.InvalidParamException;
import CSS.Parser.CssStyle;
import CSS.Properties.CssProperty;

/**
 * &nbsp;&nbsp;  'cue-before'
 *
 * <P>
 * <EM>Value: </EM> &lt;url&gt; | none<BR>
 * <EM>Initial:</EM> none<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> no<BR>
 * <EM>Percentage values:</EM> NA
 *
 * <P>Auditory icons are another way to distinguish semantic
 * elements. Sounds may be played before, and/or after the element to
 * delimit it. The same sound can be used both before and after, using the
 * shorthand 'cue' property.
 *
 * <p> Examples:
 * <PRE>
 *   A {cue-before: url(bell.aiff); cue-after: url(dong.wav) }
 *   H1 {cue-before: url(pop.au); cue-after: url(pop.au) }
 *   H1 {cue: url(pop.au) }  /* same as previous * /
 * </pre>
 *
 * <p class=comment>The <tt>:before</tt> and <tt>:after</tt>
 * pseudo-elements (see frostings document) could be used to generate
 * this content, rather than using two special-purpose properties. This
 * would be more general.</p>
 *
 * @version $Revision: 2.1 $
 */
public class ACssCueBefore extends ACssProperty {

  CssValue value;
			      
  /**
   * Create a new ACssCueBefore
   */  
  public ACssCueBefore() {
    // Initial is User Agent Specific
    value = none;
  }

  /**
   * Create a new ACssCueBefore
   */  
  public ACssCueBefore(ACssCueAfter cueBefore) {
    value = cueBefore.value;
  }

  /**
   * Creates a new ACssCueBefore
   * @param value the value of the size
   * @exception InvalidParamException The value is incorrect
   */  
  public ACssCueBefore(CssExpression value) throws InvalidParamException {
    CssValue val = value.getValue();
    
    if (val instanceof CssURL) {
      this.value = val;
      value.next();
      return;
    } else if (val.equals(none)) {
      this.value = none;
      value.next();
      return;
    }
    
    throw new InvalidParamException("value", val.toString(), getPropertyName());
  }
  
  /**
   * Returns the current value
   */  
  public Object get() {
    if (value == none)
      return null;
    else
      return value;
  }

  /**
   * Returns some usable value of this property...
   */
  public URL getValue() throws IOException { // vm
    if (value == none)
      return null;
    else {
      if (url == null) {
	url = new URL(new URL(sourceFile), (String) value.get());
      }
      return url;
    }
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }
  

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "cue-before";
  }

  public void addToStyle(CssStyle style) {
    ACssCue acssCue = ((ACssStyle) style).acssCue;
    if (acssCue.cueBefore != null)
      style.addRedefinitionWarning(this);
    acssCue.cueBefore = this;
  }

  public boolean equals(CssProperty property) {
    return (property instanceof ACssCueBefore && value.equals(((ACssCueBefore) property).value));
  }

  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getCueBefore();
    } else {
      return ((ACssStyle) style).acssCue.cueBefore;
    }
  }

  private URL url;
  private static CssIdent none = new CssIdent("none");
}
