/*
 * $Log$
 */

package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;

/**
 * <H3>&nbsp;&nbsp 'speak-date'</H3>
 * <P>
 * <EM>Value: </EM> myd | dmy | ymd <BR>
 * <EM>Initial:</EM> (Browser-specific)<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> NA
 *
 * <p>This is a request about how any
 * dates should be spoken. month-day-year is common in the USA, while
 * day-month-year is common in Europe and year-month-day is also used.

 * <p class=comment>This would be most useful when combined with a new
 * HTML tag used to identify dates, such as this theoretical example:
 *
 * <pre>
 *    &lt;p&gt;The campaign started on &lt;date value="1874-oct-21"&gt;
 *    the twenty-first of that month&lt;/date&gt; and finished 
 *    &lt;date value="1874-oct-28"&gt;a week later&lt;/date&gt;
 * </pre>
 *
 *
 * @version $Revision: 2.1 $
 */
public class ACssSpeakDate extends ACssProperty {
  
  CssValue value;
  
  /**
   * Create a new ACssSpeakDate
   */  
  public ACssSpeakDate() {
    value = myd; // browser specific
  }
  
  /**
   * Creates a new ACssSpeakDate
   *
   * @param expression the expression of the size
   * @exception InvalidParamException The expression is incorrect
   */  
  public ACssSpeakDate(CssExpression expression) 
    throws InvalidParamException {

    CssValue val = expression.getValue();
    
    if (val.equals(dmy)) {
      value = dmy;
      expression.next();
      return;
    } else if (val.equals(ymd)) {
      value = ymd;
      expression.next();
      return;
    } else if (val.equals(myd)) {
      value = myd;
      expression.next();
      return;
    }
    
    throw new InvalidParamException("value", val.toString(), getPropertyName());
  }
  
  /**
   * Returns the current value
   */  
  public Object get() {
    return value;
  }
  
  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }
  
  
  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "speak-date";
  }
  
  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    if (((ACssStyle) style).acssSpeakDate != null)
      ((ACssStyle) style).addRedefinitionWarning(this);
    ((ACssStyle) style).acssSpeakDate = this;
  }
  
  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof ACssSpeakDate && 
	    value.equals(((ACssSpeakDate) property).value));
  }
  
  
  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getSpeakDate();
    } else {
      return ((ACssStyle) style).acssSpeakDate;
    }
  }
  
  private static CssIdent myd = new CssIdent("myd");
  private static CssIdent dmy = new CssIdent("dmy");
  private static CssIdent ymd = new CssIdent("ymd");
}
