/*
 * $Log$
 */

package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;

/**
 * <H3> &nbsp;&nbsp 'speak-punctuation'</H3>
 *
 * <P>
 * <EM>Value: </EM> code | none <BR>
 * <EM>Initial:</EM> none<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> NA
 *
 * <p>'code' indicates that punctuation such as semicolons, braces, and
 * so on are to be spoken literally. The default value of 'none' means
 * that punctuation is not spoken but instead is rendered naturally as
 * various pauses.
 *
 * @version $Revision: 2.1 $
 */
public class ACssSpeakPunctuation extends ACssProperty {
  
  CssValue value;
  
  /**
   * Create a new ACssSpeakPunctuation
   */  
  public ACssSpeakPunctuation() {
    value = none;
  }
  
  /**
   * Creates a new ACssSpeakPunctuation
   *
   * @param expression the expression of the size
   * @exception InvalidParamException The expression is incorrect
   */  
  public ACssSpeakPunctuation(CssExpression expression) 
    throws InvalidParamException {

    CssValue val = expression.getValue();
    
    if (val.equals(code)) {
      value = code;
      expression.next();
      return;
    } else if (val.equals(none)) {
      value = none;
      expression.next();
      return;
    }
    
    throw new InvalidParamException("value", val.toString(), getPropertyName());
  }
  
  /**
   * Returns the current value
   */  
  public Object get() {
    return value;
  }
  
  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }
  
  
  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "speak-punctuation";
  }
  
  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    if (((ACssStyle) style).acssSpeakPunctuation != null)
      ((ACssStyle) style).addRedefinitionWarning(this);
    ((ACssStyle) style).acssSpeakPunctuation = this;
  }
  
  /**
   * Compares two properties for equality.
   *
   * @param value The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof ACssSpeakPunctuation && 
	    value.equals(((ACssSpeakPunctuation) property).value));
  }
  
  
  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getSpeakPunctuation();
    } else {
      return ((ACssStyle) style).acssSpeakPunctuation;
    }
  }
  
  private static CssIdent none = new CssIdent("none");
  private static CssIdent code = new CssIdent("code");
}
