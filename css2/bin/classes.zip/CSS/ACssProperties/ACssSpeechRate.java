/*
 * $Log: ACssSpeechRate.java,v $
 * Revision 2.1  1997/08/29 13:11:50  plehegar
 * Updated
 *
 * Revision 1.4  1997/08/25 13:51:32  plehegar
 * Added getValue()
 *
 * Revision 1.3  1997/08/22 18:01:18  plehegar
 * Updated
 *
 * Revision 1.2  1997/08/22 17:58:30  plehegar
 * Updated
 *
 * Revision 1.1  1997/08/22 17:07:38  plehegar
 * Initial revision
 *
 */
package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.Values.CssNumber;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;

/**
 *  &nbsp;&nbsp; 'speech-rate'
 *
 * <P>
 * <EM>Value:</EM> &lt;words-per-minute&gt; | x-slow | slow | medium |
 * fast | x-fast | faster | slower<BR>
 * <EM>Initial:</EM> medium<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> NA
 *
 * <P>Specifies the speaking rate. Note that both absolute and relative
 * keyword values are allowed. (compare with font-weight').
 *
 *
 * @version $Revision: 2.1 $
 * @see CSS.Properties.CssFontWeight
 */
public class ACssSpeechRate extends ACssProperty {

  Float value;

  /**
   * Create a new ACssSpeechRate
   */
  public ACssSpeechRate() {
    value = ACssProperties.getValue(this, SPEECHRATE[2]);
    faster = ACssProperties.getValue(this, SPEECHRATE[5]).floatValue();
    slower = ACssProperties.getValue(this, SPEECHRATE[6]).floatValue();
  }  

  /**
   * Creates a new ACssSpeechRate
   *
   * @param expression The expression for this property
   * @exception InvalidParamException Expressions are incorrect
   */  
  public ACssSpeechRate(CssExpression expression) throws InvalidParamException {
    this();
    CssValue val = expression.getValue();
    int index;

    if (val instanceof CssIdent) {
      value = ValueOfIdent((CssIdent) val);
    } else if (val instanceof CssNumber) {
      float v = ((Float) ((CssNumber) val).get()).floatValue();
      value = new Float(v);
    } else
      throw new InvalidParamException("value", expression.getValue().toString(), getPropertyName());
    expression.next();
  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return value;
  }


  /**
   * Returns some usable value of this property...
   */
  public int getValue() { // vm
    return value.intValue();
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "speech-rate";
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    float v = value.floatValue();

    if (v == faster) {
      return SPEECHRATE[5];
    } else if (v == slower) {
      return SPEECHRATE[6];
    } else {
      return value.toString();
    }
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    if (((ACssStyle) style).acssSpeechRate != null)
      style.addRedefinitionWarning(this);
    ((ACssStyle) style).acssSpeechRate = this;
  }

  /**
   * Compares two properties for equality.
   *
   * @param property The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof ACssSpeechRate && value.equals(((ACssSpeechRate) property).value));
  }

  private Float ValueOfIdent(CssIdent ident) throws InvalidParamException {
    int hash = ident.hashCode();
    for (int i = 0; i < SPEECHRATE.length; i++) {
      if (hash_values[i] == hash) {
	return ACssProperties.getValue(this, SPEECHRATE[i]);
      }
    }
    
    throw new InvalidParamException("value", ident.toString(), getPropertyName());
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getSpeechRate();
    } else {
      return ((ACssStyle) style).acssSpeechRate;
    }
  }

  private static int[] hash_values;

  private static String[] SPEECHRATE = { "x-slow", "slow", "medium", "fast", "x-fast", "faster", "slower" };
  private static Float defaultValue;
  private static float faster;
  private static float slower;

  static {
    hash_values = new int[SPEECHRATE.length];
    for (int i = 0; i < SPEECHRATE.length; i++)
      hash_values[i] = SPEECHRATE[i].hashCode();
  }
}

