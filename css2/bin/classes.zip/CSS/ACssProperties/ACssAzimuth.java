/*
 * $Log$
 *
 */
package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.Values.CssNumber;
import CSS.Values.CssAngle;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;

/**
 *
 * @version $Revision: 2.1 $
 */
public class ACssAzimuth extends ACssProperty {

  CssValue value;

  /**
   * Create a new ACssAzimuth
   */
  public ACssAzimuth() {
    value = new CssAngle(ACssProperties.getValue(this, 
						 defaultIdentValue.toString()));
  }  

  /**
   * Creates a new ACssAzimuth
   *
   * @param expression The expression for this property
   * @exception InvalidParamException Expressions are incorrect
   */  
  public ACssAzimuth(CssExpression expression) throws InvalidParamException {
    this();
    CssValue val = expression.getValue();
    int index;

    if (val.equals(leftwards)) {
      value = leftwards;
      expression.next();
      return;
    } else if (val.equals(rightwards)) {
      value = rightwards;
      expression.next();
      return;
    } else if (val.equals(behind)) {
      expression.next();
      CssValue valnext = expression.getValue();
      if (valnext == null) {
	// behind == behind center
	value = new CssAngle(ValueOfIdent(defaultIdentValue, true));
	return;
      } else if (valnext instanceof CssIdent) {
	// behind left
	value = new CssAngle(ValueOfIdent((CssIdent) valnext, true));
	expression.next();
	return;
      }
    } else if (val instanceof CssIdent) {
      expression.next();
      CssValue valnext = expression.getValue();
      if (valnext == null) {
	// left
	value = new CssAngle(ValueOfIdent((CssIdent) val, false));
	return;
      } else if (valnext.equals(behind)) {
	// left behind
	value = new CssAngle(ValueOfIdent((CssIdent) val, true));
	expression.next();
	return;
      }
    } else if (val instanceof CssAngle) {
      value = val;
      expression.next();
      return;
    } else if (val instanceof CssNumber) {
      value = ((CssNumber) val).getAngle();
      expression.next();
      return;
    }

    throw new InvalidParamException("value", 
				    expression.getValue().toString(), 
				    getPropertyName());
  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return value;
  }


  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "azimuth";
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    if (((ACssStyle) style).acssAzimuth != null)
      style.addRedefinitionWarning(this);
    ((ACssStyle) style).acssAzimuth = this;
  }

  /**
   * Compares two properties for equality.
   *
   * @param property The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof ACssAzimuth && 
	    value.equals(((ACssAzimuth) property).value));
  }

  private Float ValueOfIdent(CssIdent ident, boolean b) 
    throws InvalidParamException {
    
    int hash = ident.hashCode();
    for (int i = 0; i < AZIMUTH.length; i++) {
      if (hash_values[i] == hash) {
	if (b) {
	  return ACssProperties.getValue(this, 
					 behind.toString() + "." + AZIMUTH[i]);
	} else {
	  return ACssProperties.getValue(this, AZIMUTH[i]);
	}
      }
    }
    
    throw new InvalidParamException("value", 
				    ident.toString(), 
				    getPropertyName());
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getAzimuth();
    } else {
      return ((ACssStyle) style).acssAzimuth;
    }
  }

  private static int[] hash_values;

  private static String[] AZIMUTH = { "left-side", "far-left", "left",
				      "center-left", "center", "center-right",
				      "right", "far-right", "right-side" };

  private static CssIdent defaultIdentValue = new CssIdent(AZIMUTH[4]);
  private static CssIdent behind = new CssIdent("behind");
  private static CssIdent leftwards = new CssIdent("leftwards");
  private static CssIdent rightwards = new CssIdent("rightwards");

  static {
    hash_values = new int[AZIMUTH.length];
    for (int i = 0; i < AZIMUTH.length; i++)
      hash_values[i] = AZIMUTH[i].hashCode();
  }
}

