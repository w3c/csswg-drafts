/*
 * $Log$
 */
package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssNumber;
import CSS.Values.CssIdent;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;


/**
 * <H3> &nbsp;&nbsp 'richness' ('brightness' ?)</H3>
 * <P>
 * <EM>Value: </EM>&lt;number&gt;|inherit<BR>
 * <em>Initial:</EM> 50%<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> Relative to...
 *
 * <P>Specifies the richness (brightness) of the speaking voice. The
 * effect of increasing richness is to produce a voice that
 * <em>carries</em> --reducing richness produces a soft, mellifluous
 * voice.
 *
 * @version $Revision: 2.1 $
 */
public class ACssRichness extends ACssProperty {
    
    CssValue value;
    
    static CssNumber DefaultValue50 = new CssNumber(50);
    static CssIdent  inherit = new CssIdent("inherit");
    
    /**
     * Create a new ACssRichness
     */
    public ACssRichness() {
	value = DefaultValue50;
    }  
    
    /**
     * Creates a new ACssRichness
     * @param expression The expression for this property
     * @exception InvalidParamException Values are incorrect
     */  
    public ACssRichness(CssExpression expression) throws InvalidParamException {
	this();
	CssValue val = expression.getValue();
	int index;
	
	if (val instanceof CssNumber) {
	    value = (CssNumber) val;
	    expression.next();
	    return;
	} else if (val instanceof CssIdent) {
	    if (val.equals(inherit)) {
		value = inherit;
		expression.next();
		return;
	    }
	}

	throw new InvalidParamException("value", 
					expression.getValue().toString(), 
					getPropertyName());
    }
    
    /**
     * Returns the value of this property
     */
    public Object get() {
	return value;
    }
    
    
    /**
     * Returns the name of this property
     */  
    public String getPropertyName() {
	return "richness";
    }
    
    /**
     * Returns a string representation of the object.
     */
    public String toString() {
	return value.toString();
    }
    
    /**
     * Add this property to the CssStyle.
     *
     * @param style The CssStyle
     */
    public void addToStyle(CssStyle style) {
	if (((ACssStyle) style).acssRichness != null)
	    style.addRedefinitionWarning(this);
	((ACssStyle) style).acssRichness = this;
    }
    
    /**
     * Compares two properties for equality.
     *
     * @param property The other property.
     */  
    public boolean equals(CssProperty property) {
	return (property instanceof ACssRichness && 
		value.equals(((ACssRichness) property).value));
    }
    
    /**
     * Get this property in the style.
     *
     * @param style The style where the property is
     * @param resolve if true, resolve the style to find this property
     */  
    public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
	if (resolve) {
	    return ((ACssStyle) style).getRichness();
	} else {
	    return ((ACssStyle) style).acssRichness;
	}
    }
    
}

