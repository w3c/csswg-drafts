/*
 * $Log: ACssPitch.java,v $
 * Revision 2.1  1997/08/29 13:11:50  plehegar
 * Updated
 *
 * Revision 1.1  1997/08/22 18:11:54  plehegar
 * Initial revision
 *
 */
package CSS.ACssProperties;

import CSS.Parser.CssStyle;
import CSS.Values.CssExpression;
import CSS.Values.CssValue;
import CSS.Values.CssIdent;
import CSS.Values.CssFrequency;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;

/**
 *  &nbsp;&nbsp; 'pitch' <span>(or 'average pitch'
 * ?, what is the relationship with voice-family?)</span>
 *
 * <P>
 * <EM>Value: </EM>&lt;hertz&gt; | x-low | low | medium | high | x-high<BR>
 * <EM>Initial:</EM> medium<BR>
 * <EM>Applies to:</EM> all elements<BR>
 * <EM>Inherited:</EM> yes<BR>
 * <EM>Percentage values:</EM> NA
 *
 * <p>Specifies the average pitch of the speaking voice in hertz (Hz).
 *
 * @version $Revision: 2.1 $
 */
public class ACssPitch extends ACssProperty {

  CssValue value;

  /**
   * Create a new ACssPitch
   */
  public ACssPitch() {
    if (defaultValue == null) {
      defaultValue = new CssFrequency(ACssProperties.getValue(this, PITCH[2]));
    }
    value = defaultValue;
  }  

  /**
   * Creates a new ACssPitch
   *
   * @param expression The expression for this property
   * @exception InvalidParamException Values are incorrect
   */  
  public ACssPitch(CssExpression expression) throws InvalidParamException {
    this();
    CssValue val = expression.getValue();

    if (val instanceof CssIdent) {
      value = ValueOfIdent((CssIdent) val);
    } else if (val instanceof CssFrequency) {
      value = val;
    } else
      throw new InvalidParamException("value", 
				      expression.getValue().toString(), 
				      getPropertyName());
    expression.next();
  }

  /**
   * Returns the value of this property
   */
  public Object get() {
    return value;
  }


  /**
   * Returns some usable value of this property...
   */
  public int getValue() { // vm
    return ((Float) value.get()).intValue();
  }

  /**
   * Returns the name of this property
   */  
  public String getPropertyName() {
    return "pitch";
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    return value.toString();
  }

  /**
   * Add this property to the CssStyle.
   *
   * @param style The CssStyle
   */
  public void addToStyle(CssStyle style) {
    if (((ACssStyle) style).acssPitch != null)
      style.addRedefinitionWarning(this);
    ((ACssStyle) style).acssPitch = this;
  }

  /**
   * Compares two properties for equality.
   *
   * @param property The other property.
   */  
  public boolean equals(CssProperty property) {
    return (property instanceof ACssPitch && value.equals(((ACssPitch) property).value));
  }

  private CssFrequency ValueOfIdent(CssIdent ident) throws InvalidParamException {
    int hash = ident.hashCode();
    for (int i = 0; i < PITCH.length; i++) {
      if (hash_values[i] == hash) {
	return new CssFrequency(ACssProperties.getValue(this, PITCH[i]));
      }
    }
    
    throw new InvalidParamException("value", ident.toString(), getPropertyName());
  }

  /**
   * Get this property in the style.
   *
   * @param style The style where the property is
   * @param resolve if true, resolve the style to find this property
   */  
  public CssProperty getPropertyInStyle(CssStyle style, boolean resolve) {
    if (resolve) {
      return ((ACssStyle) style).getPitch();
    } else {
      return ((ACssStyle) style).acssPitch;
    }
  }

  private static int[] hash_values;

  private static String[] PITCH = { "x-low", "low", "medium", "high", "x-high" };

  private static CssFrequency defaultValue;

  static {
    hash_values = new int[PITCH.length];
    for (int i = 0; i < PITCH.length; i++)
      hash_values[i] = PITCH[i].hashCode();
  }
}

