/*
 * $Log: StyleSheetCom.java,v $
 * Revision 1.1  1998/01/07 13:32:20  plehegar
 * Initial revision
 *
 */
package CSS.CSS;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;

import html.tags.HtmlTree;
import html.tags.HtmlParser;
import html.tags.HtmlParserListener;
import html.tags.HtmlTag;

/**
 * @version $Revision: 1.1 $
 */
public class StyleSheetCom implements HtmlParserListener {
    
    String documentBase = "text";
    URL htmlURL;
    String file;
    int warningLevel = 2;
    PrintWriter out;
    
    public static void main(String args[]) 
	throws IOException, MalformedURLException {
	int i = 0;
	boolean fromXML = false;
	
	StyleSheetCom style = new StyleSheetCom();
	
	try {
	    style.file = args[i];
	    
	    while (args[i].charAt(0) == '-') {
		String argument = args[i].substring(1).toLowerCase();
		if (argument.equals("fromxml")) {
		    fromXML = true;
		} else if (argument.equals("e")) {
		    style.warningLevel = -1;
		} else if (argument.equals("format")) {
		    StyleSheetGenerator.printAvailableFormat(new PrintWriter(System.err));
		} else {
		    style.documentBase = argument;
		}
		i++;
	    }
	} catch (Exception e) {
	    System.out.println( "Usage: java " + 
				StyleSheetCom.class.getName() + 
				// " [-<your format>] [-fromxml] <url>");
				" [-e|-<your format>] <url>");
	    System.out.println( "\tuse the option -format to see"
				+ " available format.");
	    System.exit(1);
	}
	    
	style.out = new PrintWriter(System.out);
	while (i < args.length) {
	    try {
		File f = new File(args[i++]);
		style.file = f.getAbsolutePath();
		style.htmlURL = new URL("file", null, -1, style.file);
		
		URLConnection urlC = (style.htmlURL).openConnection();
		
		if (urlC.getContentType() != null && 
		    urlC.getContentType().indexOf("text/html") != -1) {
		    if (fromXML) {
			System.err.println( "Sorry, this is a text/html document" +
					    "and I can't work with an HTML document" +
					    "for an XML input." );
			return;
		    }
		    
		    try {
			HtmlParser htmlParser = new HtmlParser("html4", style.file);
			htmlParser.addParserListener(style);
			htmlParser.run();
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		} else {
		    CssParser parser;
		    if (fromXML) {
			parser = new StyleSheetXMLParser();
		    } else {
			parser = new StyleSheetParser();
		    }
		    parser.parseURL(style.htmlURL);
		    parser.getStyleSheet().findConflicts();
		    StyleSheetGenerator output = 
			new StyleSheetGenerator(style.file, 
						parser.getStyleSheet(), 
						style.documentBase,
						style.warningLevel);
		    output.print(style.out);
		}
		try {
		    urlC.getInputStream().close();
		} catch (IOException e) {
		    e.printStackTrace();
		}
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}
    }
    
    /**
     * Notifies root creation.
     *
     * Sent when the parser builds the root of the HTML tree.
     *
     * @param url the URL being parsed.
     * @param root the new root Tag for this parser.
     */    
    public void notifyCreateRoot(URL url, HtmlTag root) {
    }
    
    public void notifyActivity(int lines, long bytes) {
    }
    
    public void notifyConnection(URLConnection cnx) {
    }
    
    /**
     * Notifies successful termination.
     *
     * @param root the root of the current Tree.
     */    
    public void notifyEnd(HtmlTag root) {
	StyleSheet style = null;
	if (root != null) {
	    style = ((HtmlTree) root).getStyleSheet();
	}
	
	if (style != null) {
	    style.findConflicts();
	    StyleSheetGenerator style2 = new StyleSheetGenerator(file, 
								 style, 
								 documentBase,
								 warningLevel);
	    style2.print(out);
	} else {
	    System.out.println("No style sheet found in your HTML document");
	}
    }
    
    
    /**
     * Notifies a fatal error.
     *
     * This notification is sent when the parser need to stop during or before
     * parsing, due to an unexpected exception.
     *
     * @param root the root of the current Tree, if any.
     * @param x the exception that cause the Parser stop
     * @param msg an error message information
     */
    public void notifyFatalError(HtmlTag root, Exception x, String s) {
    }
    
}
