/**
 * $Log: CssCascadingOrder.java,v $
 * Revision 1.5  1997/08/26 14:25:19  plehegar
 * Optimized
 *
 * Revision 1.4  1997/08/25 14:06:21  plehegar
 * Minor bug line 35
 *
 * Revision 1.3  1997/08/25 12:50:23  plehegar
 * Bug
 *
 * Revision 1.2  1997/08/22 16:37:56  plehegar
 * Updated
 *
 * Revision 1.1  1997/08/22 14:53:56  plehegar
 * Initial revision
 *
 */
package CSS.CSS;

import java.util.Enumeration;
import CSS.Parser.CssSelectors;
import CSS.Properties.CssProperty;
import CSS.Parser.CssStyle;

/**
 *   <H3>
 *      &nbsp;&nbsp; Cascading order
 *   </H3>
 *
 * <P> Conflicting rules are intrinsic to the CSS mechanism. To find the value
 * for an element/property combination, the following algorithm must be
 * followed:
 *
 * <OL>
 * <LI> Find all declarations that apply to the element/property in question.
 * Declarations apply if the selector matches the element in question. If no
 * declarations apply, the inherited value is used. If there is no inherited
 * value (this is the case for the 'HTML' element and for properties that do not
 * inherit), the initial value is used.
 *
 * <LI> Sort the declarations by explicit weight: declarations marked
 * '!important' carry more weight than unmarked (normal) declarations.
 *
 * <LI> Sort by origin: the author's style sheets override the reader's style
 * sheet which override the UA's default values. An imported style sheet has the
 * same origin as the style sheet from which it is imported.
 *
 * <LI> Sort by specificity of selector: more specific selectors will override
 * more general ones. To find the specificity, count the number of ID attributes
 * in the selector (a), the number of CLASS attributes in the selector (b), and
 * the number of tag names in the selector (c). Concatenating the three numbers
 * (in a number system with a large base) gives the specificity. Some examples:
 *
 * <PRE>
 *   LI            {...}  /* a=0 b=0 c=1 -&gt; specificity =   1 * /
 *   UL LI         {...}  /* a=0 b=0 c=2 -&gt; specificity =   2 * /
 *   UL OL LI      {...}  /* a=0 b=0 c=3 -&gt; specificity =   3 * /
 *   LI.red        {...}  /* a=0 b=1 c=1 -&gt; specificity =  11 * /
 *   UL OL LI.red  {...}  /* a=0 b=1 c=3 -&gt; specificity =  13 * / 
 *   #x34y         {...}  /* a=1 b=0 c=0 -&gt; specificity = 100 * / 
 * </PRE>
 *
 * <P> Pseudo-elements and pseudo-classes are counted as normal elements and
 * classes, respectively.
 *
 * <LI> Sort by order specified: if two rules have the same weight, the latter
 * specified wins. Rules in imported style sheets are considered to be before
 * any rules in the style sheet itself.
 * </OL>
 *
 * <P> The search for the property value can be terminated whenever one rule has
 * a higher weight than the other rules that apply to the same element/property
 * combination.
 *
 * <P> This strategy gives author's style sheets considerably higher weight than
 * those of the reader. It is therefore important that the reader has the
 * ability to turn off the influence of a certain style sheet, e.g. through a
 * pull-down menu.
 *
 * <P> A declaration in the 'STYLE' attribute of an element has the same weight
 * as a declaration with an ID-based selector that is specified at the end of
 * the style sheet:
 *
 * <PRE>
 * &lt;STYLE TYPE="text/css"&gt;
 *   #x97z { color: blue }
 * &lt;/STYLE&gt;
 * &lt;P ID=x97z STYLE="color: red"&gt;
 * </PRE>
 *
 * <P> In the above example, the color of the 'P' element would be red. Although
 * the specificity is the same for both declarations, the declaration in the
 * 'STYLE' attribute will override the one in the 'STYLE' element because of
 * cascading rule number 5.
 *
 * <P> The UA may choose to honor other stylistic HTML attributes, for example
 * 'ALIGN'.  If so, these attributes are translated to the corresponding CSS
 * rules with specificity equal to 1. The rules are assumed to be at the start
 * of the author style sheet and may be overridden by subsequent style sheet
 * rules. In a transition phase, this policy will make it easier for stylistic
 * attributes to coexist with style sheets.
 *
 * @version $Revision: 1.5 $ 
 */
public final class CssCascadingOrder {

  private CssProperty[] propertyData;
  private int propertyCount;

  private final int capacityIncrement = 10;

  /**
   * Order all properties and returns the winner.
   *
   * @param property The default value returned if there is no property.
   * @param style The current style sheet where we can find all properties.
   * @param selector The current context.
   * @return the property with the right value.
   */
  public CssProperty order(CssProperty property, 
			   StyleSheet style, CssSelectors selector) {
    propertyData = new CssProperty[10];
    propertyCount = 0;

    // looking for all declarations that apply to the element/property in
    // question.
    for (Enumeration e = style.getRules().elements(); e.hasMoreElements();) {
      CssSelectors context = (CssSelectors) e.nextElement();

      if (!selector.equals(context)
	  && context.canApply(selector)) {
	// here, don't try to resolve
	CssProperty prop = property.getPropertyInStyle(context.getStyle(), 
						       false);
	if (prop != null) {
	    addProperty(prop);
	}
      }
    }

    if (propertyCount == 0) {
      // if I found nothing
      if (selector.getNext() != null && property.Inherited()) {
	// here, I can try to resolve
	property = 
	  property.getPropertyInStyle(((CssStyle) style.getStyle(selector.getNext())), 
				      true);
      } // else use the default value
    } else {
      // runs the cascading order
      property = getProperty(selector);
    }
    // duplicate the property because I change the context ...
    property = property.duplicate();
    property.setSelectors(selector);

    return property;
  }  

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    String ret = "";
    for (int i = 0; i < propertyCount; i++) {
      if (propertyData[i].getImportant()) {
	ret += propertyData[i].getSelectors() + " { " +
	  propertyData[i].getPropertyName() + " : " +
	  propertyData[i] + " !important } \n";
      } else {
	ret += propertyData[i].getSelectors() + " { " +
	  propertyData[i].getPropertyName() + " : " +
	  propertyData[i] + " } \n";
      }
    }
    return ret;
  }
    
  // here you can find the algorithm for the cascading order
  private CssProperty getProperty(CssSelectors selector) {

    // trimToSize
    int oldCapacity = propertyData.length;
    if (propertyCount < oldCapacity) {
      CssProperty oldData[] = propertyData;
      propertyData = new CssProperty[propertyCount];
      System.arraycopy(oldData, 0, propertyData, 0, propertyCount);
    }
    
    // sort by explicit weight and origin (step 2 and 3)
    quickSort(0, propertyData.length-1, 1);
    int old = propertyData[0].getExplicitWeight();
    int part_high_ind = 0;
    while (part_high_ind < propertyCount && 
	   propertyData[part_high_ind].getExplicitWeight() == old) {
      part_high_ind++;
    }
    // sort by specificity (step 4)
    quickSort(0, part_high_ind-1, 2);
    old = propertyData[0].getSelectors().getSpecificity();
    part_high_ind = 0;
    while (part_high_ind < propertyCount && 
	   propertyData[part_high_ind].getSelectors().getSpecificity() == old) {
      part_high_ind++;
    }
    // sort by order specified (step 5)
    quickSort(0, part_high_ind - 1, 3);

    return propertyData[0];
  }

  private int partition(int part_low_ind, int part_high_ind, int search) {
    int lastsmall;
    long median_val;
    int comp1;
    CssProperty transit;
    
    // swap median value an first value of array
    comp1 = ( part_low_ind + part_high_ind ) / 2;         
    
    transit = propertyData[part_low_ind];
    propertyData[part_low_ind] = propertyData[comp1];
    propertyData[comp1] = transit;
    
    switch (search) {
    case 1:
      median_val = propertyData[part_low_ind].getExplicitWeight();
      break;
    case 2:
      median_val = propertyData[part_low_ind].getSelectors().getSpecificity();
      break;
    case 3:
      median_val = propertyData[part_low_ind].getOrderSpecified();
      break;
    default:
      throw new NullPointerException("Error ! please send a bug report ...");
    }


    lastsmall = part_low_ind;
    for (int i = part_low_ind + 1; i<=part_high_ind; i++) {
      switch (search) {
      case 1:
	if (propertyData[i].getExplicitWeight() > median_val) {
	  lastsmall++;
	  // swap lastsmall and i
	  transit=propertyData[lastsmall];
	  propertyData[lastsmall]=propertyData[i];
	  propertyData[i]=transit;
	}
	break;
      case 2:
	if (propertyData[i].getSelectors().getSpecificity() > median_val) {
	  lastsmall++;
	  // swap lastsmall and i
	  transit=propertyData[lastsmall];
	  propertyData[lastsmall]=propertyData[i];
	  propertyData[i]=transit;
	}
	break;
      case 3:
	if (propertyData[i].getOrderSpecified() > median_val) {
	  lastsmall++;
	  // swap lastsmall and i
	  transit=propertyData[lastsmall];
	  propertyData[lastsmall]=propertyData[i];
	  propertyData[i]=transit;
	}
	break;
      default:
	throw new NullPointerException("Error ! please send a bug report ...");
      }
      
    }
    // swap part_low_ind and lastsmall
    transit=propertyData[part_low_ind];
    propertyData[part_low_ind]=propertyData[lastsmall];
    propertyData[lastsmall]=transit;
    
    return lastsmall;
  }
  
  private void quickSort(int qk_low_ind, int qk_high_ind, int search) {
    if (qk_low_ind < qk_high_ind) {
      int median = partition(qk_low_ind, qk_high_ind, search);
      quickSort(qk_low_ind, median, search);
      quickSort(median+1, qk_high_ind, search);
    }
  }

  private final void addProperty(CssProperty property) {
    int oldCapacity = propertyData.length;
    if (propertyCount + 1 > oldCapacity) {
      CssProperty oldData[] = propertyData;
      propertyData = new CssProperty[oldCapacity + capacityIncrement];
      System.arraycopy(oldData, 0, propertyData, 0, propertyCount);
    }
    propertyData[propertyCount++] = property;
  }

}
