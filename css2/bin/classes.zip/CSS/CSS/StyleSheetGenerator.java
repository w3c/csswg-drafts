/*
 * $Log: StyleSheetGenerator.java,v $
 * Revision 1.1  1998/01/08 18:46:51  plehegar
 * Initial revision
 *
 * Revision 3.2  1997/09/09 12:42:01  plehegar
 * Updates
 *
 * Revision 3.1  1997/08/29 13:23:27  plehegar
 * Freeze
 *
 * Revision 1.6  1997/08/22 14:55:24  plehegar
 * Updated
 *
 * Revision 1.5  1997/08/21 07:28:55  plehegar
 * Added StyleSheet
 *
 * Revision 1.4  1997/08/20 14:14:10  plehegar
 * Added context and property in CssErrorToken
 *
 * Revision 1.3  1997/08/20 13:15:31  plehegar
 * Added HTMl design by Thierry Kormann
 *
 * Revision 1.2  1997/08/20 11:42:10  plehegar
 * Freeze
 *
 * Revision 1.1  1997/08/11 08:05:33  plehegar
 * Initial revision
 *
 */
package CSS.CSS;

import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Enumeration;
import CSS.util.Date;

import CSS.Parser.Analyzer.ParseException;
import CSS.Parser.CssParseException;
import CSS.Parser.Errors;
import CSS.Parser.CssError;
import CSS.Parser.CssErrorToken;
import CSS.Parser.CssErrorDeclaration;
import CSS.Parser.CssFouffa;
import CSS.Parser.CssPrinterStyle;
import CSS.Parser.CssSelectors;
import CSS.Properties.CssProperty;
import CSS.util.InvalidParamException;
import CSS.util.SortedHashtable;
import CSS.util.Warnings;
import CSS.util.Warning;
import CSS.util.Util;

/**
 * @version $Revision: 1.1 $
 */
public final class StyleSheetGenerator implements CssPrinterStyle {
    
    SortedHashtable items;
    Warnings warnings;
    Errors errors;
    
    private CssSelectors selector;
    private CssProperty property;
    private PrintWriter out;
    private int warningLevel;
    private Properties general;
    
    private static Properties availableFormat;
    private static Hashtable formats = new Hashtable();
    
    /**
     * Create a new StyleSheetGenerator
     *
     * @param title        The title for the generated document
     * @param style        The style sheet
     * @param document     The name of the source file
     * @param warningLevel If you want to reduce warning output.
     *                     (-1 means no warnings)
     */
    public StyleSheetGenerator(String title, 
			       StyleSheet style, 
			       String document,
			       int warningLevel) {
	
	general = new Properties(setDocumentBase(getDocumentName(document)));
	general.put("file-title", title);
	general.put("today", new Date().toString());
	
	warnings = style.getWarnings();
	errors = style.getErrors();
	items = (SortedHashtable) style.getRules();
	this.warningLevel = warningLevel;
	
	general.put("errors-count", 
		    Integer.toString(errors.getErrorCount()));
	general.put("warnings-count", 
		    Integer.toString(warnings.getWarningCount()));
	general.put("rules-count", 
		    Integer.toString(items.size()));
	
	if (errors.getErrorCount() == 0) {
	    desactivateError();
	}
	if (warnings.getWarningCount() == 0 || warningLevel == -1) {
	    general.put("go-warnings", ""); // remove go-warnings
	    general.put("warnings", ""); // remove warnings
	}
	if (items.size() == 0) {
	    general.put("go-rules", ""); // remove go-rules
	    general.put("rules", ""); // remove rules
	} else {
	    general.put("no-rules", ""); // remove no-rules
	}
	
	if (errors.getErrorCount() != 0 || warnings.getWarningCount() != 0) {
	    general.put("no-error-or-warning", ""); // remove no-error-or-warning
	}
	
	if (Util.onDebug) general.list(System.err);
    }
    
    public void desactivateError() {
	general.put("go-errors", ""); // remove go-errors
	general.put("errors", ""); // remove errors
    }
    
    /**
     * Returns a string representation of the object.
     */
    public void print(PrintWriter out) {
	this.out = out; // must be in first !
	String output = processSimple("document");
	if (output != null) {
	    out.println(output);
	} else {
	    out.println("An error occured during the output of your style sheet.");
	    out.println("Please correct your request ");
	    out.println(" or send a mail to Philippe.Le_Hegaret@sophia.inria.fr");
	}
	
	out.flush();
    }
    
    public void produceRule() {
	Object[] array = items.getSortedArray();
	for (int i = 0; i < array.length; i++) {
	    selector = (CssSelectors) array[i];
	    if (!selector.isEmpty())
		out.print(processStyle(general.getProperty("rule"), general));
	}
    }
    
    public void produceSelector(CssSelectors selectorLocal) {
	if (selectorLocal != null) {
	    produceSelector(selectorLocal.getNext());
	    Properties prop = new Properties(general);
	    
	    if (selectorLocal.getElement() != null) {
		prop.put("element", selectorLocal.getElement());
	    } else {
		prop.put("element-style", "");
	    }
	    if (selectorLocal.getFirstClasse() != null) {
		prop.put("class", selectorLocal.getFirstClasse());
	    } else {
		prop.put("class-style", "");
	    }
	    if (selectorLocal.getId() != null) {
		prop.put("id", selectorLocal.getId());
	    } else {
		prop.put("id-style", "");
	    }
	    if (selectorLocal.getPseudoClass() != null) {
		prop.put("pseudo-class", selectorLocal.getPseudoClass());
	    } else {
		prop.put("pseudo-class-style", "");
	    }
	    if (selectorLocal.getPseudoElement() != null) {
		prop.put("pseudo-element", selectorLocal.getPseudoElement());
	    } else {
		prop.put("pseudo-element-style", "");
	    }
	    out.print(processStyle(prop.getProperty("selector"), prop));
	}
    }
    
    public void produceDeclaration() {
	selector.getStyle().print(this);
    }  
    
    public void print(CssProperty property) {
	Properties prop = new Properties(general); 
	prop.put("property-name", property.getPropertyName().toString());
	prop.put("property-value", property.toString());
	
	if (!property.getImportant()) {
	    prop.put("important-style", "");
	}
	if (!(CssFouffa.getProperty(property.getPropertyName()) == null && !CssFouffa.inAuralMode())) {
	    prop.put("not-css1-style", "");
	}
	out.print(processStyle(prop.getProperty("declaration"), prop));
    }
    
    public void produceError() {
	StringBuffer ret = new StringBuffer(1024);
	String oldSourceFile = null;
	
	try {
	    if (errors.getErrorCount() != 0) {
		int i = 0;
		for (CssError[] error = errors.getErrors(); i < error.length; i++) {
		    if (!error[i].getSourceFile().equals(oldSourceFile)) {
			oldSourceFile = error[i].getSourceFile();
			ret.append("\nURL : ").append(error[i].getSourceFile()).append('\n');
		    }
		    ret.append(" Line : ").append(error[i].getLine()).append(" ");
		    
		    if (error[i].getException() instanceof FileNotFoundException) {
			ret.append("File not found ");
			ret.append(error[i].getException().getMessage());
			ret.append('\n');
			
		    } else if (error[i].getException() instanceof InvalidParamException) {
			ret.append(" ").append(error[i].getException().getMessage()).append('\n');
			
		    } else if (error[i].getException() instanceof CssParseException) {
			CssParseException terror = 
			    (CssParseException) error[i].getException();
			if (terror.getMessage() != null) {
			    ret.append(terror.getMessage()).append('\n');
			} else {
			    ret.append("Parse error - unrecognized : ");
			    ret.append(queryReplace(terror.getSkippedString())).append('\n');
			    if (terror.getContexts() != null && 
				terror.getContexts().size() != 0) {
				StringBuffer buf = new StringBuffer();
				for (Enumeration e = terror.getContexts().elements(); 
				     e.hasMoreElements();) {
				    Object t = e.nextElement();
				    if (t != null) {
					buf.append(t);
					if (e.hasMoreElements())
					    buf.append(", ");
				    }
				}
				if (buf.length() != 0) {
				    ret.append("Context : ").append(buf);
				}
			    }
			    if (terror.getPropertyName() != null) {
				ret.append("\nProperty : ").append(terror.getPropertyName());
				ret.append('\n');
			    }
			}
			
		    } else if (error[i].getException() instanceof ParseException) {
			ret.append("Parse error -").append(error[i].getException().getMessage());
			ret.append('\n');
			
		    } else if (error[i].getException() instanceof ClassNotFoundException) {
			ret.append("Class not found : ");
			ret.append(error[i].getException().getMessage());
			ret.append('\n');
			
		    } else if (error[i].getException() instanceof IOException) {
			String stringError = error[i].getException().toString();
			ret.append(stringError.substring(0, stringError.indexOf(':')));
			ret.append(" : ");
			ret.append(error[i].getException().getMessage()).append('\n');
			
		    } else if (error[i] instanceof CssErrorDeclaration) {
			CssErrorDeclaration derror = (CssErrorDeclaration) error[i];
			ret.append("   ").append(derror.getPropertyName()).append(" : ");
			ret.append(derror.getExpression()).append('\n');
			
		    } else if (error[i] instanceof CssErrorToken) {
			CssErrorToken terror = (CssErrorToken) error[i];
			ret.append("   ").append(terror.getErrorDescription()).append(" : ");
			ret.append(terror.getSkippedString()).append('\n');
			
		    } else {
			ret.append(error[i].getException()).append(" \n");
			
			if (error[i].getException() instanceof NullPointerException) {
			    // ohoh, a bug
			    error[i].getException().printStackTrace();
			}
		    }
		}
	    }
	    out.println(ret.toString());
	} catch (Exception e) {
	    out.println("An error appears during error's ouput, sorry.");
	    e.printStackTrace();
	}
    }
    
    public void produceWarning() {
	StringBuffer ret = new StringBuffer(1024);
	String oldSourceFile = "";
	int oldLine = -1;
	String oldMessage = "";
	try {
	    if (warnings.getWarningCount() != 0) {
		int i = 0;
		warnings.sort();
		for (Warning[] warning = warnings.getWarnings(); 
		     i < warning.length; i++) {
		    
		    Warning warn = warning[i];
		    if (warn.getLevel() <= warningLevel) {
			if (!warn.getSourceFile().equals(oldSourceFile)) {
			    oldSourceFile = warn.getSourceFile();
			    ret.append("\n URL : ");
			    ret.append(warn.getSourceFile()).append('\n');
			} 
			if (warn.getLine() != oldLine || 
			    !warn.getWarningMessage().equals(oldMessage)) {
			    oldLine = warn.getLine();
			    oldMessage = warn.getWarningMessage();
			    ret.append("Line : ").append(warn.getLine());
			    
			    if (warn.getLevel() != 0) {
				ret.append(" Level : ").append(warn.getLevel());
			    }
			    ret.append(" ").append(warn.getWarningMessage());
			    
			    if (warn.getContext() != null) {
				ret.append(" : ").append(warn.getContext());
			    }
			    
			    ret.append(" \n");
			}
		    }
		}
	    }
	    out.println(ret.toString());
	} catch (Exception e) {
	    out.println("An error appears during warning's ouput, sorry.");
	    e.printStackTrace();
	}
    }
    
    private String queryReplace(String s) {
	/*	int len = s.length();
	StringBuffer ret = new StringBuffer(len);
	
	
	for (int i = 0; i < len; i++) {
	    char c = s.charAt(i);
	    if (c == '<') {
		ret.append(" &lt;");
	    } else if (c == '>') {
		ret.append(" &gt;");
	    } else {
		ret.append(c);
	    }
	    } 
	    return ret.toString(); */
	return s;
    }
    
    private final String processSimple(String s) {
	return processStyle(general.getProperty(s), general);
    }
    
    private String processStyle(String str, Properties prop) {
	
	try {
	    int i = 0;
	    while ((i = str.indexOf("<!-- #", i)) >= 0) {
		int lastIndexOfEntity = str.indexOf("-->", i);
		String entity = str.substring(i+6, 
					      lastIndexOfEntity - 1).toLowerCase();
		if (entity.equals("rule")) {
		    out.print(str.substring(0, i));
		    str = str.substring(lastIndexOfEntity+3);
		    i = 0;
		    produceRule();
		} else if (entity.equals("selectors")) {
		    if (selector.getNext() != null) {
			// contextuals selectors
			String value = prop.getProperty(entity);
			if (value != null) {
			    str = str.substring(0, i) + value + 
				str.substring(lastIndexOfEntity+3);
			} else {
			    i += 6; // skip this unknown entity
			}
		    } else {
			out.print(str.substring(0, i));
			str = str.substring(lastIndexOfEntity+3);
			i = 0;
			produceSelector(selector);
		    }
		} else if (entity.equals("selector")) {
		    out.print(str.substring(0, i));
		    str = str.substring(lastIndexOfEntity+3);
		    i = 0;
		    produceSelector(selector);
		} else if (entity.equals("declaration")) {
		    out.print(str.substring(0, i));
		    str = str.substring(lastIndexOfEntity+3);
		    i = 0;
		    produceDeclaration();
		} else if (entity.equals("warning")) {
		    out.print(str.substring(0, i));
		    str = str.substring(lastIndexOfEntity+3);
		    i = 0;
		    produceWarning();
		} else if (entity.equals("error")) {
		    out.print(str.substring(0, i));
		    str = str.substring(lastIndexOfEntity+3);
		    i = 0;
		    produceError();
		} else {
		    String value = prop.getProperty(entity);
		    if (value != null) {
			str = str.substring(0, i) + value + 
			    str.substring(lastIndexOfEntity+3);
		    } else {
			i += 6; // skip this unknown entity
		    }
		}
	    }
	    
	    return str;
	} catch (Exception e) {
	    e.printStackTrace();
	    return str;
	}
    }
    
    public final static void printAvailableFormat(PrintWriter out) {
	Enumeration e = availableFormat.propertyNames();
	out.println( " -- listing available output format --" );
	while (e.hasMoreElements()) {
	    String key = ((String) e.nextElement()).toLowerCase();
	    out.println( "Format : " + key );
	    out.println( "   File : " + getDocumentName(key) );
	}
	out.flush();
    }
    
    private Properties setDocumentBase(String document) {
	Properties properties = (Properties) formats.get(document);
	if (properties == null) {
	    URL url;
	    properties = new Properties();
	    try {
		url = StyleSheetGenerator.class.getResource(document);
		java.io.InputStream f = url.openStream();
		properties.load(f);
		f.close();
		properties.put("author","Philippe Le Hegaret");
		properties.put("author-email","Philippe.Le_Hegaret@sophia.inria.fr");
	    } catch (Exception e) {
		System.err.println("CSS.CSS.StyleSheetGenerator: couldn't load properties " + document);
		System.err.println("  " + e.toString() );
		printAvailableFormat(new PrintWriter(System.err));
	    }
	    formats.put(document, properties);
	}

	return new Properties(properties);
    }
    
    private final static String getDocumentName(String documentName) {
	String document = availableFormat.getProperty(documentName.toLowerCase());
	if (document == null) {
	    System.err.println( "Unable to find " + 
				documentName.toLowerCase() + " output format" );
	    return documentName;
	} else {
	    return document;
	}
    }
    
    static {
	URL url;
	availableFormat = new Properties();
	try {
	    url = StyleSheetGenerator.class.getResource("format.properties");
	    java.io.InputStream f = url.openStream();
	    availableFormat.load(f);
	    f.close();
	} catch (Exception e) {
	    System.err.println("CSS.CSS.StyleSheetGenerator: couldn't load format properties ");
	    System.err.println("  " + e.toString() );
	}
    }
}
