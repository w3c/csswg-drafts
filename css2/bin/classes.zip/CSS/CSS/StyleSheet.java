/*
 * $Log: StyleSheet.java,v $
 * Revision 2.7  1997/08/26 14:25:01  plehegar
 * Updated
 * Supressed getAllApplyContext(CssSelectors selector)
 *
 *
 * Revision 2.1  1997/08/11 08:05:18  plehegar
 * Freeze
 *
 * Revision 1.4  1997/07/21 22:21:49  plehegar
 * Added a lot of stuff
 */

package CSS.CSS;

import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;

import CSS.util.Warnings;
import CSS.util.Util;
import CSS.util.SortedHashtable;
import CSS.Parser.Errors;
import CSS.Properties.CssProperty;
import CSS.Parser.CssSelectors;
import CSS.Parser.CssStyle;

/**
 * This class contains a style sheet with all rules, errors and warnings.
 *
 * @version $Revision: 2.7 $
 */
public class StyleSheet {

  private CssCascadingOrder cascading;
  private SortedHashtable rules;
  private Errors errors;
  private Warnings warnings;

  /**
   * Create a new StyleSheet.
   */
  public StyleSheet() {
    rules = new SortedHashtable();
    errors  = new Errors();
    warnings = new Warnings();
    cascading = new CssCascadingOrder();
  }

  /**
   * Get a style in a specific context.
   * No resolution are perfomed when this function is called
   *
   * @param context The context for the style
   * @return The style for the specific context.
   */  
  public CssStyle getStyle(CssSelectors context) {
    Util.verbose("StyleSheet.getStyle("+context+")");

    if (getContext(context) != null) {
      CssSelectors realContext = (CssSelectors) getContext(context);
      CssStyle style = realContext.getStyle();
      style.setStyleSheet(this);
      style.setSelector(realContext);
      return style;
    } else {
      getRules().put(context, context);
      context.getStyle().setStyleSheet(this);
      context.getStyle().setSelector(context);
      return context.getStyle();
    }

  }

  /**
   * Add a property to this style sheet.
   *
   * @param selector The context where the property is defined
   * @param property The property to add
   */  
  public void addProperty(CssSelectors selector, CssProperty property) {
    getContext(selector).addProperty(property, warnings);
  }

  /**
   * Add some errors to this style.
   *
   * @param errors Some errors.
   */  
  public void addErrors(Errors errors) {
    if (errors.getErrorCount() != 0) {
      getErrors().addErrors(errors);
    }
  }

  /**
   * Add some warnings to this style.
   *
   * @param warnings Some warnings.
   */  
  public void addWarnings(Warnings warnings) {
    if (warnings.getWarningCount() != 0)
      getWarnings().addWarnings(warnings);
  }

  /**
   * Returns all errors.
   */  
  public final Errors getErrors() {
    return errors;
  }

  /**
   * Returns all warnings.
   */  
  public final Warnings getWarnings() {
    return warnings;
  }

  /**
   * Returns all rules
   */  
  public final Hashtable getRules() {
    return rules;
  }

  /**
   * Returns the property for a context.
   *
   * @param property The default value returned if there is no property.
   * @param style The current style sheet where we can find all properties
   * @param selector The current context
   * @return the property with the right value
   */
  public final CssProperty CascadingOrder(CssProperty property, StyleSheet style, CssSelectors selector) {
      return cascading.order(property, style, selector);
  }

  /**
   * Find all conflicts for this style sheet.
   */  
  public void findConflicts() {
    for (Enumeration e = getRules().elements(); e.hasMoreElements();) {
      CssStyle style = ((CssSelectors) e.nextElement()).getStyle();
      style.findConflicts(warnings, getRules().elements());
    }
  }

  /**
   * Returns the uniq context for a context
   *
   * @param selector the context to find.
   */  
  protected CssSelectors getContext(CssSelectors selector) {
    if (getRules().containsKey(selector)) {
      return (CssSelectors) getRules().get(selector);
    } else {
      if (selector.getNext() != null) {
	CssSelectors next = getContext(selector.getNext());
	selector.setNext(next);
      }
      getRules().put(selector, selector);
      return selector;
    }
  }

  /**
   * dump this style sheet.
   */  
  public void dump() {
    StyleSheetGenerator style = 
      new StyleSheetGenerator("", this, "text", -1);
    style.print(new PrintWriter(System.out));
  }

}
