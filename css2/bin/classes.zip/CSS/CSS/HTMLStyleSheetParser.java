/*
 * $Log: HTMLStyleSheetParser.java,v $
 * Revision 3.1  1997/08/29 13:23:27  plehegar
 * Freeze
 *
 */
package CSS.CSS;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
// import w3c.www.protocol.http.HttpURLConnection;

import html.tags.HtmlTree;
import html.tags.HtmlParser;
import html.tags.HtmlParserListener;
import html.tags.HtmlTag;

import CSS.util.Util;

/**
 * @version $Revision: 3.1 $
 */
public final class HTMLStyleSheetParser implements HtmlParserListener {
  
  private StyleSheet style;
  private URL htmlURL;

  /**
   * Create a new HTMLStyleSheetParser
   *
   * @exception Exception An error
   */
  public HTMLStyleSheetParser(String urlString, boolean auralMode)
    throws Exception {

    htmlURL = new URL(urlString);
    URLConnection connection = htmlURL.openConnection();

    if (Util.importSecurity) {
      throw new IOException("[SECURITY] You can't put an URL sorry.");
    }

    if (Util.servlet && !(connection instanceof HttpURLConnection)) {
      System.out.println( "[WARNING] : someone is trying to get the file : " + 
			  urlString );
      throw new IOException("import " + urlString + 
			    ": Operation not permitted");
    }

    if (connection instanceof HttpURLConnection) {
      HttpURLConnection HttpConnection = (HttpURLConnection) connection;
      if (HttpConnection.getResponseCode() != HttpURLConnection.HTTP_OK) {
	throw new IOException(HttpConnection.getResponseMessage());
      }
    }

    if (connection.getContentType().indexOf("text/html") != -1) {
      HtmlParser htmlParser = new HtmlParser("html4", urlString);
      if (auralMode)
	htmlParser.setAuralMode();
      htmlParser.addParserListener(this);
      htmlParser.run();
    } else {
      StyleSheetParser parser = new StyleSheetParser();
      if (auralMode) {
	parser.setAuralMode();
      }
      parser.parseURL(htmlURL);
      style = parser.getStyleSheet();
    }
    try {
	connection.getInputStream().close();
    } catch (IOException e) {
	e.printStackTrace();
    }
  }  

  /**
   * Notifies root creation.
   *
   * Sent when the parser builds the root of the HTML tree.
   *
   * @param url the URL being parsed.
   * @param root the new root Tag for this parser.
   */    
  public void notifyCreateRoot(URL url, HtmlTag root) {
  }
  
  public void notifyActivity(int lines, long bytes) {
  }

  public void notifyConnection(URLConnection cnx) {
  }
  
  /**
   * Notifies successful termination.
   *
   * @param root the root of the current Tree.
   */    
  public void notifyEnd(HtmlTag root) {
    if (root != null) {
      style = ((HtmlTree) root).getStyleSheet();
    }
  }
    
  /**
   * Notifies a fatal error.
   *
   * This notification is sent when the parser need to stop during or before
   * parsing, due to an unexpected exception.
   *
   * @param root the root of the current Tree, if any.
   * @param x the exception that cause the Parser stop
   * @param msg an error message information
   */
  public void notifyFatalError(HtmlTag root, Exception x, String s) {
  }

  /**
   * Returns the recognized style sheet.
   * @return A style sheet.
   */  
  public StyleSheet getStyleSheet() {
    return style;
  }

} // HTMLStyleSheetParser
