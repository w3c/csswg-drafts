/*
 * $Log: StyleSheetParser.java,v $
 * Revision 3.1  1997/08/29 13:23:27  plehegar
 * Freeze
 *
 * Revision 1.1  1997/08/21 07:26:37  plehegar
 * Initial revision
 *
 */

package CSS.CSS;

import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import java.net.URL;

import CSS.Parser.CssValidatorListener;
import CSS.Parser.CssFouffa;
import CSS.Parser.Errors;
import CSS.Parser.CssSelectors;
import CSS.Properties.CssProperty;
import CSS.util.Warnings;
import CSS.util.Warning;
import CSS.util.Util;

/**
 * @version $Revision: 3.1 $
 */
public final class StyleSheetParser 
        implements CssValidatorListener, CssParser {
    
    CssFouffa cssFouffa;
    StyleSheet style = new StyleSheet();
    
    public void reInit() {
	style = new StyleSheet();
    }
    
    public StyleSheet getStyleSheet() {
	return style;
    }
    
    public void notifyErrors(Errors errors) {
	style.addErrors(errors);
    }
    
    public void notifyWarnings(Warnings warnings) {
	style.addWarnings(warnings);
    }
    
    /**
     * Adds a vector of properties to a selector.
     *
     * @param selector     the selector
     * @param declarations Properties to associate with contexts
     */  
    public void handleRule(CssSelectors selector, Vector properties) {
	for (Enumeration e2 = properties.elements();e2.hasMoreElements();) {
	    CssProperty property = (CssProperty) e2.nextElement();
	    property.setSelectors(selector);
	    style.addProperty(selector, property);
	}
    }
    
    /**
     * Handles an at-rule.
     *
     * <p>The parameter <code>value</code> can be :
     * <DL>
     * <DT>CssString
     * <DD>The value coming from a string.
     * <DT>CssURL
     * <DD>The value coming from an URL.
     * <DT>Vector
     * <DD>The value is a vector of declarations (it contains properties).
     *     This feature is not legal, so be careful.
     * </DL>
     *
     * @param ident The ident for this at-rule (for example: 'font-face')
     * @param string The string representation if this at-rule
     */  
    public void handleAtRule(String ident, String string) {
	style.getWarnings().addWarning(new Warning(cssFouffa.getSourceFile(),
						   cssFouffa.getLine(),
						   "at-rule",
						   2,
						   ident,
						   string));
    }
    
    /**
     * @param url the URL containing the style sheet
     * @exception IOException an IO error
     */
    public void parseURL(URL url) {
	Util.verbose( "StyleSheet.parseURL(" + url + ")" );
	try {
	    if (cssFouffa == null) {
		cssFouffa = new CssFouffa(url);
		cssFouffa.addListener(this);
	    } else
		cssFouffa.ReInit(url);
	    cssFouffa.parseStyle();
	}
	catch (IOException e) {
	    e.printStackTrace();
	}
    }
    
    /**
     * @param input the inputStream containing the style data
     * @param url the name of the file the style element was read in.
     * @exception IOException an IO error
     */
    public void parseStyleElement(InputStream input, URL url, int lineno) {
	Util.verbose( "StyleSheet.parseStyleElement(" + url + "," + lineno + ")" );
	
	try {
	    if (cssFouffa == null) {
		cssFouffa = new CssFouffa(input, url, lineno);
		cssFouffa.addListener(this);
	    } else
		cssFouffa.ReInit(input, url, lineno);
	    cssFouffa.parseStyle();
	}
	catch (IOException e) {
	    e.printStackTrace();
	}
    }
    
    /**
     * @param input the inputStream containing the style data
     * @param url the name of the file the style element was read in.
     * @exception IOException an IO error
     * @deprecated Replaced by parseStyleElement
     * @see #parseStyleElement(InputStream, URL, int)
     */
    public void parseStyleElement(String input, URL url, int lineno) {
	parseStyleElement(new ByteArrayInputStream(input.getBytes()), url, lineno);
    }
    
    /**
     * Parse some declarations
     * @param input the inputStream containing the style data
     * @param id the uniq id
     * @param filename the name of the file the style element was read in.
     * @exception IOException an IO error
     */
    public void parseStyleAttribute(InputStream input, String id, URL url, int lineno) {
	lineno--; // why ?!?!
	Util.verbose( "StyleSheet.parseStyleAttribute(" + id + "," + url + "," + lineno + ")" );
	
	try {
	    if (cssFouffa == null) {
		cssFouffa = new CssFouffa(input, url, lineno);
		cssFouffa.addListener(this);
	    } else
		cssFouffa.ReInit(input, url, lineno);
	    CssSelectors selector = new CssSelectors();
	    selector.setId(id);
	    cssFouffa.parseDeclarations(selector);
	}
	catch (IOException e) {
	    e.printStackTrace();
	}
    }
    
    /**
     * @param input the inputStream containing the style data
     * @param id the uniq id
     * @param url the name of the file the style element was read in.
     * @exception IOException an IO error
     * @deprecated Replaced by parseStyleAttribute
     * @see #parseStyleAttribute(InputStream, URL, int)
     */
    public void parseStyleAttribute(String input, String id, 
				    URL url, int lineno) {
	parseStyleAttribute(new ByteArrayInputStream(input.getBytes()), 
			    id, url, lineno);
    }
    
    public void setStyle(Class style) {
	CssFouffa.setStyle(style);
    }
    
    /**
     * @deprecated
     */  
    public void setAuralMode() {
	CssFouffa.setAuralMode();
    }
    
    /**
     * @deprecated
     */  
    public void unsetAuralMode() {
	CssFouffa.unsetAuralMode();
    }
    
}
