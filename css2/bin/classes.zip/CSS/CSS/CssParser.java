/*
 * $Log$
 */
package CSS.CSS;

import java.io.InputStream;
import java.net.URL;

/**
 * This class describes how to implements your cascading
 * style sheet parser.
 * 
 * You must implements this interfaces if you want to have
 * a backward compatibilitie with other CSS parser.
 * <p>
 * Typically, it is used like this :
 * <p>
 * <code>
 *  // YourParser.setAuralMode();  add this if you want to parse Aural CSS<br>
 *  YourParser parser = new YourParser();<br>
 *  parser.parseURL(yourURLDocument);<br>
 *  StyleSheet style = parser.getStyleSheet();<br>
 *  // here, i want an HTML document to output<br>
 *  StyleSheetGenerator.setDocumentBase("html.properties");<br>
 *  StyleSheetGenerator generator = new StyleSheetGenerator("foo", 
 *                                                          style,
 *                                                          "foo.css",
 *                                                          2);<br>
 *  generator.print(new PrintStream(System.out));<br>
 * </code>
 *
 * @see CSS.CSS.StyleSheetParser
 * @version $Revision$
 */
public interface CssParser {

  /**
   * Reinitialize this parser
   */  
  public abstract void reInit();

  /**
   * Get the style sheet after a parse.
   *
   * @return The resulted style sheet
   */  
  public abstract StyleSheet getStyleSheet();

  /**
   * Parse an URL
   *
   * @param url the URL to parse
   */  
  public abstract void parseURL(URL url);

  /**
   * Parse a STYLE element.
   * The real difference between this method and the precedent
   * is that this method can take a string. The URL is used
   * to resolve import statement and URL statement in the style
   * sheet.
   * <p>
   * For a backward compatibility, <code>parseStyleElement</code> and
   * <code>parseStyleAttribute</code> use a string for the input.
   *
   * @param input the input string.
   * @param url  the URL where the input stream comes from.
   * @param lineno The number line in the source document. It is used for error message
   * @deprecated Replaced by parseStyleElement
   * @see #parseStyleElement(InputStream, URL, int)
   */  
  public abstract void parseStyleElement(String input, URL url, int lineno);

  /**
   * Parse a STYLE element.
   * The real difference between this method and the precedent
   * is that this method can take an InputStream. The URL is used
   * to resolve import statement and URL statement in the style
   * sheet.
   *
   * @param input the input stream.
   * @param url  the URL where the input stream comes from.
   * @param lineno The number line in the source document. It is used for error message
   */  
  public abstract void parseStyleElement(InputStream input, URL url, int lineno);

  /**
   * Parser a STYLE attribute.
   * Here, you must generate your own uniq id for the context.
   * After, you can reference this style attribute by the id.
   * <p>
   * <strong>Be careful, the id must be uniq !</strong>
   * <p>
   * For a backward compatibility, <code>parseStyleElement</code> and
   * <code>parseStyleAttribute</code> use a string for the input.
   *
   * @param input the input string.
   * @param id your uniq id to reference this style attribute.
   * @param url  the URL where the input stream comes from.
   * @param lineno The number line in the source document. It is used for error message.
   * @deprecated Replaced by parseStyleAttribute
   * @see #parseStyleAttribute(InputStream, String, URL, int)
   */  
  public abstract void parseStyleAttribute(String input, String id, URL url, int lineno);

  /**
   * Parser a STYLE attribute.
   * Here, you must generate your own uniq id for the context.
   * After, you can reference this style attribute by the id.
   * <p>
   * <strong>Be careful, the id must be uniq !</strong>
   *
   * @param input the input stream.
   * @param id your uniq id to reference this style attribute.
   * @param url  the URL where the input stream comes from.
   * @param lineno The number line in the source document. It is used for error message.
   */  
  public abstract void parseStyleAttribute(InputStream input, String id, URL url, int lineno);

}
