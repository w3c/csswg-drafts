/*
 * $Log: Warning.java,v $
 * Revision 2.2  1997/09/08 13:35:45  plehegar
 * Added level
 *
 * Revision 2.1  1997/08/08 15:51:50  plehegar
 * Nothing
 *
 */
package CSS.util;

import CSS.Parser.CssSelectors;
import CSS.Properties.CssProperty;

/**
 * This class is use to manage all warning every where
 * @version $Revision: 2.2 $
 */
public class Warning {
  private String sourceFile;
  private int hashSource;
  private int line;
  private CssSelectors selector;
  private String warningMessage;

  /**
   * Create a new Warning with message parameters.
   *
   * @param sourceFile the source file
   * @param line the line number in the source file
   * @param warningMessage the warning message to find in the properties file
   * @param level the warning level
   * @param message1 the first message to add
   * @param message2 the second message to add
   *
   * @see CSS.util.Messages
   */
  public Warning(String sourceFile, int line, String warningMessage, int level,
		 String message1, String message2) {
    this.sourceFile = sourceFile;
    this.hashSource = sourceFile.hashCode() % 100;
    this.line = line;
    this.warningMessage = warm(warningMessage, message1, message2);
    this.line = getLevel(warningMessage, level) + (line * 10); 
  }  

  /**
   * Create a new Warning.
   *
   * @param sourceFile the source file
   * @param line the line number in the source file
   * @param warningMessage the warning message to find in the properties file
   * @param level the warning level
   *
   * @see CSS.util.Messages
   */
  public Warning(String sourceFile, int line, 
		 String warningMessage, int level) {
    this(sourceFile, line, warningMessage, level, "", "");
  }  

  /**
   * Create a new Warning with a property and insert two messages inside.
   *
   * @param property The property where the warning came
   * @param warningMessage The warning message to find in the properties file
   * @param level the warning level
   * @param message1 the first message to add
   * @param message2 the second message to add
   *
   * @see CSS.util.Messages
   */
  public Warning(CssProperty property, String warningMessage, int level,
		 String message1, String message2) {
    this.sourceFile = property.getSourceFile();
    this.hashSource = sourceFile.hashCode() % 100;
    this.warningMessage = warm(warningMessage, message1, message2);
    this.line = getLevel(warningMessage, level) + (property.getLine() * 10); 
  }

  /**
   * Create a new Warning with a property.
   * <P>Be careful ! Be sure that all informations in your property is
   * available.
   *
   * @param property The property where the warning came
   * @param warningMessage The warning message to find in the properties file
   * @param level the warning level
   *
   * @see CSS.util.Messages
   * @see CSS.Properties.CssProperty#setInfo
   */
  public Warning(CssProperty property, String warningMessage, int level) {
    this(property, warningMessage, level, property.getPropertyName(), "");
    this.selector = property.getSelectors();
  }

  /**
   * Create a new Warning with a property and insert an other property name
   * inside.
   *
   * @param property The property where the warning came
   * @param warningMessage The warning message to find in the properties file
   * @param level the warning level
   * @param property2 The property in conflicts with the first
   *
   * @see CSS.util.Messages 
   */
  public Warning(CssProperty property, String warningMessage, int level,
		 CssProperty property2) {
    this(property, warningMessage, level, property2.getPropertyName(), "");
    this.selector = property.getSelectors();
  }

  /**
   * Get the source file
   */  
  public String getSourceFile() {
    return sourceFile;
  }

  /**
   * Get the line number.
   */  
  public int getLine() {
    return line / 10;
  }

  /**
   * Get the message.
   */  
  public String getWarningMessage() {
    return warningMessage;
  }

  /**
   * Get the warning level.
   */  
  public int getLevel() {
    return line % 10;
  }

  /**
   * Get the context.
   */  
  public CssSelectors getContext() {
    return selector;
  }

  public int getInternalOrder() {
    return (hashSource * 100000) + line;
  }

  /**
   * debug trace
   */
  public void dump() {
    System.out.println( getSourceFile() );
    System.out.println( getLine() );
    System.out.println( getWarningMessage() );
    System.out.println( getLevel() );
  }

  private String warm(String warning, String arg1, String arg2) {
    String str = Messages.getWarningString(warning);
    if (str == null) {
      return "can't find the warning message for " + warning;
    } else {
      // replace all parameters.
      for (int i = 0; (i = str.indexOf("%s", i)) >= 0 ; ) {
	StringBuffer stb = new StringBuffer(str.substring(0, i));
	str = stb.append(arg1).append(str.substring(i+2)).toString();
	arg1 = arg2;
      }
      return str;
    }
  }

  private int getLevel(String warning, int defaultLevel) {
    String str = Messages.getWarningLevelString(warning);
    if (str == null)
      return defaultLevel;
    else {
      try {
	int level = Integer.parseInt(str);
	if (level > 9 || level < 0) {
	  return defaultLevel;
	}
	return level;
      } catch (Exception e) {
	return defaultLevel;
      }
    }
  }

}
