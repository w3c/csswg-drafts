/*
 * $Log$
 */

package CSS.util;

import java.util.Properties;
import java.net.URL;

/**
 * @version $Revision$
 */
public class Messages {

  /**
   * Message properties
   */  
  public static Properties properties;

  /**
   * Get a property.
   */  
  public static String getString(String message) {
    return properties.getProperty(message);
  }

  /**
   * Get a warning property.
   * 
   * @param message the warning property.
   */  
  public static String getWarningString(String message) {
    return getString(new StringBuffer("warning.").append(message).toString());
  }

  /**
   * Get a warning level property.
   * 
   * @param message the warning property.
   */  
  public static String getWarningLevelString(String message) {
    return getString(new StringBuffer("warning.").append(message).append(".level").toString());
  }

  /**
   * Get an error property.
   *
   * @param message the error property.
   */  
  public static String getErrorString(String message) {
    return getString(new StringBuffer("error.").append(message).toString());
  }

  static {
    properties = new Properties();
    try {
      URL url = Messages.class.getResource("Messages.properties");
      java.io.InputStream f = url.openStream();
      try {
	  properties.load(f);
      } finally {
	  f.close();
      }
    } catch (Exception e) {
      System.err.println("CSS.util.Messages: couldn't load properties ");
      System.err.println("  " + e.toString() );
    }
  }
}
