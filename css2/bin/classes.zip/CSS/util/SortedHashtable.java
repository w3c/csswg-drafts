/*
 * $Log$
 */
package CSS.util;


import java.util.Enumeration;
import java.util.Hashtable;

/**
 * @version $Revision$
 */
public class SortedHashtable extends Hashtable {

  /**
   * Constructs a new, empty hashtable with the specified initial 
   * capacity and the specified load factor. 
   *
   * @param      initialCapacity   the initial capacity of the hashtable.
   * @param      loadFactor        a number between 0.0 and 1.0.
   * @exception  IllegalArgumentException  if the initial capacity is less
   *               than or equal to zero, or if the load factor is less than
   *               or equal to zero.
   */
  public SortedHashtable(int initialCapacity, float loadFactor) {
    super(initialCapacity, loadFactor);
  }

  /**
   * Constructs a new, empty hashtable with the specified initial capacity
   * and default load factor.
   *
   * @param   initialCapacity   the initial capacity of the hashtable.
   */
    public SortedHashtable(int initialCapacity) {
        super(initialCapacity);
    }

  /**
   * Constructs a new, empty hashtable with a default capacity and load
   * factor. 
   *
   * @since   JDK1.0
   */
  public SortedHashtable() {
    super();
  }

  public Object[] getSortedArray() {
    Object[] sortedArray = new Object[size()];
    int i = 0;

    for (Enumeration e = elements(); e.hasMoreElements(); i++) {
      sortedArray[i] = e.nextElement();
    }
    
    quickSort(sortedArray, 0, size()-1);

    return sortedArray;
  }

  private int partition(Object[] array, int part_low_ind, int part_high_ind) {
    int lastsmall;
    String median_val;
    int comp1;
    Object transit;
    
    // swap median value an first value of array
    comp1 = ( part_low_ind + part_high_ind ) / 2;         
    
    transit = array[part_low_ind];
    array[part_low_ind] = array[comp1];
    array[comp1] = transit;
    median_val = array[part_low_ind].toString();
    lastsmall = part_low_ind;
    for (int i = part_low_ind + 1; i<=part_high_ind; i++) {
      if (array[i].toString().compareTo(median_val) < 0) {
          lastsmall++;
          // swap lastsmall and i
          transit=array[lastsmall];
          array[lastsmall]=array[i];
          array[i]=transit;
        }
    }
    // swap part_low_ind and lastsmall
    transit=array[part_low_ind];
    array[part_low_ind]=array[lastsmall];
    array[lastsmall]=transit;
    
    return lastsmall;
  }
  
  private void quickSort(Object[] array, int qk_low_ind, int qk_high_ind) {
    if (qk_low_ind < qk_high_ind) {
      int median = partition(array, qk_low_ind, qk_high_ind);
      quickSort(array, qk_low_ind, median);
      quickSort(array, median+1, qk_high_ind);
    }
  }


}
