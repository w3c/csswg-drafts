package CSS.Properties2;

import java.util.Properties;
import java.net.URL;

import CSS.Properties.CssProperty;

/**
 * @version $Revision: 2.1 $
 */
public class Css2Properties {
  public static Properties properties;

  public static String getString(CssProperty property, String prop) {
    return properties.getProperty(property.getPropertyName()+"."+prop);
  }

  public static boolean getInheritance(CssProperty property) {
    return getString(property, "inherited").equals("true");
  }
  
  static {
    properties = new Properties();
    try {
      URL url = Css2Properties.class.getResource("CSS2Default.properties");
      properties.load(url.openStream());
    } catch (Exception e) {
      System.err.println("CSS.Properties2.Css2Properties: couldn't load properties ");
      System.err.println("  " + e.toString() );
    }
  }
}
