/*
 * $Log: CssColorConstants.java,v $
 * Revision 1.3  1997/07/30 13:19:32  plehegar
 * Updated package
 *
 * Revision 1.2  1997/07/22 17:48:26  plehegar
 * Bug fix marron
 *
 * Revision 1.1  1997/07/21 22:07:31  plehegar
 * Initial revision
 *
 */
package CSS.Values;

/**
 * This class is ued by CssColor
 *
 * @version $Revision: 1.3 $
 * @see CSS.Values.CssColor
 */
public interface CssColorConstants {

  /**
   * All named colors.
   */  
  public static final String[] COLORNAME = {
    "aqua", "black", "blue", "fushia", "gray", "green", "lime", "maroon", 
    "navy", "olive", "purple", "red", "silver", "teal", "white", "yellow" };

}
