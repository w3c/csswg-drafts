/*
 * $Log: CssValue.java,v $
 * Revision 2.2  1997/08/20 11:39:49  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/08 15:53:07  plehegar
 * Nothing
 *
 * Revision 1.3  1997/07/30 13:19:37  plehegar
 * Updated package
 *
 * Revision 1.2  1997/07/24 00:23:40  plehegar
 * Added equals()
 *
 * Revision 1.1  1997/07/18 20:28:51  plehegar
 * Initial revision
 *
 */
package CSS.Values;

import CSS.util.InvalidParamException;
import CSS.Parser.Frame;

/**
 * @version $Revision: 2.2 $
 */
public abstract class CssValue {

  /**
   * Set the value of this value.
   *
   * @param s     the string representation of the value.
   * @param frame For errors and warnings reports.
   * @exception InvalidParamException The unit is incorrect
   */  
  public abstract void set(String s, Frame frame) throws InvalidParamException;

  /**
   * Returns the internal value
   */  
  public abstract Object get();

  /**
   * Compares two values for equality.
   *
   * @param value The other value.
   */  
  public boolean equals(Object value) {
    return super.equals(value);
  }
}
