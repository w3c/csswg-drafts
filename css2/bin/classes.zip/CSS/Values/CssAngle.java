/*
 * $Log: CssAngle.java,v $
 * Revision 1.1  1997/08/29 13:10:38  plehegar
 * Initial revision
 *
 * Revision 1.1  1997/08/21 08:29:35  plehegar
 * Initial revision
 *
 */
package CSS.Values;

import CSS.util.InvalidParamException;
import CSS.Parser.Frame;

/**
 * <H3>Angle</H3>

 * <P>Angle units are used with aural cascading style sheets.
 *
 * <P>These are the legal angle units:
 *
 * <UL>
 * <LI>deg: degrees
 * <LI>grad: gradians
 * <LI>rad: radians
 * </UL>
 *
 * <p>Values in these units may be negative. They should be normalized to the
 * range 0-360deg by the UA. For example, -10deg and 350deg are equivalent.
 *
 * @version $Revision: 1.1 $ */
public class CssAngle extends CssValue {

  /**
   * Create a new CssAngle.
   */
  public CssAngle() {
    this(defaultValue);
  }  

  /**
   * Create a new CssAngle
   */
  public CssAngle(float v) {
    this(new Float(v));
  } 

  /**
   * Create a new CssAngle
   */
  public CssAngle(Float angle) {
    value = angle;
  }  

  /**
   * Set the value of this angle.
   *
   * @param s The string representation of the angle
   * @param frame For errors and warnings reports
   * @exception InvalidParamException The unit is incorrect
   */  
  public void set(String s, Frame frame) throws InvalidParamException {
    s = s.toLowerCase();
    int length = s.length();
    String unit;
    float v;
    if (s.indexOf("grad") == -1) {
      unit = s.substring(length-3, length);
      v = new Float(s.substring(0, length-3)).floatValue();
    } else {
      unit = "grad";
      v = new Float(s.substring(0, length-4)).floatValue();
    }
    int hash = unit.hashCode();


    int i = 0;
    while (i<units.length) {
      if (hash == hash_units[i]) {
	this.unit = i;
	break;
      }
      i++;
    }

    switch (i) {
    case 0:
      break;
    case 1:
      v *= ( 180 / (float) Math.PI );
      break;
    case 2:
      v *= ( 9 / (float) 5 );
      break;
    default:
      throw new InvalidParamException("unit", unit);
    }

    this.unit = 0; // there is no unit by default

    while (v < 0) {
      v += 360;
    }
    while (v > 360) {
      v -= 360;
    }

    this.value = new Float(v);
  }

  /**
   * Returns the current value
   */  
  public Object get() {
    return value;
  }
  
  /**
   * Returns the current value
   */  
  public String getUnit() {
    return units[unit];
  }

  /**
   * Returns a string representation of the object.
   */
  public String toString() {
    if (value.floatValue() != 0)
      return get() + getUnit();
    else
      return get().toString();
  }

  /**
   * Compares two values for equality.
   *
   * @param value The other value.
   */  
  public boolean equals(Object value) {
    return (value instanceof CssAngle && 
	    this.value.equals(((CssAngle) value).value) &&
	     unit == ((CssAngle) value).unit);
  }

  private Float value;
  private int unit;
  private static String[] units = { "deg", "grad", "rad" };
  private static int[] hash_units;
  private static Float defaultValue = new Float(0);

  static {
    hash_units = new int[units.length];
    for (int i=0; i<units.length; i++)
      hash_units[i] = units[i].hashCode();
  }
}

