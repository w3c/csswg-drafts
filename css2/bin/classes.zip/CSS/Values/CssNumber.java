/*
 * $Log: CssNumber.java,v $
 * Revision 2.1  1997/08/08 15:53:05  plehegar
 * Nothing
 *
 * Revision 1.3  1997/07/30 13:19:34  plehegar
 * Updated package
 *
 * Revision 1.2  1997/07/23 21:01:29  plehegar
 * Added getLength()
 *
 * Revision 1.1  1997/07/16 13:58:16  plehegar
 * Initial revision
 *
 */
package CSS.Values;

import CSS.util.InvalidParamException;
import CSS.Parser.Frame;

/**
 * A CSS float number.
 *
 * @version $Revision: 2.1 $
 */
public class CssNumber extends CssValue {
    
    Float value;

    /**
     * Create a new CssNumber
     */
    public CssNumber() {
    }
    
    /**
     * Create a new CssNumber
     */
    public CssNumber(float value) {
	this.value = new Float(value);
    }    
    
    /**
     * Set the value of this frequency.
     *
     * @param s     the string representation of the frequency.
     * @param frame For errors and warnings reports.
     */  
    public void set(String s, Frame frame) {
	value = new Float(s);
    }
    
    /**
     * Returns the value
     */  
    public Object get() {
	return value;
    }
    
    /**
     * Returns a length.
     * Only zero can be a length.
     *
     * @exception InvalidParamException The value is not zero
     */  
    public CssLength getLength() throws InvalidParamException {
	float num = value.floatValue();
	if (num == 0)
	    return new CssLength();
	else
	    throw new InvalidParamException("zero", value.toString(), "length");
    }
    
    /**
     * Returns a percentage.
     * Only zero can be a length.
     *
     * @exception InvalidParamException The value is not zero
     */  
    public CssPercentage getPercentage() throws InvalidParamException {
	float num = value.floatValue();
	if (num == 0)
	    return new CssPercentage();
	else
	    throw new InvalidParamException("zero", value.toString(), "percentage");
    }
    
    /**
     * Returns a time.
     * Only zero can be a length.
     *
     * @exception InvalidParamException The value is not zero
     */  
    public CssTime getTime() throws InvalidParamException {
	float num = value.floatValue();
	if (num == 0)
	    return new CssTime();
	else
	    throw new InvalidParamException("zero", value.toString(), "time");
    }
    
    /**
     * Returns a angle.
     * Only zero can be a length.
     *
     * @exception InvalidParamException The value is not zero
     */  
    public CssAngle getAngle() throws InvalidParamException {
	float num = value.floatValue();
	if (num == 0)
	    return new CssAngle();
	else
	    throw new InvalidParamException("zero", value.toString(), "angle");
    }
    
    /**
     * Returns a frequency.
     * Only zero can be a length.
     *
     * @exception InvalidParamException The value is not zero
     */  
    public CssFrequency getFrequency() throws InvalidParamException {
	float num = value.floatValue();
	if (num == 0)
	    return new CssFrequency();
	else
	    throw new InvalidParamException("zero", value.toString(), "frequency");
    }
    
    /**
     * Returns a string representation of the object.
     */
    public String toString() {  
	return value.toString();
    }
    
    /**
     * Compares two values for equality.
     *
     * @param value The other value.
     */  
    public boolean equals(Object value) {
	return (value instanceof CssNumber && 
		this.value.equals(((CssNumber) value).value));
    }
    
}
