/*
 * $Log: CssValidator.java,v $
 * Revision 3.1  1997/08/29 13:23:27  plehegar
 * Freeze
 *
 * Revision 2.2  1997/08/20 11:42:09  plehegar
 * Freeze
 *
 * Revision 2.1  1997/08/11 08:05:17  plehegar
 * Freeze
 *
 * Revision 1.1  1997/07/28 21:32:31  plehegar
 * Initial revision
 *
 */

package CSS.servlet;

import java.io.IOException;
import java.io.EOFException;
import java.io.PrintWriter;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// multipart/form-data
import CSS.util.Codecs;
import CSS.util.NVPair;

import CSS.Parser.CssFouffa;
import CSS.CSS.CssParser;
import CSS.CSS.StyleSheetXMLParser;
import CSS.CSS.StyleSheetParser;
import CSS.CSS.HTMLStyleSheetParser;
import CSS.CSS.StyleSheet;
import CSS.CSS.StyleSheetGenerator;
import CSS.ACssProperties.ACssStyle;
import CSS.util.Util;
import CSS.util.FakeFile;

/**
  * This class is a servlet to use the validator.
  *
  * @version $Revision: 3.1 $
  */
public final class CssValidator extends HttpServlet {
  
  private CssParser parser;
  private URL htmlURL;
  private int warningLevel = 2;
  private boolean debug;
  private boolean auralMode;
  private boolean errorReport = true;

  private String returnMode;
  private String documentBase;

  private final static String texthtml    = "text/html";
  private final static String textplain   = "text/plain";
  private final static String textunknwon = "text/unknown";
  private final static String html = "html";

  // for errors and warnings
  private static URL baseDocument;

  static {
    try {
      baseDocument = new URL("http://jigsaw.w3.org/demos/guests/css/");
    } catch (MalformedURLException e) {}
  }

  /**
   * Create a new CssValidator.
   */
  public CssValidator() {
    returnMode = texthtml;
    documentBase = html;
  }

  /**
   * Initializes the servlet and logs the initialization. The init
   * method is called once, automatically, by the network service each
   * time it loads the servlet.  It is guaranteed to finish before any
   * service requests are accepted.  On fatal initialization errors, an
   * UnavailableException should be thrown.  Do not call the method
   * System.exit.
   *
   * <p> The init method stores the ServletConfig object.  Servlet
   * writers who specialize this method should call either super.init,
   * or store the ServletConfig object themselves.  If an implementor
   * decides to store the ServletConfig object in a different location,
   * then the getServletConfig method must also be overridden.
   *
   * <P>
   * <DL><STRONG>Init parameters:</STRONG>
   * <DT>debug
   * <DD><code>true</code> if you want to be in debug mode.
   * <DT>aural
   * <DD><code>true</code> if you want to be in aural mode.
   * <DT>import
   * <DD><code>false</code> if you don't want to activate the import statement.
   *     For security reasons, you shoud be careful when you lunch the servlet
   *     on a HTTP server with special access authorization.
   * <DT>input
   * <DD><code>html</code> if the user have an HTML input or <code>xml</code> 
   *     otherwise. <strong>deprecated</strong>
   * </DL>
   *
   * @param config servlet configuration information.
   * @exception ServletException if a servlet exception has occurred.  
   */
  public void init(ServletConfig config) throws ServletException {
    super.init(config);

    // [SECURITY] don't forget this !
    Util.servlet = true;

    if (config.getInitParameter("debug") != null) {
      // servlet debug mode
      // define a boolean property CSS.StyleSheet.debug if you want more debug.
      this.debug = config.getInitParameter("debug").equals("true");
    }
    if ((config.getInitParameter("aural") != null) &&
	(config.getInitParameter("aural").equals("true"))) {

      try {
	Properties auralConfig = new Properties();
	URL url = ACssStyle.class.getResource("ACSSDefault.properties");
	java.io.InputStream f = url.openStream();
	try {
	    auralConfig.load(f);
	} finally {
	    f.close();
	}
	CssFouffa.loadConfig(auralConfig);
	verbose( "Aural mode activate ..." );
      } catch (Exception e) {
	System.err.println("CSS.servlet.CssValidator: Coudln't load aural config");
	e.printStackTrace();
      }
    }

    if ((config.getInitParameter("input") != null) &&
	(config.getInitParameter("input").equals("xml"))) {
      parser = new StyleSheetXMLParser();
    } else {
      parser = new StyleSheetParser();
    }

    if ((config.getInitParameter("import") != null) &&
	(config.getInitParameter("import").equals("false"))) {
      Util.importSecurity = true;
    }

  }

  /** 
   * Performs the HTTP GET operation.  An HTTP BAD_REQUEST error is
   * reported if an error occurs. This servlet writers shouldn't set the
   * headers for the requested entity (content type and encoding).
   *
   * <P> Note that the GET operation is expected to be <em>safe</em>,
   * without any side effects for which users might be held responsible.
   * For example, most form queries have no side effects.  Requests
   * intended to change stored data should use some other HTTP method.
   * (There have been cases of significant security breaches reported
   * because web-based applications used GET inappropriately.)
   *
   * <P> The GET operation is also expected to be <em>idempotent</em>,
   * meaning that it can safely be repeated.  This is not quite the same
   * as being safe, but in some common examples the requirements have
   * the same result.  For example, repeating queries is both safe and
   * idempotent (unless payment is required!), but buying something or
   * modifying data is neither safe nor idempotent.
   *
   * <P>
   * <DL><STRONG>Forms parameters:</STRONG>
   * <DT>URL
   * <DD>the URL to be parsed.
   * <DT>submitURL
   * <DD>if the user want to parse an URL.
   * <DT>text
   * <DD>The text to be parsed.
   * <DT>submitTEXT
   * <DD>if the user want to parse the text.
   * <DT>output
   * <DD>HTML if the user want an HTML output or XML otherwise.
   * <DT>input
   * <DD>HTML if the user have an HTML input or XML otherwise.
   * </DL>
   *
   * @param req encapsulates the request to the servlet.
   * @param resp encapsulates the response from the servlet.
   * @exception ServletException if the request could not be handled.
   * @exception IOException if detected when handling the request.  
   * @see CSS.CSS.StyleSheetGenerator
   */
  public void doGet(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {

    String url = req.getParameter("URL");
    String text = req.getParameter("text");
    String submitURL = req.getParameter("submitURL");
    String submitTEXT = req.getParameter("submitTEXT");
    String output = req.getParameter("output");
    String warning = req.getParameter("warning");
    String error = req.getParameter("error");
    PrintWriter out = new PrintWriter(res.getOutputStream());

    text = Util.suppressWhiteSpace(text);
    url = Util.suppressWhiteSpace(url);

    if (output == null)
      output = html;
    
    // verify the request
    if ((submitURL != null && url == null) ||
	(submitTEXT != null && text == null)) {
      res.sendError(res.SC_BAD_REQUEST, "You have send an invalid request.");
      return;
    }
    if (submitTEXT == null && submitURL == null) {
      if (url != null) {
	submitURL = "ok";
      } else {
	res.sendError(res.SC_BAD_REQUEST, "You have send an invalid request.");
	return;
      }
    }

    // set the content-type for the response
    if (output.equals(html)) {
      res.setContentType(texthtml);
    } else {
      res.setContentType(textplain);
    }

    // set the warning output
    if (warning != null && warning.equals("no")) {
      warningLevel = -1;
    } else {
      try {
	warningLevel = Integer.parseInt(warning);
      } catch (Exception e) {
	System.err.println( e );
      }
    }

    // set the error erport
    if (error != null && error.equals("no")) {
      errorReport = false;
    }

    // I don't want cache for the response (inhibits proxy)
    res.setHeader("Pragma", "no-cache");

    // debug mode
    verbose("\nServlet request ");
    if (submitURL != null)
      verbose("Source file : " + url );
    else
      verbose("TEXTAREA Input");
    verbose("From " + req.getRemoteHost() + 
	    " (" + req.getRemoteAddr() + ") at " + (new Date()) );

    if (submitURL != null) {
      // HTML document
      try {
	HTMLStyleSheetParser URLparser = 
	  new HTMLStyleSheetParser(url, auralMode);
	handleRequest(out, url, 
		      URLparser.getStyleSheet(), output);
      } catch (Exception e) {
	handleError(out, url, e);
	return;
      }
    } else if (submitTEXT != null) {
      // only text area can take XML input
      boolean XMLinput = false;

      if (req.getParameter("input") != null &&
	  req.getParameter("input").equals("XML")) {
	XMLinput = true;
      }
      
      // debug mode
      if (XMLinput) verbose( "XML input" );
      verbose("- TextArea Data -");
      verbose(text);
      verbose("- End of TextArea Data");

      // change to have the right parser
      if (XMLinput) {
	parser = new StyleSheetXMLParser();
      } else {
	parser.reInit();
      }

      try {
	parser.parseStyleElement(new ByteArrayInputStream(text.getBytes()), 
				 new URL(baseDocument, "TextArea"), 0);
	handleRequest(out, 
		      "TEXTAREA INPUT", parser.getStyleSheet(), output);
      } catch (Exception e) {
	handleError(out, "TextArea", e);
	return;
      }
      
      if (XMLinput) {
	parser = new StyleSheetParser();
      }
    } else {
      res.sendError(res.SC_INTERNAL_SERVER_ERROR, 
		    "please send a bug report to Philippe.Le_Hegaret@sophia.inria.fr");
    }


    verbose("CssValidator: Request terminated.\n");
  }

  /**
   * Performs the HTTP POST operation.  An HTTP BAD_REQUEST error is reported if
   * an error occurs. The headers that are set should include content type,
   * length, and encoding.  Setting content length allows the servlet to take
   * advantage of HTTP "connection keep alive".  If content length can not be
   * set in advance, the performance penalties associated with not using keep
   * alives will sometimes be avoided if the response entity fits in an internal
   * buffer.  The servlet implementor must write the headers before the response
   * data because the headers can be flushed at any time after the data starts
   * to be written.
   *
   * <P> This method does not need to be either "safe" or "idempotent".
   * Operations requested through POST could be ones for which users
   * need to be held accountable.  Specific examples including updating
   * stored data or buying things online.
   *
   * <P>
   * <DL><STRONG>Forms parameters:</STRONG>
   * <DT>file
   * <DD>The input file to be parsed.
   * <DT>output
   * <DD>The format output.
   * <DT>input
   * <DD>HTML if the user have an HTML input or XML otherwise.
   * </DL>
   *
   * @param req encapsulates the request to the servlet
   * @param resp encapsulates the response from the servlet
   * @exception ServletException if the request could not be handled
   * @exception IOException if detected when handling the request 
   * @see CSS.CSS.StyleSheetGenerator 
   */
  public void doPost(HttpServletRequest req, HttpServletResponse res) 
    throws ServletException, IOException {
      
    FakeFile file = null;
    String output = null;
    boolean XMLinput = false;
    String warning = null;
    String error = null;

    ServletInputStream in = req.getInputStream();
    byte[] buf = new byte[2048];
    byte[] general = new byte[65536];
    int count = 0;
    int len;

    verbose("\nCssValidator: Servlet request ");
    verbose("From " + req.getRemoteHost() + 
	    " (" + req.getRemoteAddr() + ") at " + (new Date()) );
    verbose("Content-length : " + req.getContentLength());

    if (req.getContentType().trim().startsWith("multipart/form-data")) {
      verbose("Content-type : multipart/form-data");
    }

    while ((len = in.readLine(buf, 0, buf.length)) != -1) {
      if (len >= 2 && buf[len-1] == '\n' && buf[len-2] == '\r') {
	len -= 1;
	buf[len-1] = '\n';
      }
      if (len  != 0 && buf[len-1] == '\r') {
	buf[len-1] = '\n';
      }
      
//       for (int i = 0; i < len; i++) {
// 	if (buf[i] == '\n' || buf[i] == '\r') {
// 	  System.err.print( "&" + ((int) buf[i]) );
// 	  System.err.println();
// 	} else {
// 	  System.err.print( (char) buf[i] );
// 	}
//       }

      System.arraycopy(buf, 0, general, count, len);
      count += len;
    }

    try {
      buf = new byte[count];
      System.arraycopy(general, 0, buf, 0, count);
      NVPair[] tmp = Codecs.mpFormDataDecode(buf, req.getContentType());
      for (int i = 0; i < tmp.length; i++) {
	if (tmp[i].getName().equals("file")) {
	  file = (FakeFile) tmp[i].getValue();
	} else if (tmp[i].getName().equals("output")) {
	  output = (String) tmp[i].getValue();
	} else if (tmp[i].getName().equals("warning")) {
	  warning = (String) tmp[i].getValue();
	} else if (tmp[i].getName().equals("error")) {
	  warning = (String) tmp[i].getValue();
	} else if (tmp[i].getName().equals("input")) {
	  XMLinput = ((String) tmp[i].getValue()).equals("XML");
	}
      }
    } catch (Exception e) {
      System.out.println( e );
    }
    if (output == null)
      output = html;

    if (file == null || file.getSize() == 0) {
      res.sendError(res.SC_BAD_REQUEST, "You have send an invalid request");
      return;
    }

    if (output.equals(html)) {
      res.setContentType(texthtml);
    } else {
      res.setContentType(textplain);
    }

    // set the warning output
    if (warning != null && warning.equals("no")) {
      warningLevel = -1;
    } else {
      try {
	warningLevel = Integer.parseInt(warning);
      } catch (Exception e) {
	System.err.println( e );
      }
    }

    // set the error erport
    if (error != null && error.equals("no")) {
      errorReport = false;
    }

    res.setHeader("Pragma", "no-cache");

    verbose("File : " + file.getName());
    if (XMLinput) verbose( "XML input" );

    if (XMLinput) {
      parser = new StyleSheetXMLParser();
    } else {
      parser.reInit();
    }

    try {
      parser.parseStyleElement(file.getInputStream(), 
			       new URL(baseDocument, file.getName()), 
			       0);
    
      handleRequest(new PrintWriter(res.getOutputStream()), 
		    file.getName(), parser.getStyleSheet(), output);
    } catch (Exception e) {
      handleError(new PrintWriter(res.getOutputStream()), file.getName(), e);
    }
    
    if (XMLinput) {
      parser = new StyleSheetParser();
    }
    
    verbose("CssValidator: Request terminated.\n");
  }
  
  private void handleRequest(PrintWriter out, 
			     String title, 
			     StyleSheet styleSheet, 
			     String output) 
    throws Exception {
    if (styleSheet == null) {
      throw new IOException("Can't process the file : " + title);
    }
      
    styleSheet.findConflicts();
    
    StyleSheetGenerator style;
    style = new StyleSheetGenerator(title, styleSheet, output, warningLevel);
    if (!errorReport)
      style.desactivateError();
    style.print(out);
  }

  private void handleError(PrintWriter out, String title, Exception e) {
    try {
      URL localURL = CssValidator.class.getResource("error.html");
      DataInputStream in = new DataInputStream(localURL.openStream());
      try {
	while (true)
	  out.print((char) in.readUnsignedByte());
      } catch (EOFException eof) {
	out.println("<H2>File : " + title + "</H2>");
	out.println(e.toString());
	out.println("<BR></BODY></HTML>");
	out.flush();
	e.printStackTrace();
	return;
      }
    } catch (Exception unknown) {
      out.println("CSS.servlet.CssValidator: couldn't load  error file");
      out.flush();
      unknown.printStackTrace();
      return;
    }
  }
  
  // trace function
  private final void verbose(String s) {
    if (debug) {
      System.err.println( s );
    }
  }

}
