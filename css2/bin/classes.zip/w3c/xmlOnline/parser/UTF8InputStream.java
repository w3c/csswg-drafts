package w3c.xmlOnline.parser;

import java.io.FilterInputStream;
import java.io.UTFDataFormatException;
import java.io.InputStream;
import w3c.xmlOnline.parser.CharInputStream;

/**
 * A "FilterInputStream" for decoding UTF8 streams.
 * Adds a method "readChar" that returns the next character from
 * a UTF8 encoded input stream.
 *
 * <p><em>This should probably be updated to use the Reader
 * classes from JDK 1.1...</em>
 *
 * @version	$Id: UTF8InputStream.java,v 1.2 1997/06/24 14:37:56 bbos Exp $
 * @author      Bert Bos
 */
public class UTF8InputStream
extends FilterInputStream
implements CharInputStream {

  /**
   * Initializer: creates a new UTF8 stream.
   * @param in	the input stream
   */
  public UTF8InputStream(InputStream in)
  {
    super(in);
  }

  private boolean eof = false;			// At eof?

  /**
   * Return next character. Will block until enough bytes
   * are available. Reads the required number of bytes (a
   * variable number) and computes the corresponding
   * (Unicode) character, which is returned.
   * @return	the Unicode number of the character read,
   *		or -1 if the end of the input is reached.
   * @see CharInputStream
   */
  public int readChar()
    throws java.io.UTFDataFormatException, java.io.IOException
  {
    if (eof) return -1;
    int c = in.read();
    int b2, b3;
    if ((c & 0x80) == 0x00) {			// 0xxxxxxx
      return (char)c;
    } else if ((c & 0xe0) == 0xc0) {		// 110xxxxx 10xxxxxx
      b2 = in.read();
      if ((b2 & 0xc0) != 0x80)
	throw new UTFDataFormatException();
      return (char)(((c & 0x1F) << 6) | (b2 & 0x3F));
    } else if ((c & 0xf0) == 0xe0) {		// 1110xxxx 10xxxxxx 10xxxxxx
      b2 = in.read();
      if ((b2 & 0xc0) != 0x80)
	throw new UTFDataFormatException();
      b3 = in.read();
      if ((b3 & 0xc0) != 0x80)
	throw new UTFDataFormatException();
      return (char)(((c & 0x1F) << 12) | ((b2 & 0x3F) << 6) | (b3 & 0x3f));
    } else if (c == -1) {			// EOF
      eof = true;
      return -1;
    } else {					// 10xxxxxx or 1111xxxx
      throw new UTFDataFormatException();	// Can't handle chars > \uffff
    }
  }

}
