package w3c.xmlOnline.parser;
import java.io.IOException;
public interface Scanner
{
  int next() throws IOException;
  int getLineno();
  int getColno();
}
