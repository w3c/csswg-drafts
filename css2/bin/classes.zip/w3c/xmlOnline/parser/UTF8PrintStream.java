package w3c.xmlOnline.parser;

import java.io.PrintStream;
import java.io.OutputStream;
import java.io.IOException;

/**
 * A PrintStream that outputs text in UTF8 encoding. This
 * is not actually used by the XML-online parser, but may be
 * useful in order to generate XML.
 *
 * <p><em>This should probably be updated to use the Writer
 * classes from JDK 1.1...</em>
 *
 * @version $Id: UTF8PrintStream.java,v 1.2 1997/06/24 14:37:56 bbos Exp $
 * @author Bert Bos
 */
public class UTF8PrintStream extends PrintStream {

  /**
   * Creates a new UTF8PrintStream.
   * @param out the output stream
   */
  public UTF8PrintStream(OutputStream out)
  {
    super(out);
  }

  /**
   * Creates a new UTF8PrintStream, with auto flushing.
   * @param out the output stream
   * @param autoflush if true the stream automatically flushes
   *		its output when a newline character is printed
   */
  public UTF8PrintStream(OutputStream out, boolean autoflush)
  {
    super(out, autoflush);
  }

  /**
   * Prints a String.
   * @param s the String to be printed
   */
  synchronized public void print(String s)
  {
    if (s == null) s = "null";
    int len = s.length();
    for (int i = 0 ; i < len; i++) print(s.charAt(i));
  }

  /**
   * Prints an array of characters.
   * @param s the array of chars to be printed
   */
  synchronized public void print(char s[])
  {
    for (int i = 0 ; i < s.length ; i++) print(s[i]);
  }

  /**
   * Write a character in UTF8 encoding.
   */
  public void print(char c)
  {
    if (c <= 0x007F) {
      write((byte)c);
    } else if (c <= 0x07FF) {
      write((byte)(0xC0 | (c >> 6)));
      write((byte)(0x80 | (c & 0x3F)));
    } else {					// c <= 0xFFFF
      write((byte)(0xC0 | (c >> 12)));
      write((byte)(0x80 | ((c >> 6) & 0x3F)));
      write((byte)(0x80 | (c & 0x3F)));
    }
  }

}
