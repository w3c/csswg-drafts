package w3c.xmlOnline.parser;

import java.io.FilterInputStream;
import java.io.UTFDataFormatException;
import java.io.InputStream;
import w3c.xmlOnline.parser.CharInputStream;

/**
 * A "FilterInputStream" for "decoding" ISO8859-1 streams.
 * Adds a method "readChar" that returns the next character from
 * a ISO8859-1 encoded input stream (which, of course, is just
 * the next byte).
 *
 * <p><em>This should probably be updated to use the Reader
 * classes from JDK 1.1...</em>
 *
 * @version	$Id: ISO88591InputStream.java,v 1.2 1997/06/24 14:37:55 bbos Exp $
 * @author      Bert Bos
 */
public class ISO88591InputStream
extends FilterInputStream
implements CharInputStream {

      /**
       * Initializer: creates a new ISO8859-1 stream.
       * @param in	the input stream
       */
  public ISO88591InputStream(InputStream in) {
    super(in);
  }

  private boolean eof = false;			// At eof?

      /**
       * Return next character. Will block until enough bytes
       * are available.
       * @return	the Unicode number of the character read,
       *		or -1 if the end of the input is reached.
       * @see CharInputStream
       */
  public int readChar()
    throws java.io.UTFDataFormatException, java.io.IOException
  {
    int c;
    if (eof) return -1;
    if ((c = in.read()) == -1) eof = true;
    return c;
  }

}
