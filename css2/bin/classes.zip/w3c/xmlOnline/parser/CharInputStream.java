package w3c.xmlOnline.parser;

import java.io.IOException;

/**
 * Interface that describes all InputStreams that can
 * read characters (as opposed to just bytes).
 *
 * <p><em>This should probably be updated to use the Reader
 * classes from JDK 1.1...</em>
 *
 * @version $Id: CharInputStream.java,v 1.2 1997/06/24 14:37:55 bbos Exp $
 * @author Bert Bos
 * @see UTF8InputStream
 */
public interface CharInputStream
{

  /**
   * Read and return a character, or -1 at end of file
   * @return Unicode code, or -1 if at eof
   */
  public int readChar()
    throws java.io.UTFDataFormatException, java.io.IOException;

} /* CharInputStream */
