package w3c.xmlOnline.parser;

/**
 * Exception indicating an attempt to set the input
 * stream of XMLTokenizer to an unknown encoding.
 */
public class UnknownEncoding extends Exception
{
    /**
     * Constructs an UnknowEncoding with no detail message.
     * A detail message is a String that describes this particular exception.
     */
    public UnknownEncoding() {super();}

    /**
     * Constructs an UnknownEncoding with the specified detail message.
     * A detail message is a String that describes this particular exception.
     * @param s the detail message
     */
    public UnknownEncoding(String s) {super(s);}
}
