package w3c.xmlOnline.parser;

import java.io.InputStream;
import java.io.IOException;
import java.io.UTFDataFormatException;
import w3c.xmlOnline.parser.UTF8InputStream;
import w3c.xmlOnline.parser.ISO88591InputStream;
import w3c.xmlOnline.parser.UnknownEncoding;
import w3c.xmlOnline.parser.ParserDef;
import w3c.xmlOnline.parser.Scanner;

/**
 * The XMLTokenizer class is created with a stream of bytes as
 * argument. Every call to next causes it to read a few more bytes and
 * return the token they represent. The encoding of the byte stream is
 * assumed to be UTF8 by default, but other encodings can be used as
 * well.
 *
 * <p>The corresponding parser is generated from the grammar in
 * <a href="Parser.ll1">Parser.ll1</a>.
 *
 * <h2>Differences with XML draft</h2>
 *
 * <p>The XMLTokens interface gives the list of tokens that are
 * recognized. Compared to the terminal symbols in <a
 * href="http://www.w3.org/pub/WWW/TR/WD-xml-961114.html">the XML
 * draft,</a> they are generally somewhat larger: on average a single
 * token represents more characters than a token in the XML draft. The
 * reason is that it divides the work between the tokenizer and the
 * parser better, and it allows the parser to work without lookahead,
 * running strictly as an LL(1) parser.
 *
 * <p>Another difference is in the way white space is handled. White
 * space is never returned as a token in this parser. It is either
 * ignored or passed as PCDATA, depending on the context. There are
 * three contexts: content mode, markup mode and marked-section mode
 * and each has its own rules. The rules are simple enough that the
 * tokenizer can deal with them, which in turn means that the parser
 * has an even easier job.
 *
 * <p>The rules for ignoring white space are not the same as in the
 * XML draft, though. In markup, white space only serves to seperate
 * other tokens, so ignoring it there is not an important change. In
 * marked-sections white space is never ignored, which is the same in
 * the XML draft. But in content the rule is different.
 *
 * <p>In content, there is a simple rule applied by the tokenizer: a
 * newline that immediately precedes a `&lt;' is ignored, as is a
 * newline that immediately follows a `&gt;'. No other white space is
 * ever ignored. A `newline' in this context is either a line feed
 * (U+000A), carriage return (U+000D) or a carriage return followed by
 * a line feed. For example, the following XML code (_ represents a
 * normal space):
 *
 * <pre>
 * before_&lt;dada&gt;some_text_ here&lt;/dada&gt;_after
 * </pre>
 *
 * <p>is exactly equivalent to:
 *
 * <pre>
 * before_
 * &lt;dada&gt;
 * some_text_here
 * &lt/dada&gt;
 * _after
 * </pre>
 *
 * <p>That means that to get a real newline just before or after some
 * markup, you will need to insert <em>two</em> newlines. That seems
 * like a small price to pay. Otherwise we would need different rules
 * for the whitespace outside the root element, since it is hard to
 * create files that don't end with a newline.
 *
 * <p>Ignoring <em>more</em> than one newline, or ignoring other
 * whitespace, would make it impossible to end an element with white
 * space.
 *
 * <p>Hexadecimal numeric entities don't have to have exactly four
 * digits in this implementation.
 *
 * <p>Comments may not contain occurrences of `--' (two dashes)
 * according to the XML draft. This tokenizer doesn't check for that;
 * it only ends a comment at `--&gt;'. (It would be easy enough to
 * add, though.)
 *
 * <p>Processing instructions, other than the predefined XML ones, are
 * not tokenized, but returned as a single string. It is left to the
 * application to look for the `target' (the first word in the
 * string).
 *
 * <p>Structured attributes are supported. They look like
 *
 * <pre>
 * &lt;*attribname&gt;... attribute content... &lt;&gt;
 * </pre>
 *
 * <p>As an experiment, a + is allowed instead of the * as well
 * (to see if it looks better). Similarly, end-tags
 * may use : instead of /
 *
 * <p>Three types of short end-tags are supported: <code>&lt;/&gt;</code>,
 * <code>&lt;:&gt;<code> and <code>&lt;&gt;</code>
 *
 * @version $Id: XMLTokenizer.java,v 1.4 1997/09/15 18:36:46 bbos Exp $
 * @author Bert Bos
 */
public class XMLTokenizer
implements ParserDef, Scanner
{

  private InputStream origStream;		// The raw byte stream
  private LookAhead in;				// The decoded stream
  private StringBuffer val = new StringBuffer(); // Value of current token
  private Double doubleval;			// Value of token if NUMBER
  private int nexttok = -1;			// Next (-1 = not yet known)

  private static final int CONTENT_MODE = 0;	// C
  private static final int MARKUP_MODE = 1;	// T
  private static final int CDATA_MODE = 2;	// M

  private int mode = CONTENT_MODE;		// Current lexical mode

  /**
   * Constructor: creates a tokenizer, given a raw byte stream.
   * The stream is assumed to be in UTF8.
   * @param aStream raw byte stream
   * @exception UnknownEncoding if the encoding isn't either UTF8 or ISO8859-1
   */
  public XMLTokenizer(InputStream aStream) throws UnknownEncoding
  {
    this(aStream, "UTF8");
  }

  /**
   * Constructor: creates a tokenizer, given a raw byte stream.
   * The stream is assumed to have the given encoding, which
   * can be "UTF8", "ISO8859-1",... (case-insensitive).
   * @param aStream raw byte stream
   * @param encoding the "charset" of the stream
   * @exception UnknownEncoding if the encoding isn't either UTF8 or ISO8859-1
   */
  public XMLTokenizer(InputStream aStream, String encoding)
    throws UnknownEncoding
  {
    origStream = aStream;
    setEncoding(encoding);
  }

  /**
   * Set the encoding of the input stream. This changes the way the
   * bytes are interpreted. The encoding may be changed in the
   * middle of parsing, but a few bytes may already have been
   * read into a buffer and will not be interpreted again.
   * Changing among charset in which XML delimiters are
   * encoded the same should normally work (UTF8, ISO8859-*)
   * Currently limited to UTF8 and ISO8859-1.
   * @param encoding a string like "utf8", "iso8859-1", etc.
   * @exception UnknownEncoding if the encoding isn't either UTF8 or ISO8859-1
   */
  public void setEncoding(String encoding) throws UnknownEncoding
  {
    String enc = encoding.toUpperCase();
    if (enc.equals("UTF8"))
      in = new LookAhead(new UTF8InputStream(origStream));
    else if (enc.equals("ISO8859-1"))
      in = new LookAhead(new ISO88591InputStream(origStream));
    else
      throw new UnknownEncoding(encoding);
  }

  /**
   * Return current line number
   */
  public int getLineno()
  {
    return in.getLineno();
  }

  /**
   * Return current column number
   */
  public int getColno()
  {
    return in.getColno();
  }

  /**
   * Return next token, storing any associated information
   * in a String that is available by calling value(). The
   * string is only available until the next call to next().
   * Not all tokens store information in value().
   * @return the recognized token (an int)
   */
  public int next() throws IOException
  {
    if (nexttok != -1) {int h = nexttok; nexttok = -1; return h;}
    val.setLength(0);
    if (in.atEof()) return __ENDMARK;
    switch (mode) {
      case CONTENT_MODE: return nextContent();
      case MARKUP_MODE: return nextMarkUp();
      case CDATA_MODE: return nextCData();
      default: throw new Error("Cannot happen");
    }
  }

  /**
   * Return the value associated with the current token.
   * Not all tokens set the value to something meaningful.
   * @return the contents of the current token
   */
  public String value()
  {
    return val.toString();
  }

  /**
   * Return the value associated with the current token.
   * Only valid if the current token is NUMBER.
   * @return the contents of the current token as a double
   */
  public Double doublevalue()
  {
    return doubleval;
  }

  /**
   * Recognize the lexical tokens that can occur in
   * CONTENT mode.
   * @return the next token
   */
  private int nextContent() throws IOException, UTFDataFormatException
  {
    // Ignore newline before '<'
    if (in.lookingAt("\n<") || in.lookingAt("\r<"))
      in.skip(1);
    else if (in.lookingAt("\r\n<"))
      in.skip(2);

    // Check for markup tokens
    if (! in.lookingAt("<")) {
      //val.setLength(0);
      while (! in.lookingAt("<") && ! in.lookingAt("\n<")
	     && ! in.lookingAt("\r<") && ! in.lookingAt("\r\n<")
	     && ! in.atEof()) {
	if (! in.lookingAt("&")) {
	  val.append(in.curChar());
	  in.skip(1);
	} else if (expandEntity()) {
	  /* text has been added to val */
	} else if (val.length() != 0) {
	  nexttok = UNKNOWN_ENT;		// Report this next time
	  return PCDATA;			// Report what we have so far
	} else {
	  return UNKNOWN_ENT;			// Report immediately
	}
      }
      return PCDATA;
    }
    in.skip(1);					// Skip '<'
    skipWS();					// Skip whitespace
    if (in.lookingAt("?")) {
      return readPI();
    } else if (in.lookingAt("/") || in.lookingAt(":")) {
      in.skip(1);
      mode = MARKUP_MODE;
      return ETAGO;
    } else if (in.lookingAt("*") || in.lookingAt("+")) {
      in.skip(1);
      mode = MARKUP_MODE;
      return ATTRIBOPEN;
    } else if (in.lookingAt(">")) {
      in.skip(1);
      skipNL();
      return ETAG;
    } else if (in.lookingAt("!--")) {
      return readComment();
    } else if (in.lookingAtIgnoreCase("!doctype")) {
      in.skip(8);
      mode = MARKUP_MODE;
      return DOCTYPE;
    } else if (in.lookingAtIgnoreCase("![cdata[")) {
      in.skip(8);
      mode = CDATA_MODE;
      return MSSTART;
    } else {
      mode = MARKUP_MODE;
      return LT;
    }
  }

  /** At "<!--". NOTE: newline after '>' is ignored */
  private int readComment() throws IOException
  {
    in.skip(3);					// "!--"
    //val.setLength(0);
    while (! in.atEof() && ! in.lookingAt("--")) {
      val.append(in.curChar());
      in.skip(1);
    }
    if (in.atEof()) return UNCLOSED_COMMENT;
    in.skip(2);					// "--"
    skipWS();
    if (! in.lookingAt(">")) return UNCLOSED_COMMENT;
    in.skip(1);					// ">"
    skipNL();
    return COMMENT;
  }

  /** At "<?". NOTE: newline after '>' is ignored */
  private int readPI() throws IOException
  {
    in.skip(1);					// "?"
    if (in.lookingAtIgnoreCase("xml ") || in.lookingAtIgnoreCase("xml\t")
	|| in.lookingAtIgnoreCase("xml\n") || in.lookingAtIgnoreCase("xml\r")){
      in.skip(4);
      mode = MARKUP_MODE;
      return XML;
    }
    //val.setLength(0);
    while (! in.atEof() && in.curChar() != '?') {
      val.append(in.curChar());
      in.skip(1);
    }
    if (in.atEof()) return UNCLOSED_PI;
    in.skip(1);					// "?"
    skipWS();
    if (in.curChar() != '>') return UNCLOSED_PI;
    in.skip(1);					// ">"
    skipNL();
    return PI;
  }

  /** At "&" looking at decimal or hexadecimal entity */
  private boolean expandEntity() throws IOException
  {
    int h, n = 0, radix;
    in.skip(1);					// "&"
    if (in.lookingAt("amp;")) {			// Predefined entity &amp;
      in.skip(4);
      val.append('&');
    } else if (in.lookingAt("lt;")) {		// Predefined entity &lt;
      in.skip(3);
      val.append('<');
    } else if (in.lookingAt("gt;")) {		// Predefined entity &gt;
      in.skip(3);
      val.append('>');
    } else if (in.lookingAt("quot;")) {		// Predefined entity &quot;
      in.skip(5);
      val.append('"');
    } else if (in.lookingAt("apos;")) {		// Predefined entity &apos;
      in.skip(5);
      val.append('\'');
    } else if (in.curChar() == '#') {		// Numeric entity
      in.skip(1);
      if (in.curChar() == 'x') {		// &#xnnn; hexadecimal
	in.skip(1);
	radix = 16;
      } else {					// &#nnn; decimal
	radix = 10;
      }
      do {
	if (in.atEof()) return false;
	h = Character.digit(in.curChar(), radix);
	if (h == -1) return false;
	in.skip(1);
	n = radix * n + h;
	if (n > 0xffff) return false;
      } while (! in.lookingAt(";"));
      in.skip(1);				// ";"
      val.append((char)n);
    } else
      return false;				// Illegal entity
    return true;
  }

//  /** At "XML " (already seen "<?"); change mode to MARKUP_MODE */
//  private int readXMLSpecial() throws IOException
//  {
//    in.skip(4);					// "XML "
//    mode = MARKUP_MODE;
//    skipWS();
//    if (in.lookingAtIgnoreCase("idinfo")) {in.skip(6); return IDINFO;}
//    if (in.lookingAtIgnoreCase("default")) {in.skip(7); return DEFAULT;}
//    if (in.lookingAtIgnoreCase("encoding")) {in.skip(8); return ENCODING;}
//    return UNKNOWN_XML;
//  }

  /**
   * Read data without expanding entities or parsing markup.
   * Only "[[>" is recognized. Tokens returned can be:
   * <pre>
   *   name      	text 			next mode
   *   MSDATA		any data		M
   *   MSEND		"]]>"			C
   *   UNCLOSED_MS	eof			M
   * </pre>
   * NOTE: newline after '>' is ignored */
  private int nextCData() throws IOException
  {
    //val.setLength(0);
    while (! in.atEof() && in.curChar() != ']' && ! in.lookingAt("]]>")) {
      val.append(in.curChar());
      in.skip(1);
    }
    if (in.atEof()) return UNCLOSED_MS;
    in.skip(3);					// "]]>"
    nexttok = MSEND;				// Return this next time
    mode = CONTENT_MODE;
    skipNL();
    return MSDATA;
  }

  /**
   * Read markup. Markup ends at a '>'
   * <pre>
   *   name      	text 			next mode
   *   EMPTY		"/>"			CONTENT
   *   ENDPI		"?>"			CONTENT
   *   EQ		"="			MARKUP
   *   GT		">"			CONTENT
   *   LITERAL	 	quoted string		MARKUP
   *   NAME		an identifier		MARKUP
   * </pre>
   */
  private int nextMarkUp() throws IOException
  {
    skipWS();
    char c = in.curChar();

    if (c == '=') {				// EQ
      in.skip(1);
      return EQ;
    }
    if (c == '>') {				// GT
      in.skip(1);
      skipNL();
      mode = CONTENT_MODE;
      return GT;
    }
    if (c == '\'' || c == '"') {		// LITERAL
      return readLiteral();
    }
    if (c == '?') {				// ENDPI
      in.skip(1);
      skipWS();
      if (! in.lookingAt(">")) return UNKNOWN_MARKUP;
      in.skip(1);
      skipNL();
      mode = CONTENT_MODE;
      return ENDPI;
    }
    if (c == '/') {				// EMPTY
      in.skip(1);
      skipWS();
      if (! in.lookingAt(">")) return UNKNOWN_MARKUP;
      in.skip(1);
      skipNL();
      mode = CONTENT_MODE;
      return EMPTY;
    }
    if (Character.isLetter(c)) {		// NAME
      return readName();
    }
    if (Character.isDigit(c) || c == '-' || c == '+') {	// NUMBER
      return readNumber();
    }
    in.skip(1);					// error
    return UNKNOWN_MARKUP;
  }

  /** Skip possible newline (called afet a '>') */
  private void skipNL() throws IOException, UTFDataFormatException
  {
    if (in.lookingAt("\n")) in.skip(1);
    else if (in.lookingAt("\r\n")) in.skip(2);
    else if (in.lookingAt("\r")) in.skip(1);
  }

  /** Skip whitespace */
  private void skipWS() throws IOException, UTFDataFormatException
  {
    while (Character.isSpace(in.curChar())) in.skip(1);
  }

  /** At "'" or "\"" */
  private int readLiteral() throws IOException, UTFDataFormatException
  {
    char c, quote = in.curChar();
    in.skip(1);
    //val.setLength(0);
    while (! in.atEof()
	   && (c = in.curChar()) != quote && c != '<' && c != '>') {
      if (c != '&') {
	val.append(c);
	in.skip(1);
      } else if (expandEntity()) {
	/* text has been added to val */
      } else {
	nexttok = UNKNOWN_ENT;			// Report this next time
	return LITERAL;				// Report what we have sofar
      }
    }
    if (in.atEof() || in.curChar() == '<' || in.curChar() == '>')
      return UNCLOSED_LIT;
    in.skip(1);
    return LITERAL;
  }

  /** At letter */
  private int readName() throws IOException, UTFDataFormatException
  {
    char c;
    //val.setLength(0);
    val.append(in.curChar());
    in.skip(1);
    while (! in.atEof()
	   && (Character.isLetterOrDigit((c = in.curChar()))
	       || c == '-' || c == '.' || c == ':')) {
      val.append(c);
      in.skip(1);
    }
    return NAME;
  }

  /** At digit */
  private int readNumber() throws IOException, UTFDataFormatException
  {
    char c;
    double n = 0, m = 1, sign = 1, exp = 0, expsign = 1;
    //val.setLength(0);
    c = in.curChar();
    val.append(c);
    if (c == '-') sign = -1;
    else if (c == '+') ; /* skip */
    else n = c - '0';
    in.skip(1);
    while (! in.atEof() && Character.isDigit((c = in.curChar()))) {
      val.append(c);
      n = 10 * n + c - '0';
      in.skip(1);
    }
    if (! in.atEof() && c == '.') {
      val.append(c);
      in.skip(1);
      while (! in.atEof() && Character.isDigit((c = in.curChar()))) {
	val.append(c);
	m /= 10.0;
	n += m * (c - '0');
	in.skip(1);
      }
    }
    if (sign == -1)
      n = -n;
    if (! in.atEof() && (c == 'E' || c == 'e')) {
      val.append(c);
      in.skip(1);
      c = in.curChar();
      val.append(c);
      if (c == '-') expsign = -1;
      else if (c == '+') ; /* skip */
      else exp = c - '0';
      in.skip(1);
      while (! in.atEof() && Character.isDigit((c = in.curChar()))) {
	val.append(c);
	exp = 10 * exp + c - '0';
	in.skip(1);
      }
      if (expsign == -1) exp = -exp;
      n *= Math.pow(10, exp);
    }
    doubleval = new Double(n);
    return NUMBER;
  }

}

final class LookAhead
{
  private int lineno = 1;			// Line number
  private int col = 0;				// Column number
  private CharInputStream in;			// The decoded stream;
  private char[] buf = new char[20];		// 20 should be enough
  private int buflen = 0;
  
  LookAhead(CharInputStream aStream)
  {
    in = aStream;
  }

  int getLineno() {return lineno;}
  int getColno() {return col;}


  char curChar() throws IOException
  {
    int c;
    if (buflen == 0) {
      c = in.readChar();
      if (c == -1) throw new IOException("Reading past EOF");
      buf[buflen++]= (char)c;
    }
    return buf[0];
  }

  boolean lookingAt(String s) throws IOException
  {
    int slen = s.length();
    for (int i = 0; i < slen; i++) {
      if (buflen <= i) {
	int c = in.readChar();
	if (c == -1) return false;
	buf[buflen++] = (char)c;
      }
      if (s.charAt(i) != buf[i]) return false;
    }
    return true;
  }

  boolean lookingAtIgnoreCase(String s) throws IOException
  {
    int slen = s.length();
    for (int i = 0; i < slen; i++) {
      if (buflen <= i) {
	int c = in.readChar();
	if (c == -1) return false;
	buf[buflen++] = (char)c;
      }
      if (s.charAt(i) != Character.toLowerCase(buf[i])) return false;
    }
    return true;
  }

  boolean atEof() throws IOException, UTFDataFormatException
  {
    int c;
    if (buflen != 0) return false;
    c = in.readChar();
    if (c == -1) return true;
    buf[buflen++] = (char)c;
    return false;
  }

  private int prev = -1;			// Previous char


  void skip(int n) throws IOException, UTFDataFormatException
  {
    int min = n < buflen ? n : buflen;

    // Count newlines in buffer
    for (int i = 0; i < min; i++) {
      if (buf[i]=='\r' || (buf[i]=='\n' && prev!='\r')) {lineno++; col = 0;}
      prev = buf[i]; col++;
    }

    // Shift buffer left
    buflen -= min;
    if (buflen != 0) System.arraycopy(buf, min, buf, 0, buflen);

    // Read more while counting newlines
    for (int i = min; i < n; i++) {
      int c = in.readChar();
      if (c == '\r' || (c == '\n' && prev != '\r')) {lineno++; col = 0;}
      prev = c; col++;
    }
  }

}
