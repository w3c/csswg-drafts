package w3c.xmlOnline.parser;

import java.util.Vector;

/**
 * An auxiliary class for the parser. It helps to implements lexical
 * scoping. Each DChain objects contains the name of an element, a
 * vector with attribute names (at Vector[2k]) and default values for
 * that attribute (at Vector [2k+1]), and two pointers to other DChain
 * objects. One points to the DChain object for the same element in a
 * wider scope (which is temporarily hidden by this DChain) and the
 * other points to the DChain that was created most recently before
 * this one. When a lexical scope ends, the parser discards all DChain
 * objects by following this latter chain until it is back in the
 * situation at the start of the lexical scope.
 *
 * @version $Id: DChain.java,v 1.2 1997/06/24 14:37:55 bbos Exp $
 * @author Bert Bos
 */
class DChain extends Vector
{
  /** Elt for which these are the default attributes */
  String tag;

  /** Same elt but in a wider scope (same hash bucket) */
  DChain nextInBucket;

  /** Most recently created DChain before this one */
  DChain nextInChain;

  /** Create a new DChain object. */
  DChain(String elt, DChain bucket, DChain chain)
  {
    tag = elt;
    nextInBucket = bucket;
    nextInChain = chain;
  }

}
