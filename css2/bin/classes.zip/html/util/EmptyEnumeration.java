/* Copyright (c) 1997 by Groupe Bull.  All Rights Reserved */
/* $Id: EmptyEnumeration.java,v 1.1 1997/01/28 16:11:24 leon Exp $ */
/* Author: Jean-Michel.Leon@sophia.inria.fr */

package html.util;

import java.util.*;

public class EmptyEnumeration implements Enumeration {
    public boolean hasMoreElements() {
	return false;
    }
    
    public Object nextElement() {
	return null;
    }
}
