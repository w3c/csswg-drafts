/* Copyright (c) 1997 by Groupe Bull.  All Rights Reserved */
/* $Id: Unknown.java,v 1.1 1997/02/05 14:40:45 leon Exp $ */
/* Author: Jean-Michel.Leon@sophia.inria.fr */

package html.tags;

import html.tree.*;

public class Unknown extends HtmlTree {

    public boolean isBlock() {
	return false;
    }

    public boolean isPreformatted() {
	return true;
    }

}
