/* Copyright (c) 1997 by Groupe Bull.  All Rights Reserved */
/* $Id: HtmlStreamListener.java,v 1.1 1997/02/05 14:40:44 leon Exp $ */
/* Author: Jean-Michel.Leon@sophia.inria.fr */

package html.tags;

public interface HtmlStreamListener {
    public void notifyActivity(int lines, long bytes);
}
